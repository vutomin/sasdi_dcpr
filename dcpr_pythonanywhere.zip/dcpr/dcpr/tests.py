import shutil
import tempfile

from django.contrib.auth.models import Group, User
from django.core import mail
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.urls import reverse

from .models import Attachment, Boundary, BoundaryDataset, CaptureRequest, Dataset, Project
from .roles import CHAIRPERSON, NSIF, SUBCOMMITTEE

MEDIA = tempfile.mkdtemp()


def pdf(name="spec.pdf"):
    return SimpleUploadedFile(name, b"%PDF-1.4 test", content_type="application/pdf")


def dataset_data(i=0, title="Gauteng provincial roads", **extra):
    d = {
        f"ds-{i}-title": title, f"ds-{i}-purpose": "Road maintenance planning",
        f"ds-{i}-lineage": "", f"ds-{i}-feature_description": "Road centrelines with surface type",
        f"ds-{i}-abstract": "Network of provincial roads",
        f"ds-{i}-geographic_extents": ["P", "M"], f"ds-{i}-geographic_extent_other": "",
        f"ds-{i}-data_types": ["N", "L"], f"ds-{i}-resolution": "1:10 000",
        f"ds-{i}-attributes": "Road number, surface, width",
        f"ds-{i}-capture_methods": ["CC", "D"], f"ds-{i}-method_details": "Vehicle-mounted GPS",
        f"ds-{i}-boundary_ids": str(Boundary.objects.get(level="province", code="GT").pk),
        f"ds-{i}-extent_geojson": "", f"ds-{i}-extent_kind": "",
    }
    d.update(extra)
    return d


def form_data(action="submit", datasets=1, attach=True, **extra):
    d = {
        "org-name": "Gauteng Dept of Roads", "org-level": "P", "org-address": "1 Main Rd, Johannesburg",
        "contact-name": "Thandi Mokoena", "contact-designation": "GIS Manager",
        "contact-phone_number": "0115551234", "contact-fax_number": "", "contact-email": "thandi@example.org",
        "project-name": "Provincial road network update", "project-start_date": "2026-11-01",
        "project-end_date": "2027-03-31", "project-estimated_cost": "250000.00",
        "req-urgency": "M", "req-data_usage_restrictions": "N",
        "ds-TOTAL_FORMS": str(datasets), "ds-INITIAL_FORMS": "0", "ds-MIN_NUM_FORMS": "1", "ds-MAX_NUM_FORMS": "1000",
        "req-declarant_name": "Thandi Mokoena", "req-declarant_designation": "GIS Manager",
        "req-declaration_accepted": "on",
        "att-TOTAL_FORMS": "1", "att-INITIAL_FORMS": "0", "att-MIN_NUM_FORMS": "0", "att-MAX_NUM_FORMS": "1000",
        "att-0-category": "spec", "att-0-description": "Detailed specification",
        "action": action,
    }
    for i in range(datasets):
        d.update(dataset_data(i, title=f"Dataset {i + 1}" if i else "Gauteng provincial roads"))
    if attach:
        d["att-0-file"] = pdf()
    d.update(extra)
    return d


@override_settings(MEDIA_ROOT=MEDIA)
class WorkflowTests(TestCase):
    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        shutil.rmtree(MEDIA, ignore_errors=True)

    def setUp(self):
        self.applicant = User.objects.create_user("app", "app@example.org", "pw")
        self.other = User.objects.create_user("other", "o@example.org", "pw")
        self.nsif = self._user("nsif", NSIF)
        self.committee = self._user("committee", SUBCOMMITTEE)
        self.chair = self._user("chair", CHAIRPERSON)

    def _user(self, name, group):
        u = User.objects.create_user(name, f"{name}@gov.za", "pw")
        u.groups.add(Group.objects.get(name=group))
        return u

    def _submit(self, form_type="E1", **extra):
        self.client.force_login(self.applicant)
        with self.captureOnCommitCallbacks(execute=True):
            r = self.client.post(reverse("dcpr:create", args=[form_type]), form_data(**extra))
        self.assertEqual(r.status_code, 302, getattr(r, "context", None) and [
            f.errors for f in (r.context.get("org_form"), r.context.get("dataset_formset"),
                               r.context.get("request_form"), r.context.get("formset")) if f])
        return CaptureRequest.objects.latest("pk")

    def _act(self, user, req, name, **data):
        self.client.force_login(user)
        payload = {f"{name}-{k}": v for k, v in data.items()}
        with self.captureOnCommitCallbacks(execute=True):
            return self.client.post(reverse("dcpr:action", args=[req.pk, name]), payload)

    def test_submit_e1_with_attachment(self):
        req = self._submit()
        self.assertEqual(req.status, "submitted")
        self.assertRegex(req.reference_number, r"^CSI/E1/\d{4}/0001$")
        self.assertEqual(req.attachments.count(), 1)
        self.assertEqual(req.attachments.first().category, "spec")
        self.assertEqual(req.dataset.title, "Gauteng provincial roads")
        self.assertTrue(any("received" in m.subject for m in mail.outbox))

    def test_save_draft_does_not_need_declaration(self):
        req = self._submit(action="save", **{"req-declaration_accepted": ""})
        self.assertEqual(req.status, "draft")
        self.assertIsNone(req.reference_number)

    def test_submit_requires_declaration(self):
        self.client.force_login(self.applicant)
        r = self.client.post(reverse("dcpr:create", args=["E1"]),
                             form_data(**{"req-declaration_accepted": ""}))
        self.assertEqual(r.status_code, 200)
        self.assertFalse(CaptureRequest.objects.exists())

    def test_rejects_disallowed_file_type(self):
        self.client.force_login(self.applicant)
        bad = SimpleUploadedFile("evil.exe", b"MZ", content_type="application/octet-stream")
        r = self.client.post(reverse("dcpr:create", args=["E1"]), form_data(**{"att-0-file": bad}))
        self.assertEqual(r.status_code, 200)
        self.assertFalse(CaptureRequest.objects.exists())

    def test_other_extent_requires_text(self):
        self.client.force_login(self.applicant)
        r = self.client.post(reverse("dcpr:create", args=["E1"]),
                             form_data(**{"ds-0-geographic_extents": ["O"]}))
        self.assertEqual(r.status_code, 200)
        self.assertIn("geographic_extent_other", r.context["dataset_formset"].forms[0].errors)

    def test_full_e1_approval_flow(self):
        req = self._submit()
        # Applicant cannot acknowledge
        self._act(self.applicant, req, "acknowledge")
        req.refresh_from_db()
        self.assertEqual(req.status, "submitted")

        self._act(self.nsif, req, "acknowledge")
        req.refresh_from_db()
        self.assertEqual(req.status, "acknowledged")

        # Adjudication requires notes AND pack
        self._act(self.nsif, req, "send_for_adjudication", comment="Looks fine")
        req.refresh_from_db()
        self.assertEqual(req.status, "acknowledged")
        self._act(self.nsif, req, "send_for_adjudication", comment="Meets SASDI standards", files=pdf("pack.pdf"))
        req.refresh_from_db()
        self.assertEqual(req.status, "adjudication")
        self.assertEqual(req.assessment_notes, "Meets SASDI standards")

        self._act(self.committee, req, "criteria_met", comment="Approved at meeting 12")
        req.refresh_from_db()
        self.assertEqual((req.status, req.outcome), ("awaiting_signature", "approved"))

        self._act(self.chair, req, "sign_letter", files=pdf("signed.pdf"))
        req.refresh_from_db()
        self.assertEqual(req.status, "letter_signed")

        # Signed letter hidden from applicant until notified
        signed = req.attachments.get(category="signed_letter")
        self.client.force_login(self.applicant)
        self.assertEqual(self.client.get(reverse("dcpr:download", args=[signed.pk])).status_code, 403)

        mail.outbox.clear()
        self._act(self.nsif, req, "notify_applicant", comment="Congratulations")
        req.refresh_from_db()
        self.assertEqual(req.status, "notified")
        self.assertTrue(any("Successful" in m.subject for m in mail.outbox))
        self.client.force_login(self.applicant)
        self.assertEqual(self.client.get(reverse("dcpr:download", args=[signed.pk])).status_code, 200)

        self._act(self.nsif, req, "file_and_close", file_reference="NSIF/2026/88")
        req.refresh_from_db()
        self.assertEqual(req.status, "closed")
        self.assertEqual(req.file_reference, "NSIF/2026/88")
        self.assertIsNotNone(req.closed_at)
        self.assertTrue(req.events.filter(action="register").exists())

        # Applicant never sees the internal adjudication pack
        pack = req.attachments.get(category="pack")
        self.client.force_login(self.applicant)
        self.assertEqual(self.client.get(reverse("dcpr:download", args=[pack.pk])).status_code, 403)

    def test_e1_rejection_requires_reason(self):
        req = self._submit()
        self._act(self.nsif, req, "acknowledge")
        self._act(self.nsif, req, "send_for_adjudication", comment="x", files=pdf())
        self._act(self.committee, req, "criteria_not_met")
        req.refresh_from_db()
        self.assertEqual(req.status, "adjudication")
        self._act(self.committee, req, "criteria_not_met", comment="Duplicates existing custodian data")
        req.refresh_from_db()
        self.assertEqual(req.outcome, "rejected")
        self.client.force_login(self.chair)
        r = self.client.get(req.get_absolute_url())
        self.assertContains(r, "Sign letter for unsuccessful request")

    def test_wrong_role_cannot_adjudicate(self):
        req = self._submit()
        self._act(self.nsif, req, "acknowledge")
        self._act(self.nsif, req, "send_for_adjudication", comment="x", files=pdf())
        self._act(self.nsif, req, "criteria_met", comment="self-approve")
        req.refresh_from_db()
        self.assertEqual(req.status, "adjudication")

    def test_e2_follows_full_process_with_notification_wording(self):
        req = self._submit("E2")
        self.assertTrue(req.reference_number.startswith("CSI/E2/"))
        self.assertEqual(req.noun, "notification")
        self.assertTrue(any("notification received" in m.subject for m in mail.outbox))
        self.client.force_login(self.nsif)
        r = self.client.get(req.get_absolute_url())
        self.assertContains(r, "Acknowledge notification")
        self.assertNotContains(r, "Acknowledge request")
        self._act(self.nsif, req, "acknowledge")
        # E2 can no longer be filed straight after acknowledgement
        self._act(self.nsif, req, "file_and_close", file_reference="F1")
        req.refresh_from_db()
        self.assertEqual(req.status, "acknowledged")
        self._act(self.nsif, req, "send_for_adjudication", comment="Custodian mandate confirmed", files=pdf())
        self.client.force_login(self.committee)
        self.assertContains(self.client.get(req.get_absolute_url()), "Notification meets criteria")
        self._act(self.committee, req, "criteria_met", comment="Noted and supported")
        self.client.force_login(self.chair)
        self.assertContains(self.client.get(req.get_absolute_url()), "Sign letter for successful notification")
        self._act(self.chair, req, "sign_letter", files=pdf("signed.pdf"))
        mail.outbox.clear()
        self._act(self.nsif, req, "notify_applicant")
        self.assertTrue(any("Outcome of your spatial data capture notification" in m.subject for m in mail.outbox))
        self._act(self.nsif, req, "file_and_close", file_reference="NSIF/E2/1")
        req.refresh_from_db()
        self.assertEqual((req.status, req.outcome), ("closed", "approved"))
        labels = list(req.events.values_list("label", flat=True))
        self.assertIn("Acknowledge notification", labels)
        self.assertIn("Notify applicant: successful notification", labels)

    def test_e2_can_be_referred_back(self):
        req = self._submit("E2")
        self._act(self.nsif, req, "acknowledge")
        self._act(self.nsif, req, "send_for_adjudication", comment="x", files=pdf())
        mail.outbox.clear()
        self._act(self.committee, req, "refer_back", comment="Attach the custodian mandate.")
        req.refresh_from_db()
        self.assertEqual(req.status, "returned")
        self.assertTrue(any("Your notification has been referred back" in m.subject for m in mail.outbox))

    def test_privacy_and_register(self):
        req = self._submit()
        self.client.force_login(self.other)
        self.assertEqual(self.client.get(req.get_absolute_url()).status_code, 403)
        self.assertEqual(self.client.get(reverse("dcpr:register")).status_code, 403)
        self.client.force_login(self.nsif)
        r = self.client.get(reverse("dcpr:register"))
        self.assertContains(r, req.reference_number)
        csv_resp = self.client.get(reverse("dcpr:register") + "?export=csv")
        self.assertIn(req.reference_number, csv_resp.content.decode())
        self.client.force_login(self.chair)
        self.assertEqual(self.client.get(reverse("dcpr:report")).status_code, 200)

    def test_edit_draft_and_add_more_documents(self):
        req = self._submit(action="save")
        att = req.attachments.first()
        data = form_data(action="submit", **{
            "att-TOTAL_FORMS": "2", "att-INITIAL_FORMS": "1",
            "att-0-id": str(att.pk), "att-0-category": "spec", "att-0-description": "Spec",
            "att-1-category": "plan", "att-1-description": "Plan", "att-1-file": pdf("plan.pdf"),
        })
        data.pop("att-0-file")
        r = self.client.post(reverse("dcpr:edit", args=[req.pk]), data)
        self.assertEqual(r.status_code, 302)
        req.refresh_from_db()
        self.assertEqual(req.status, "submitted")
        self.assertEqual(req.attachments.count(), 2)
        # applicant may add supplementary docs before adjudication
        r = self.client.post(reverse("dcpr:upload", args=[req.pk]),
                             {"category": "tor", "files": [pdf("tor.pdf"), pdf("tor2.pdf")]})
        self.assertEqual(req.attachments.count(), 4)
        # but can no longer edit the form
        r = self.client.get(reverse("dcpr:edit", args=[req.pk]))
        self.assertEqual(r.status_code, 302)

    def test_pages_render(self):
        req = self._submit()
        for u in (self.applicant, self.nsif):
            self.client.force_login(u)
            for url in (reverse("dcpr:dashboard"), req.get_absolute_url(),
                        reverse("dcpr:print", args=[req.pk]), reverse("dcpr:create", args=["E2"])):
                self.assertEqual(self.client.get(url).status_code, 200, url)

    # ---- datasets / multi-select / optional documents -------------------------
    def test_multiple_datasets_and_multi_select(self):
        req = self._submit(datasets=3)
        self.assertEqual(req.datasets.count(), 3)
        d = req.datasets[0]
        self.assertEqual(d.geographic_extents, ["P", "M"])
        self.assertEqual(d.data_types, ["N", "L"])
        self.assertEqual(d.capture_methods, ["CC", "D"])
        self.assertEqual(d.capture_method_display, "GPS coordinate capture, Digitising")
        self.client.force_login(self.nsif)
        csv_text = self.client.get(reverse("dcpr:register") + "?export=csv").content.decode()
        self.assertIn("3 of 3", csv_text)
        self.assertContains(self.client.get(reverse("dcpr:print", args=[req.pk])), "Dataset 3 of 3")

    def test_dataset_requires_at_least_one_selection(self):
        self.client.force_login(self.applicant)
        r = self.client.post(reverse("dcpr:create", args=["E1"]), form_data(**{"ds-0-data_types": []}))
        self.assertEqual(r.status_code, 200)
        self.assertIn("data_types", r.context["dataset_formset"].forms[0].errors)

    def test_duplicate_dataset_titles_rejected(self):
        self.client.force_login(self.applicant)
        r = self.client.post(reverse("dcpr:create", args=["E1"]),
                             form_data(datasets=2, **{"ds-1-title": "Gauteng provincial roads"}))
        self.assertEqual(r.status_code, 200)
        self.assertFalse(CaptureRequest.objects.exists())

    def test_remove_dataset_on_edit(self):
        req = self._submit(action="save", datasets=2)
        ids = list(req.datasets.values_list("pk", flat=True))
        data = form_data(datasets=2, attach=False, **{
            "ds-INITIAL_FORMS": "2", "ds-0-id": str(ids[0]), "ds-1-id": str(ids[1]), "ds-1-DELETE": "on",
            "ds-0-project": str(req.project.pk), "ds-1-project": str(req.project.pk),
        })
        r = self.client.post(reverse("dcpr:edit", args=[req.pk]), data)
        self.assertEqual(r.status_code, 302)
        self.assertEqual(req.datasets.count(), 1)

    def test_supporting_documents_optional(self):
        req = self._submit(attach=False)
        self.assertEqual(req.status, "submitted")
        self.assertEqual(req.attachments.count(), 0)
        # Category/description without a file is ignored rather than an error
        req2 = self._submit(attach=False, **{"att-0-category": "plan", "att-0-description": "later"})
        self.assertEqual(req2.attachments.count(), 0)

    # ---- refer back for amendments ---------------------------------------------
    def _to_stage(self, stage):
        req = self._submit()
        if stage == "submitted":
            return req
        self._act(self.nsif, req, "acknowledge")
        if stage == "acknowledged":
            return req
        self._act(self.nsif, req, "send_for_adjudication", comment="ok", files=pdf())
        if stage == "adjudication":
            return req
        self._act(self.committee, req, "criteria_met", comment="ok")
        return req

    def test_each_role_can_refer_back_at_its_stage(self):
        for stage, user in (("submitted", self.nsif), ("acknowledged", self.nsif),
                            ("adjudication", self.committee), ("awaiting_signature", self.chair)):
            req = self._to_stage(stage)
            mail.outbox.clear()
            self._act(user, req, "refer_back", comment="Please add the ward list.")
            req.refresh_from_db()
            self.assertEqual(req.status, "returned", stage)
            self.assertEqual(req.returned_from, stage)
            self.assertEqual(req.outcome, "")
            self.assertTrue(any("referred back" in m.subject for m in mail.outbox))

    def test_refer_back_requires_reason_and_right_role(self):
        req = self._to_stage("adjudication")
        self._act(self.committee, req, "refer_back")              # no reason
        self._act(self.nsif, req, "refer_back", comment="x")      # not NSIF's stage
        self._act(self.applicant, req, "refer_back", comment="x")
        req.refresh_from_db()
        self.assertEqual(req.status, "adjudication")

    def test_amend_and_resubmit(self):
        req = self._to_stage("adjudication")
        ref = req.reference_number
        self._act(self.committee, req, "refer_back", comment="Add a second dataset for bridges.")
        self.client.force_login(self.applicant)
        r = self.client.get(req.get_absolute_url())
        self.assertContains(r, "Add a second dataset for bridges.")
        r = self.client.get(reverse("dcpr:edit", args=[req.pk]))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Resubmit with amendments")

        ds = req.datasets[0]
        data = form_data(datasets=2, attach=False, **{
            "ds-INITIAL_FORMS": "1", "ds-0-id": str(ds.pk), "ds-0-project": str(req.project.pk),
            "ds-1-title": "Provincial bridges",
        })
        with self.captureOnCommitCallbacks(execute=True):
            r = self.client.post(reverse("dcpr:edit", args=[req.pk]), data)
        self.assertEqual(r.status_code, 302)
        req.refresh_from_db()
        self.assertEqual(req.status, "submitted")
        self.assertEqual(req.reference_number, ref)
        self.assertEqual(req.datasets.count(), 2)
        self.assertTrue(req.events.filter(action="resubmit").exists())
        # NSIF picks it up again
        self._act(self.nsif, req, "acknowledge")
        req.refresh_from_db()
        self.assertEqual(req.status, "acknowledged")

    def test_resubmit_requires_declaration_again(self):
        req = self._to_stage("submitted")
        self._act(self.nsif, req, "refer_back", comment="Fix cost")
        req.refresh_from_db()
        self.assertFalse(req.declaration_accepted)


# --------------------------------------------------------------------------- #
# Geospatial
# --------------------------------------------------------------------------- #
import json as _json

from django.core.management import call_command

from . import geo


def bbox_geojson(w, s, e, n):
    return _json.dumps({"type": "FeatureCollection", "features": [{"type": "Feature", "properties": {},
        "geometry": {"type": "Polygon", "coordinates": [[[w, s], [e, s], [e, n], [w, n], [w, s]]]}}]})


@override_settings(MEDIA_ROOT=MEDIA)
class SpatialTests(TestCase):
    def setUp(self):
        self.applicant = User.objects.create_user("app2", "a2@example.org", "pw")
        self.nsif = User.objects.create_user("nsif2", "n2@gov.za", "pw")
        self.nsif.groups.add(Group.objects.get(name=NSIF))

    def _submit(self, **extra):
        self.client.force_login(self.applicant)
        with self.captureOnCommitCallbacks(execute=True):
            r = self.client.post(reverse("dcpr:create", args=["E1"]), form_data(attach=False, **extra))
        self.assertEqual(r.status_code, 302, r.context and r.context["dataset_formset"].errors)
        return CaptureRequest.objects.latest("pk")

    def test_bundled_boundaries_loaded_with_hierarchy(self):
        self.assertEqual(Boundary.objects.filter(level="country").count(), 1)
        self.assertEqual(Boundary.objects.filter(level="ward").count(), 4392)
        self.assertFalse(Boundary.objects.exclude(level="country").filter(parent=None).exists())
        self.assertEqual(Boundary.objects.get(level="province", code="NC").name, "Northern Cape")  # source typo fixed
        ward = Boundary.objects.get(level="ward", name="Stellenbosch Ward 1")
        self.assertEqual(ward.parent.code, "WC024")
        self.assertEqual(ward.path, "Western Cape › Cape Winelands › Stellenbosch")
        self.assertEqual(Boundary.objects.filter(level="province").count(), 9)
        self.assertEqual(Boundary.objects.filter(level="district").count(), 52)
        self.assertEqual(Boundary.objects.filter(level="municipality").count(), 213)
        stb = Boundary.objects.get(level="municipality", name="Stellenbosch")
        self.assertEqual(stb.code, "WC024")
        self.assertEqual(stb.parent.name, "Cape Winelands")
        self.assertEqual(stb.parent.parent.code, "WC")
        self.assertEqual(Boundary.objects.get(level="district", code="CPT").kind_label, "Metropolitan municipality")
        self.assertAlmostEqual(stb.area_km2, 831, delta=40)   # official area ~831 km2

    def test_extent_from_boundary(self):
        req = self._submit()
        d = req.datasets[0]
        self.assertEqual([b.code for b in d.boundaries.all()], ["GT"])
        self.assertAlmostEqual(d.extent_area_km2, 18178, delta=900)   # Gauteng ~18 178 km2
        self.assertLess(d.extent_min_x, 28.0)

    def test_extent_from_bbox_and_boundary_union(self):
        stb = Boundary.objects.get(level="municipality", name="Stellenbosch")
        req = self._submit(**{"ds-0-boundary_ids": str(stb.pk),
                              "ds-0-extent_geojson": bbox_geojson(18.3, -34.0, 18.5, -33.8), "ds-0-extent_kind": "bbox"})
        d = req.datasets[0]
        self.assertEqual(d.custom_extent_kind, "bbox")
        self.assertAlmostEqual(d.extent_min_x, 18.3, places=3)
        self.assertAlmostEqual(d.extent_max_x, stb.max_x, places=3)
        self.assertGreater(d.extent_area_km2, stb.area_km2)

    def test_extent_required_and_validated(self):
        self.client.force_login(self.applicant)
        r = self.client.post(reverse("dcpr:create", args=["E1"]),
                             form_data(attach=False, **{"ds-0-boundary_ids": ""}))
        self.assertEqual(r.status_code, 200)
        self.assertIn("geographic extent", str(r.context["dataset_formset"].forms[0].non_field_errors()))
        r = self.client.post(reverse("dcpr:create", args=["E1"]), form_data(attach=False, **{
            "ds-0-boundary_ids": "", "ds-0-extent_geojson": bbox_geojson(2.0, 48.0, 2.5, 49.0)}))   # Paris
        self.assertIn("outside South Africa", str(r.context["dataset_formset"].forms[0].errors))
        r = self.client.post(reverse("dcpr:create", args=["E1"]), form_data(attach=False, **{
            "ds-0-boundary_ids": "", "ds-0-extent_geojson": "not json"}))
        self.assertIn("not valid GeoJSON", str(r.context["dataset_formset"].forms[0].errors))
        self.assertFalse(CaptureRequest.objects.exists())

    def test_ward_api_by_map_view(self):
        self.client.force_login(self.applicant)
        url = reverse("dcpr:api_boundaries_geojson")
        fc = self.client.get(url + "?level=ward&bbox=18.80,-34.00,18.95,-33.85").json()
        names = {f["properties"]["name"] for f in fc["features"]}
        self.assertTrue(any(n.startswith("Stellenbosch Ward") for n in names))
        self.assertLess(len(names), 200)
        self.assertTrue(self.client.get(url + "?level=ward&bbox=16,-35,33,-22").json()["too_large"])
        self.assertEqual(self.client.get(url + "?level=ward").status_code, 400)
        r = self.client.get(reverse("dcpr:api_boundaries") + "?q=Stellenbosch Ward 12").json()
        self.assertEqual(r["results"][0]["level"], "ward")
        country = self.client.get(reverse("dcpr:api_boundaries") + "?level=country").json()["results"]
        self.assertEqual(country[0]["name"], "South Africa")

    def test_ward_extent_overlap(self):
        w1 = Boundary.objects.get(level="ward", name="Stellenbosch Ward 1")
        a = self._submit(**{"ds-0-boundary_ids": str(w1.pk)})
        b = self._submit(**{"ds-0-boundary_ids": str(Boundary.objects.get(level="municipality", code="WC024").pk)})
        self.client.force_login(self.nsif)
        r = self.client.get(a.get_absolute_url())
        self.assertEqual([o["other_req"] for o in r.context["overlaps"]], [b])
        self.assertGreater(r.context["overlaps"][0]["share"], 95)

    def test_boundary_api(self):
        self.client.force_login(self.applicant)
        r = self.client.get(reverse("dcpr:api_boundaries") + "?q=stellen").json()
        self.assertEqual(r["results"][0]["name"], "Stellenbosch")
        self.assertIn("Cape Winelands", r["results"][0]["path"])
        fc = self.client.get(reverse("dcpr:api_boundaries_geojson") + "?level=province").json()
        self.assertEqual(len(fc["features"]), 9)
        ids = ",".join(str(i) for i in Boundary.objects.filter(level="district")[:3].values_list("pk", flat=True))
        fc = self.client.get(reverse("dcpr:api_boundaries_geojson") + "?ids=" + ids).json()
        self.assertEqual(len(fc["features"]), 3)
        self.client.logout()
        self.assertEqual(self.client.get(reverse("dcpr:api_boundaries")).status_code, 302)

    def test_spatial_search_and_overlaps(self):
        gp = self._submit()                                              # Gauteng
        wc = self._submit(**{"ds-0-boundary_ids": str(Boundary.objects.get(level="municipality", name="Stellenbosch").pk),
                             "ds-0-data_types": ["PO"]})                 # Western Cape
        jhb = Boundary.objects.get(level="municipality", name__icontains="Johannesburg")
        ov = self._submit(**{"ds-0-boundary_ids": str(jhb.pk)})          # inside Gauteng
        self.client.force_login(self.nsif)
        url = reverse("dcpr:search")
        # by boundary
        wcp = Boundary.objects.get(level="province", code="WC")
        r = self.client.get(url, {"boundary_ids": wcp.pk, "mode": "intersects"})
        self.assertEqual([d.project.capture_request for d in r.context["results"]], [wc])
        # by bounding box around Johannesburg
        r = self.client.get(url, {"extent_geojson": bbox_geojson(27.9, -26.3, 28.1, -26.1), "mode": "intersects"})
        self.assertEqual({d.project.capture_request for d in r.context["results"]}, {gp, ov})
        # 'within' Gauteng excludes nothing in Gauteng but excludes Western Cape
        gpb = Boundary.objects.get(level="province", code="GT")
        r = self.client.get(url, {"boundary_ids": gpb.pk, "mode": "within"})
        self.assertEqual({d.project.capture_request for d in r.context["results"]}, {gp, ov})
        # attribute filter combined
        r = self.client.get(url, {"data_type": "PO", "mode": "intersects"})
        self.assertEqual([d.project.capture_request for d in r.context["results"]], [wc])
        # overlap check on the detail page
        r = self.client.get(gp.get_absolute_url())
        self.assertEqual([o["other_req"] for o in r.context["overlaps"]], [ov])
        self.assertContains(r, "Overlapping capture requests")
        # applicants cannot use spatial search
        self.client.force_login(self.applicant)
        self.assertEqual(self.client.get(url).status_code, 403)

    def test_print_has_map_and_csv_has_bbox(self):
        req = self._submit()
        self.client.force_login(self.nsif)
        self.assertContains(self.client.get(reverse("dcpr:print", args=[req.pk])), "<svg")
        csv_text = self.client.get(reverse("dcpr:register") + "?export=csv").content.decode()
        self.assertIn("Gauteng", csv_text)
        self.assertIn("Bbox west", csv_text)
        self.assertEqual(self.client.get(reverse("dcpr:report")).status_code, 200)

    def test_deleting_request_removes_project_and_pages_still_work(self):
        a = self._submit()
        b = self._submit()
        pid = a.project_id
        a.delete()
        self.assertFalse(Project.objects.filter(pk=pid).exists())
        self.client.force_login(self.nsif)
        self.assertEqual(self.client.get(b.get_absolute_url()).status_code, 200)
        self.assertEqual(self.client.get(reverse("dcpr:search") + "?q=roads&mode=intersects").status_code, 200)

    def test_load_custom_boundaries_command(self):
        import os, tempfile
        path = _write_geojson([("Ward 115", "79800115", "JHB", [28.0, -26.2, 28.05, -26.15])],
                              name_field="WARD", code_field="WID", parent_field="MUNIC")
        call_command("load_boundaries", path, "--level", "other", "--name-field", "WARD", "--code-field", "WID",
                     "--mode", "update", stdout=open(os.devnull, "w"))
        b = Boundary.objects.get(level="other", code="79800115")
        self.assertEqual(b.name, "Ward 115")
        self.assertGreater(b.area_km2, 0)


def _write_geojson(rows, name_field="DISTRICT_N", code_field="DISTRICT", parent_field="PROVINCE", crs=None,
                   extra=None):
    """rows: (name, code, parent, [w, s, e, n])."""
    import os, tempfile
    feats = []
    for name, code, parent, (w, s_, e, n) in rows:
        props = {name_field: name, code_field: code, parent_field: parent, "CATEGORY": "C"}
        props.update(extra or {})
        feats.append({"type": "Feature", "properties": props, "geometry": {"type": "Polygon",
                      "coordinates": [[[w, s_], [e, s_], [e, n], [w, n], [w, s_]]]}})
    fc = {"type": "FeatureCollection", "features": feats}
    if crs:
        fc["crs"] = {"type": "name", "properties": {"name": crs}}
    path = os.path.join(tempfile.mkdtemp(), "boundaries.geojson")
    with open(path, "w") as fh:
        _json.dump(fc, fh)
    return path


@override_settings(MEDIA_ROOT=MEDIA)
class BoundaryUploadTests(TestCase):
    """Administrator uploads and updates of the boundary dataset."""
    from . import boundaries as bi

    def test_bundled_reimport_is_idempotent(self):
        from . import boundaries as bi
        path = [b[0] for b in bi.BUNDLED if b[1] == "municipality"][0]
        res = bi.import_file(Boundary, path, "municipality", tolerance=0)
        self.assertEqual((res.features, res.created, res.updated, res.retired), (213, 0, 213, 0))

    def test_dry_run_changes_nothing(self):
        from . import boundaries as bi
        before = Boundary.objects.count()
        path = _write_geojson([("New District", "DC99", "WC", [19.0, -33.5, 19.5, -33.0])])
        res = bi.import_file(Boundary, path, "district", mode="update", dry_run=True)
        self.assertEqual(res.created, 1)
        self.assertEqual(Boundary.objects.count(), before)

    def test_update_vs_replace(self):
        from . import boundaries as bi
        path = _write_geojson([("Cape Winelands (redrawn)", "DC2", "WC", [19.0, -33.9, 19.6, -33.3]),
                               ("New District", "DC99", "WC", [20.0, -33.5, 20.5, -33.0])])
        res = bi.import_file(Boundary, path, "district", mode="update")
        self.assertEqual((res.created, res.updated, res.retired), (1, 1, 0))
        dc2 = Boundary.objects.get(level="district", code="DC2")
        self.assertEqual(dc2.name, "Cape Winelands (redrawn)")
        self.assertEqual(dc2.parent.code, "WC")
        # Stellenbosch still points at the same (updated) district record
        self.assertEqual(Boundary.objects.get(level="municipality", code="WC024").parent_id, dc2.pk)
        res = bi.import_file(Boundary, path, "district", mode="replace")
        self.assertEqual(res.retired, 51)   # 52 bundled + 1 added above, minus the 2 in the file
        self.assertEqual(Boundary.objects.filter(level="district", is_active=True).count(), 2)
        self.assertTrue(any("point to a retired district" in w for w in res.warnings))

    def test_derive_provinces(self):
        from . import boundaries as bi
        path = _write_geojson([("A", "DCA", "WC", [18.0, -34.0, 19.0, -33.0]),
                               ("B", "DCB", "WC", [19.0, -34.0, 20.0, -33.0])])
        res = bi.import_file(Boundary, path, "district", mode="update", derive_provinces=True)
        self.assertEqual(res.derived, 1)
        wc = Boundary.objects.get(level="province", code="WC")
        self.assertEqual(wc.name, "Western Cape")
        self.assertAlmostEqual(wc.min_x, 18.0, places=2)
        self.assertAlmostEqual(wc.max_x, 20.0, places=2)

    def test_ocha_cod_ab_preset_and_name_pattern(self):
        from . import boundaries as bi
        path = _write_geojson([("007", "ZA1024007", "WC024", [18.85, -33.95, 18.9, -33.9])],
                              name_field="adm4_name", code_field="adm4_pcode", parent_field="adm3_id",
                              extra={"adm3_name": "Stellenbosch"})
        res = bi.import_file(Boundary, path, "ward", mode="update")
        self.assertIn("{adm3_name} Ward {adm4_name:int}", res.text)
        w = Boundary.objects.get(level="ward", code="ZA1024007")
        self.assertEqual((w.name, w.parent.code), ("Stellenbosch Ward 7", "WC024"))
        # OCHA files have no CATEGORY: metros are inferred from their codes
        self.assertEqual(bi.infer_category("district", "CPT", ""), "A")
        self.assertEqual(bi.infer_category("district", "DC44", ""), "C")
        self.assertEqual(bi.infer_category("municipality", "KZN263", ""), "B")
        self.assertEqual(bi.infer_category("municipality", "JHB", ""), "A")
        self.assertEqual(bi.infer_category("municipality", "JHB", "B"), "B")   # file value wins

    def test_validation_errors(self):
        from . import boundaries as bi
        bad_crs = _write_geojson([("A", "DCA", "WC", [18.0, -34.0, 19.0, -33.0])], crs="EPSG:2048")
        with self.assertRaisesRegex(bi.BoundaryImportError, "coordinate system"):
            bi.import_file(Boundary, bad_crs, "district")
        wrong_fields = _write_geojson([("A", "DCA", "WC", [18.0, -34.0, 19.0, -33.0])],
                                      name_field="FOO", code_field="BAR")
        with self.assertRaisesRegex(bi.BoundaryImportError, "Fields in this file: BAR, CATEGORY, FOO"):
            bi.import_file(Boundary, wrong_fields, "district")
        dupes = _write_geojson([("A", "DCA", "WC", [18.0, -34.0, 19.0, -33.0]),
                                ("B", "DCA", "WC", [19.0, -34.0, 20.0, -33.0])])
        with self.assertRaisesRegex(bi.BoundaryImportError, "duplicate code DCA"):
            bi.import_file(Boundary, dupes, "district")
        outside = _write_geojson([("Paris", "P1", "FR", [2.0, 48.0, 2.5, 49.0])])
        with self.assertRaisesRegex(bi.BoundaryImportError, "outside South Africa"):
            bi.import_file(Boundary, outside, "district")

    def test_admin_upload_validate_then_import(self):
        from django.core.files.uploadedfile import SimpleUploadedFile
        admin_user = User.objects.create_superuser("root", "r@gov.za", "pw")
        self.client.force_login(admin_user)
        path = _write_geojson([("Overstrand (2026)", "WC032", "DC3", [19.2, -34.7, 19.9, -34.2])],
                              name_field="MUNICNAME", code_field="CAT_B", parent_field="DISTRICT")
        data = {"title": "MDB local municipalities 2026 (test)", "level": "municipality",
                "source": "MDB", "mode": "update", "run": "validate",
                "file": SimpleUploadedFile("lm.geojson", open(path, "rb").read(), "application/geo+json")}
        r = self.client.post(reverse("admin:dcpr_boundarydataset_add"), data, follow=True)
        self.assertEqual(r.status_code, 200)
        up = BoundaryDataset.objects.get(title__contains="2026 (test)")
        self.assertEqual(up.status, "validated")
        self.assertEqual(up.updated_count, 1)
        self.assertEqual(Boundary.objects.get(level="municipality", code="WC032").name, "Overstrand")
        r = self.client.post(reverse("admin:dcpr_boundarydataset_changelist"),
                             {"action": "import_selected", "_selected_action": [up.pk]}, follow=True)
        up.refresh_from_db()
        self.assertEqual(up.status, "loaded")
        b = Boundary.objects.get(level="municipality", code="WC032")
        self.assertEqual((b.name, b.dataset_id, b.parent.code), ("Overstrand (2026)", up.pk, "DC3"))
        r = self.client.get(reverse("admin:dcpr_boundarydataset_change", args=[up.pk]))
        self.assertContains(r, "1 updated")

