"""Email backend used when no SMTP server is configured.

Instead of sending, it writes each message to the server log (on PythonAnywhere:
Web tab → Server log), so a pilot can run without email and nothing is lost silently.
"""
import logging

from django.core.mail.backends.base import BaseEmailBackend

logger = logging.getLogger("dcpr.mail")


class LoggingEmailBackend(BaseEmailBackend):
    def send_messages(self, email_messages):
        for m in email_messages:
            logger.warning("EMAIL NOT SENT (no SMTP configured)\nTo: %s\nSubject: %s\n\n%s",
                           ", ".join(m.to), m.subject, m.body)
        return len(email_messages)
