import csv
import json
from collections import Counter

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.db.models import Q, Sum
from django.core.cache import cache
from django.http import FileResponse, Http404, HttpResponse, JsonResponse
from django.utils.safestring import mark_safe
from shapely.geometry import shape
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from . import geo, workflow
from .forms import (
    ActionForm, AttachmentFormSet, ContactForm, DatasetFormSet, OrganisationForm, ProjectForm,
    RegisterFilterForm, RequestForm, SignUpForm, SpatialSearchForm, SupplementaryUploadForm,
)
from .models import Attachment, Boundary, CaptureRequest, ContactPerson, Dataset, Project
from .roles import CHAIRPERSON, NSIF, SUBCOMMITTEE, can_view_request, has_role, is_office

S = CaptureRequest.Status

# Documents the applicant may see. Internal documents (adjudication pack, draft
# letters) are office-only; the signed letter is released once they are notified.
APPLICANT_VISIBLE = set(Attachment.APPLICANT_CATEGORIES) | {"ack"}
RELEASED_STATUSES = {S.APPLICANT_NOTIFIED, S.CLOSED}


def office_required(view):
    @login_required
    def wrapper(request, *args, **kwargs):
        if not is_office(request.user):
            raise PermissionDenied
        return view(request, *args, **kwargs)
    wrapper.__name__ = view.__name__
    return wrapper


def _base_qs():
    return CaptureRequest.objects.select_related(
        "project__submitted_by__organisation", "applicant"
    ).prefetch_related("project__datasets__boundaries__parent")


def _get_viewable(request, pk):
    req = get_object_or_404(_base_qs(), pk=pk)
    if not can_view_request(request.user, req):
        raise PermissionDenied
    if req.status == S.DRAFT and req.applicant_id != request.user.pk:
        raise Http404
    return req


def visible_attachments(user, req):
    qs = req.attachments.select_related("uploaded_by")
    if is_office(user):
        return qs
    cats = set(APPLICANT_VISIBLE)
    if req.status in RELEASED_STATUSES:
        cats.add("signed_letter")
    return qs.filter(category__in=cats)


# --------------------------------------------------------------------------- #
# Accounts
# --------------------------------------------------------------------------- #
def signup(request):
    if request.user.is_authenticated:
        return redirect("dcpr:dashboard")
    form = SignUpForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Your account has been created.")
        return redirect("dcpr:dashboard")
    return render(request, "registration/signup.html", {"form": form})


# --------------------------------------------------------------------------- #
# Dashboard
# --------------------------------------------------------------------------- #
@login_required
def dashboard(request):
    user = request.user
    mine = _base_qs().filter(applicant=user)
    to_amend = mine.filter(status=S.RETURNED)
    queues = []
    if has_role(user, NSIF):
        queues.append(("Awaiting acknowledgement", _base_qs().filter(status=S.SUBMITTED)))
        queues.append(("Acknowledged – assess / file", _base_qs().filter(status=S.ACKNOWLEDGED)))
        queues.append(("Letter signed – notify applicant", _base_qs().filter(status=S.LETTER_SIGNED)))
        queues.append(("Applicant notified – scan & file", _base_qs().filter(status=S.APPLICANT_NOTIFIED)))
        queues.append(("Referred back – awaiting applicant's amendments", _base_qs().filter(status=S.RETURNED)))
    if has_role(user, SUBCOMMITTEE):
        queues.append(("For adjudication", _base_qs().filter(status=S.IN_ADJUDICATION)))
    if has_role(user, CHAIRPERSON):
        queues.append(("Letters awaiting your signature", _base_qs().filter(status=S.AWAITING_SIGNATURE)))
    stats = None
    if is_office(user):
        live = CaptureRequest.objects.exclude(status=S.DRAFT)
        stats = {
            "total": live.count(),
            "open": live.exclude(status=S.CLOSED).count(),
            "approved": live.filter(outcome="approved").count(),
            "rejected": live.filter(outcome="rejected").count(),
        }
    return render(request, "dcpr/dashboard.html", {
        "mine": mine, "to_amend": to_amend, "queues": queues, "stats": stats,
    })


# --------------------------------------------------------------------------- #
# Create / edit Form E1 / E2
# --------------------------------------------------------------------------- #
def _initial_for(user):
    last = ContactPerson.objects.filter(user=user).select_related("organisation").last()
    if last:
        org = last.organisation
        return (
            {"name": org.name, "level": org.level, "address": org.address},
            {"name": last.name, "designation": last.designation, "phone_number": last.phone_number,
             "fax_number": last.fax_number, "email": last.email},
        )
    return {}, {"name": user.get_full_name(), "email": user.email}


def _resolve_contact(org, contact_form, user):
    d = contact_form.cleaned_data
    contact, _ = ContactPerson.objects.update_or_create(
        organisation=org, email__iexact=d["email"],
        defaults={**d, "organisation": org, "user": user},
    )
    return contact


@login_required
def request_form(request, form_type=None, pk=None):
    if pk:
        req = get_object_or_404(_base_qs(), pk=pk, applicant=request.user)
        if not req.is_editable:
            messages.error(request, "This request is being processed and can no longer be edited.")
            return redirect(req)
        form_type = req.form_type
        project = req.project
        org = req.organisation
        org_initial = {"name": org.name, "level": org.level, "address": org.address}
        contact_instance = req.contact
        contact_initial = None
    else:
        if form_type not in CaptureRequest.FormType.values:
            raise Http404
        req = project = contact_instance = None
        org_initial, contact_initial = _initial_for(request.user)

    data = request.POST if request.method == "POST" else None
    files = request.FILES if request.method == "POST" else None
    submitting = data is not None and data.get("action") == "submit"

    org_form = OrganisationForm(data, prefix="org", initial=org_initial)
    contact_form = ContactForm(data, prefix="contact", instance=contact_instance, initial=contact_initial)
    project_form = ProjectForm(data, prefix="project", instance=project)
    dataset_formset = DatasetFormSet(data, instance=project or Project(), prefix="ds")
    request_form_ = RequestForm(
        data, prefix="req", instance=req, submitting=submitting,
        initial=None if req else {"declarant_name": contact_initial.get("name", ""),
                                   "declarant_designation": contact_initial.get("designation", "")},
    )
    att_formset = AttachmentFormSet(data, files, instance=req or CaptureRequest(), prefix="att", user=request.user)
    forms_ = [org_form, contact_form, project_form, request_form_, dataset_formset, att_formset]

    was_returned = bool(req and req.is_returned)
    if request.method == "POST":
        if all([f.is_valid() for f in forms_]):
            with transaction.atomic():
                org = org_form.save()
                contact = _resolve_contact(org, contact_form, request.user)
                project = project_form.save(commit=False)
                project.submitted_by = contact
                project.save()
                dataset_formset.instance = project
                dataset_formset.save()
                req = request_form_.save(commit=False)
                req.form_type = form_type
                req.applicant = request.user
                req.project = project
                req.save()
                att_formset.instance = req
                att_formset.save()
                if not pk:
                    workflow.log(req, "create", "Draft created", "", request.user)
                if submitting:
                    workflow.submit(req, request.user)
            if submitting and was_returned:
                messages.success(request, f"Amended {req.noun} submitted. {req.reference_number} is back with NSIF.")
            elif submitting:
                messages.success(request, f"{req.Noun} submitted. Your reference number is {req.reference_number}.")
            else:
                messages.success(request, "Draft saved. You can come back to add documents before submitting.")
            return redirect(req)
        messages.error(request, "Please correct the highlighted fields below.")

    return render(request, "dcpr/request_form.html", {
        "form_type": form_type,
        "form_type_label": CaptureRequest.FormType(form_type).label,
        "req": req,
        "referral": req.last_referral if was_returned else None,
        "org_form": org_form, "contact_form": contact_form, "project_form": project_form,
        "dataset_formset": dataset_formset, "request_form": request_form_, "formset": att_formset,
        "max_mb": settings.ATTACHMENT_MAX_SIZE_MB,
        "map_config": map_config(),
    })


@login_required
@require_POST
def request_delete(request, pk):
    req = get_object_or_404(CaptureRequest, pk=pk, applicant=request.user, status=S.DRAFT)
    project = req.project
    for a in req.attachments.all():
        a.file.delete(save=False)
    project.delete()  # cascades to request, dataset, attachments
    messages.success(request, "Draft deleted.")
    return redirect("dcpr:dashboard")


# --------------------------------------------------------------------------- #
# Detail / actions
# --------------------------------------------------------------------------- #
@login_required
def request_detail(request, pk):
    req = _get_viewable(request, pk)
    office = is_office(request.user)
    transitions = workflow.available_transitions(req, request.user)
    actions = [(t, t.label_for(req), t.help_for(req), ActionForm(transition=t, req=req, prefix=t.name))
               for t in transitions]
    # "Waiting on" lists the next required step(s); refer-back is optional so it is left out.
    waiting = [(", ".join(t.roles_for(req)), t.label_for(req))
               for t in workflow.pending_transitions(req) if t.name != "refer_back"]
    events = req.events.select_related("actor")
    upload_form = None
    if _can_upload_supplementary(request.user, req):
        cats = list(Attachment.APPLICANT_CATEGORIES) if not office else [c for c, _ in Attachment.Category.choices]
        upload_form = SupplementaryUploadForm(categories=cats)
    return render(request, "dcpr/request_detail.html", {
        "req": req, "dataset": req.dataset, "office": office,
        "attachments": visible_attachments(request.user, req),
        "actions": actions, "waiting": waiting, "events": events,
        "upload_form": upload_form, "steps": _progress(req),
        "referral": req.last_referral if req.is_returned else None,
        "extents": _extents_collection(req.datasets),
        "overlaps": _overlaps(req) if office and req.status != S.DRAFT else None,
        "map_config": map_config(),
    })


def _overlaps(req):
    """Other submitted requests whose dataset extents intersect this request's datasets."""
    others = Dataset.objects.filter(project__capture_request__isnull=False).exclude(
        project=req.project).exclude(project__capture_request__status=S.DRAFT
    ).select_related("project__capture_request")
    rows = []
    for d in req.datasets:
        for other, km2, share in geo.overlapping_datasets(d, others):
            rows.append({"dataset": d, "other": other, "other_req": other.project.capture_request,
                         "km2": km2, "share": share})
    return rows


def _progress(req):
    """Steps for the progress tracker shown on the detail page."""
    # Form E1 and Form E2 follow the same steps.
    steps = [
        (S.SUBMITTED, "Submitted"), (S.ACKNOWLEDGED, "Acknowledged"),
        (S.IN_ADJUDICATION, "Adjudication"), (S.AWAITING_SIGNATURE, "Signature"),
        (S.LETTER_SIGNED, "Signed"), (S.APPLICANT_NOTIFIED, "Notified"), (S.CLOSED, "Filed"),
    ]
    order = [s for s, _ in steps]
    if req.status == S.RETURNED:
        # Show where it was referred back from, flagged as "returned".
        current = order.index(req.returned_from) if req.returned_from in order else 0
        return [
            {"label": "Referred back" if i == current else label,
             "state": "done" if i < current else "returned" if i == current else "todo"}
            for i, (_, label) in enumerate(steps)
        ]
    current = order.index(req.status) if req.status in order else -1
    return [
        {"label": label, "state": "done" if i < current or req.status == S.CLOSED
         else "current" if i == current else "todo"}
        for i, (_, label) in enumerate(steps)
    ]


def _can_upload_supplementary(user, req):
    if is_office(user):
        return req.status != S.DRAFT
    # Applicants may add supporting documents until adjudication starts.
    return req.applicant_id == user.pk and req.status in (S.SUBMITTED, S.ACKNOWLEDGED, S.RETURNED)


@login_required
@require_POST
def request_action(request, pk, name):
    req = _get_viewable(request, pk)
    t = workflow.TRANSITIONS.get(name)
    if t is None:
        raise Http404
    form = ActionForm(request.POST, request.FILES, transition=t, req=req, prefix=name)
    if not form.is_valid():
        for field, errs in form.errors.items():
            for e in errs:
                messages.error(request, f"{form.fields[field].label if field in form.fields else ''}: {e}")
        return redirect(req)
    try:
        workflow.perform(
            req, name, request.user,
            comment=form.cleaned_data.get("comment", ""),
            files=form.cleaned_data.get("files") or [],
            file_reference=form.cleaned_data.get("file_reference", ""),
        )
    except workflow.TransitionError as e:
        messages.error(request, str(e))
    else:
        messages.success(request, f"Done: {t.label_for(req)}.")
    return redirect(req)


@login_required
@require_POST
def attachment_upload(request, pk):
    req = _get_viewable(request, pk)
    if not _can_upload_supplementary(request.user, req):
        raise PermissionDenied
    cats = list(Attachment.APPLICANT_CATEGORIES) if not is_office(request.user) else None
    form = SupplementaryUploadForm(request.POST, request.FILES, categories=cats)
    if form.is_valid():
        for f in form.cleaned_data["files"]:
            Attachment.objects.create(
                request=req, category=form.cleaned_data["category"], file=f,
                description=form.cleaned_data["description"], uploaded_by=request.user,
            )
        n = len(form.cleaned_data["files"])
        workflow.log(req, "upload", f"{n} supporting document{'s' if n != 1 else ''} added",
                     req.status, request.user)
        messages.success(request, "Document(s) uploaded.")
    else:
        for errs in form.errors.values():
            for e in errs:
                messages.error(request, e)
    return redirect(req)


@login_required
def download_attachment(request, pk):
    att = get_object_or_404(Attachment.objects.select_related("request"), pk=pk)
    req = att.request
    if not can_view_request(request.user, req):
        raise PermissionDenied
    if not visible_attachments(request.user, req).filter(pk=att.pk).exists():
        raise PermissionDenied
    try:
        fh = att.file.open("rb")
    except FileNotFoundError:
        raise Http404("File missing from storage.")
    inline = request.GET.get("inline") == "1"
    return FileResponse(fh, as_attachment=not inline, filename=att.original_name)


@login_required
def request_print(request, pk):
    req = _get_viewable(request, pk)
    provinces = [shape(b.display_geometry) for b in Boundary.objects.filter(level="province")]
    maps = {}
    for d in req.datasets:
        if d.extent_geometry:
            g = shape(d.extent_geometry)
            near = [p for p in provinces if p.intersects(g.buffer(0.5))]
            layers = [(p, "ctx") for p in near] + [(g, "ext")]
            maps[d.pk] = mark_safe(geo.svg_map(layers, width=300, height=210))
    return render(request, "dcpr/request_print.html", {
        "req": req, "dataset": req.dataset,
        "attachments": visible_attachments(request.user, req),
        "maps": maps,
    })


# --------------------------------------------------------------------------- #
# Register & CSI feedback report
# --------------------------------------------------------------------------- #
def _filtered_register(request):
    form = RegisterFilterForm(request.GET or None)
    qs = _base_qs().exclude(status=S.DRAFT)
    if form.is_valid():
        d = form.cleaned_data
        if d["q"]:
            q = d["q"]
            qs = qs.filter(
                Q(reference_number__icontains=q) | Q(project__name__icontains=q)
                | Q(project__datasets__title__icontains=q)
                | Q(project__submitted_by__organisation__name__icontains=q)
            ).distinct()
        if d["form_type"]:
            qs = qs.filter(form_type=d["form_type"])
        if d["status"]:
            qs = qs.filter(status=d["status"])
        if d["outcome"] == "pending":
            qs = qs.filter(outcome="")
        elif d["outcome"]:
            qs = qs.filter(outcome=d["outcome"])
        if d["urgency"]:
            qs = qs.filter(urgency=d["urgency"])
        if d["date_from"]:
            qs = qs.filter(submitted_at__date__gte=d["date_from"])
        if d["date_to"]:
            qs = qs.filter(submitted_at__date__lte=d["date_to"])
    return form, qs


@office_required
def register(request):
    form, qs = _filtered_register(request)
    if request.GET.get("export") == "csv":
        return _register_csv(qs)
    return render(request, "dcpr/register.html", {"form": form, "rows": qs, "querystring": request.GET.urlencode()})


def _register_csv(qs):
    resp = HttpResponse(content_type="text/csv")
    resp["Content-Disposition"] = (
        f'attachment; filename="spatial-data-capture-register-{timezone.localdate():%Y%m%d}.csv"'
    )
    w = csv.writer(resp)
    w.writerow([
        "Reference", "Form", "Status", "Outcome", "Urgency", "Organisation", "Level",
        "Contact", "Email", "Project", "Dataset no.", "Dataset", "Area of interest", "Area (km2)",
        "Bbox west", "Bbox south", "Bbox east", "Bbox north", "Geographic extent level", "Data type",
        "Method of capture", "Start", "End", "Estimated cost (ZAR)", "Usage restrictions",
        "Submitted", "Closed", "Filing reference",
    ])
    # One row per dataset, so projects producing several datasets are fully listed.
    for r in qs:
        c = r.contact
        datasets = list(r.datasets) or [None]
        for i, d in enumerate(datasets, 1):
            w.writerow([
                r.reference_number, r.form_type, r.get_status_display(), r.get_outcome_display(),
                r.get_urgency_display(), c.organisation.name, c.organisation.get_level_display(),
                c.name, c.email, r.project.name, f"{i} of {len(datasets)}" if d else "",
                d.title if d else "",
                "; ".join([b.name for b in d.boundaries.all()] + ([d.get_custom_extent_kind_display()] if d.custom_extent else [])) if d else "",
                d.extent_area_km2 if d else "",
                *([round(v, 5) for v in d.extent_bbox] if d and d.extent_bbox else ["", "", "", ""]),
                d.geographic_extent_display if d else "",
                d.data_type_display if d else "", d.capture_method_display if d else "",
                r.project.start_date, r.project.end_date,
                r.project.estimated_cost, r.get_data_usage_restrictions_display(),
                timezone.localtime(r.submitted_at).strftime("%Y-%m-%d %H:%M") if r.submitted_at else "",
                timezone.localtime(r.closed_at).strftime("%Y-%m-%d %H:%M") if r.closed_at else "",
                r.file_reference,
            ])
    return resp


@office_required
def report(request):
    """Chairperson's feedback to CSI on all spatial data capture project requests."""
    form, qs = _filtered_register(request)
    rows = list(qs)
    by_status = Counter(r.get_status_display() for r in rows)
    by_outcome = Counter(r.get_outcome_display() for r in rows)
    by_form = Counter(r.form_type for r in rows)
    by_level = Counter(r.organisation.get_level_display() for r in rows)
    datasets = [d for r in rows for d in r.datasets]
    by_method = Counter(label for d in datasets for label in d.capture_method_labels)
    by_type = Counter(label for d in datasets for label in d.data_type_labels)
    # Datasets per province, by spatial intersection of their extents
    by_province = Counter()
    provinces = [(b.name, shape(b.geometry)) for b in Boundary.objects.filter(level="province")]
    for d in datasets:
        if d.extent_geometry:
            g = shape(d.extent_geometry)
            for name, pg in provinces:
                if pg.intersects(g):
                    by_province[name] += 1
    total_cost = qs.aggregate(t=Sum("project__estimated_cost"))["t"] or 0
    approved_cost = qs.filter(outcome="approved").aggregate(t=Sum("project__estimated_cost"))["t"] or 0
    decided = [r for r in rows if r.closed_at and r.submitted_at]
    avg_days = (
        sum((r.closed_at - r.submitted_at).days for r in decided) / len(decided) if decided else None
    )
    return render(request, "dcpr/report.html", {
        "form": form, "rows": rows, "total": len(rows),
        "by_status": by_status.most_common(), "by_outcome": by_outcome.most_common(),
        "by_form": sorted(by_form.items()), "by_level": by_level.most_common(),
        "by_method": by_method.most_common(), "by_type": by_type.most_common(),
        "by_province": by_province.most_common(),
        "ds_total": len(datasets), "total_cost": total_cost,
        "approved_cost": approved_cost, "avg_days": avg_days, "generated": timezone.now(),
    })


# --------------------------------------------------------------------------- #
# Geospatial: map config, boundary APIs, spatial search
# --------------------------------------------------------------------------- #
def map_config():
    cfg = dict(getattr(settings, "DCPR_MAP", {}))
    from django.urls import reverse
    cfg["api"] = {"boundaries": reverse("dcpr:api_boundaries"),
                  "geojson": reverse("dcpr:api_boundaries_geojson")}
    return cfg


def _extents_collection(datasets):
    feats = []
    for i, d in enumerate(datasets):
        if d.extent_geometry:
            feats.append({"type": "Feature", "geometry": d.extent_geometry, "properties": {
                "index": i, "title": d.title,
                "boundaries": [b.name for b in d.boundaries.all()],
                "custom": bool(d.custom_extent), "area_km2": d.extent_area_km2,
            }})
    return {"type": "FeatureCollection", "features": feats}


def _boundary_json(b):
    return {"id": b.pk, "name": b.name, "code": b.code, "level": b.level,
            "level_label": b.kind_label, "path": b.path,
            "bbox": [round(v, 5) for v in b.bbox], "area_km2": round(b.area_km2)}


def _label_point(b):
    """A point inside the boundary for placing its name on the map."""
    try:
        p = shape(b.display_geometry).representative_point()
        return [round(p.x, 4), round(p.y, 4)]
    except Exception:
        return [round((b.min_x + b.max_x) / 2, 4), round((b.min_y + b.max_y) / 2, 4)]


@login_required
def api_boundaries(request):
    """Search/list boundaries: ?q=stellen  ?level=district  ?parent=<id>"""
    qs = Boundary.objects.filter(is_active=True).select_related("parent__parent__parent__parent")
    q = request.GET.get("q", "").strip()
    level = request.GET.get("level")
    if level:
        qs = qs.filter(level=level)
    if request.GET.get("parent"):
        qs = qs.filter(parent_id=request.GET["parent"])
    if q:
        starts = list(qs.filter(name__istartswith=q)[:20])
        rest = list(qs.filter(name__icontains=q).exclude(pk__in=[b.pk for b in starts])[:20])
        found = sorted(starts, key=lambda b: (Boundary.LEVEL_ORDER[b.level], b.name)) + rest
        found = found[:25]
    else:
        found = list(qs[:500])
    return JsonResponse({"results": [_boundary_json(b) for b in found]})


@login_required
def api_boundaries_geojson(request):
    """Display geometries: ?level=province|district|municipality  or  ?ids=1,2,3"""
    ids = [int(x) for x in request.GET.get("ids", "").split(",") if x.strip().isdigit()]
    level = request.GET.get("level")
    key = None
    if ids:
        qs = Boundary.objects.filter(pk__in=ids)
    elif level == "ward" or (level in Boundary.LEVEL_ORDER and request.GET.get("bbox")):
        # Wards are only served for the area on screen (there are ~4 400 nationally).
        try:
            w, s_, e, n = [float(v) for v in request.GET.get("bbox", "").split(",")]
        except ValueError:
            return JsonResponse({"error": "Pass bbox=west,south,east,north."}, status=400)
        if level == "ward" and (e - w) * (n - s_) > 4.0:
            return JsonResponse({"type": "FeatureCollection", "features": [], "too_large": True})
        qs = Boundary.objects.filter(level=level, is_active=True).filter(geo.bbox_overlap_q("", (w, s_, e, n)))[:2500]
    elif level in Boundary.LEVEL_ORDER:
        key = f"dcpr:boundaries:{level}:{Boundary.objects.filter(level=level).count()}:{Boundary.objects.filter(level=level).order_by('-pk').values_list('pk', flat=True).first()}"
        cached = cache.get(key)
        if cached:
            resp = HttpResponse(cached, content_type="application/json")
            resp["Cache-Control"] = "private, max-age=3600"
            return resp
        qs = Boundary.objects.filter(level=level, is_active=True)
    else:
        return JsonResponse({"error": "Pass level or ids."}, status=400)
    qs = qs.select_related("parent__parent")
    data = json.dumps({"type": "FeatureCollection", "features": [
        {"type": "Feature", "id": b.pk, "geometry": b.display_geometry, "properties": {
            "id": b.pk, "name": b.name, "level": b.level, "level_label": b.kind_label,
            "path": b.path, "label": _label_point(b)}} for b in qs]}, separators=(",", ":"))
    if key:
        cache.set(key, data, 3600)
    resp = HttpResponse(data, content_type="application/json")
    resp["Cache-Control"] = "private, max-age=3600"
    return resp


@office_required
def spatial_search(request):
    form = SpatialSearchForm(request.GET or None)
    results, area, searched = [], None, False
    if form.is_valid() and any(request.GET.get(k) for k in
                               ("q", "boundary_ids", "extent_geojson", "form_type", "status",
                                "data_type", "capture_method")):
        searched = True
        d = form.cleaned_data
        qs = Dataset.objects.filter(project__capture_request__isnull=False).exclude(
            project__capture_request__status=S.DRAFT).select_related(
            "project__capture_request", "project__submitted_by__organisation").prefetch_related("boundaries")
        if d["q"]:
            q = d["q"]
            qs = qs.filter(Q(title__icontains=q) | Q(project__name__icontains=q)
                           | Q(project__capture_request__reference_number__icontains=q)
                           | Q(project__submitted_by__organisation__name__icontains=q))
        if d["form_type"]:
            qs = qs.filter(project__capture_request__form_type=d["form_type"])
        if d["status"]:
            qs = qs.filter(project__capture_request__status=d["status"])
        area = form.search_area()
        datasets = geo.filter_datasets(qs, area, d.get("mode") or "intersects")
        # JSON list filters are applied in Python so they work on every database backend.
        if d["data_type"]:
            datasets = [x for x in datasets if d["data_type"] in (x.data_types or [])]
        if d["capture_method"]:
            datasets = [x for x in datasets if d["capture_method"] in (x.capture_methods or [])]
        results = datasets
    feats = []
    for i, ds in enumerate(results):
        if ds.extent_geometry:
            r = ds.project.capture_request
            feats.append({"type": "Feature", "geometry": ds.extent_geometry, "properties": {
                "index": i, "title": ds.title, "ref": r.reference_number, "project": r.project.name,
                "status": r.status_label, "url": r.get_absolute_url()}})
    return render(request, "dcpr/search.html", {
        "form": form, "results": results, "searched": searched,
        "result_extents": {"type": "FeatureCollection", "features": feats},
        "search_area": geo.to_geojson(area) if area is not None else None,
        "map_config": map_config(),
    })
