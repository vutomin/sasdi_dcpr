"""Load the bundled boundaries: country, provinces and wards (OCHA COD-AB 2020) and the official
MDB 2018 district and local municipal boundaries.

Runs in 'replace' mode: on databases that previously held open-source (geoBoundaries) boundaries,
those are retired (kept for requests that reference them, hidden from the picker) and provinces
with matching codes are updated in place.
"""
from django.db import migrations


def load(apps, schema_editor):
    from dcpr import boundaries
    Boundary = apps.get_model("dcpr", "Boundary")
    BoundaryDataset = apps.get_model("dcpr", "BoundaryDataset")
    boundaries.load_bundled(Boundary, BoundaryDataset)
    # Remove retired open-source boundaries that no request references.
    Boundary.objects.filter(is_active=False, source__icontains="geoBoundaries", datasets=None).delete()


def unload(apps, schema_editor):
    apps.get_model("dcpr", "BoundaryDataset").objects.filter(title__endswith="bundled)").delete()


class Migration(migrations.Migration):
    dependencies = [("dcpr", "0004_boundary_datasets")]
    operations = [migrations.RunPython(load, unload)]
