"""Formerly loaded open-source (geoBoundaries) boundaries.

Kept as a no-op so databases that already applied it stay consistent; the official
MDB 2018 boundaries are loaded by 0005_load_mdb_2018_boundaries instead.
"""
from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [("dcpr", "0002_create_role_groups")]
    operations = [migrations.RunPython(migrations.RunPython.noop, migrations.RunPython.noop)]
