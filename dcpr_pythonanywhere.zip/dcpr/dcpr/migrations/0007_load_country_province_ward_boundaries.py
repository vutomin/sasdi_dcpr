"""Add the national, provincial and ward layers (OCHA COD-AB 2020) to databases that already had
the MDB 2018 districts and municipalities. Bundles already loaded are skipped, so on a fresh
install (where 0005 loaded everything) this does nothing. Provinces previously derived from
districts are updated in place with the official provincial boundaries."""
from django.db import migrations


def load(apps, schema_editor):
    from dcpr import boundaries
    boundaries.load_bundled(apps.get_model("dcpr", "Boundary"), apps.get_model("dcpr", "BoundaryDataset"))


class Migration(migrations.Migration):
    dependencies = [("dcpr", "0006_country_and_ward_levels")]
    operations = [migrations.RunPython(load, migrations.RunPython.noop)]
