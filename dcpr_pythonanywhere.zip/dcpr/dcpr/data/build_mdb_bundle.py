"""Build the simplified boundary bundles shipped with DCPR.

Official sources (place the files in one folder and pass it as the argument):
  * MDB_District_Municipal_Boundary_2018.geojson          -> districts & metros (MDB 2018)
  * LocalMunicipalities2018_Final*.geojson                -> local & metro municipalities (MDB 2018)
  * *zaf_admin0.geojson, *zaf_admin1.geojson, *zaf_admin4.geojson
        -> country, provinces, wards (OCHA COD-AB for South Africa, from MDB/Stats SA, valid 2020-11-09)

    python dcpr/data/build_mdb_bundle.py /path/to/folder

Geometries are simplified (see TOL) and rounded to 5 decimals; all attributes are kept.
Administrators can upload the full-resolution files through the admin at any time.
"""
import glob
import gzip
import json
import sys
from pathlib import Path

from shapely import set_precision
from shapely.geometry import MultiPolygon, Polygon, mapping, shape

OUT = Path(__file__).resolve().parent
TOL = {"country": 0.002, "province": 0.0005, "district": 0.0005, "municipality": 0.0005, "ward": 0.0003}
SOURCES = [
    ("country", "*zaf_admin0.geojson", "ocha_2020_country.geojson.gz"),
    ("province", "*zaf_admin1.geojson", "ocha_2020_provinces.geojson.gz"),
    ("district", "MDB_District_Municipal_Boundary_2018*.geojson", "mdb_2018_district_municipalities.geojson.gz"),
    ("municipality", "LocalMunicipalities2018*.geojson", "mdb_2018_local_municipalities.geojson.gz"),
    ("ward", "*zaf_admin4.geojson", "ocha_2020_wards.geojson.gz"),
]


def build(level, src, dest):
    data = json.load(open(src, encoding="utf-8-sig"))
    out = {"type": "FeatureCollection", "name": Path(src).stem,
           "crs": {"type": "name", "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}},
           "features": []}
    for f in data["features"]:
        g = shape(f["geometry"])
        if not g.is_valid:
            g = g.buffer(0)
        s = set_precision(g.simplify(TOL[level], preserve_topology=True), 0.00001)
        if not s.is_valid:
            s = s.buffer(0)
        if isinstance(s, Polygon):
            s = MultiPolygon([s])
        props = {k: v for k, v in f["properties"].items() if v is not None}
        out["features"].append({"type": "Feature", "properties": props, "geometry": mapping(s)})
    raw = json.dumps(out, separators=(",", ":"))
    with gzip.open(OUT / dest, "wt", encoding="utf-8") as fh:
        fh.write(raw)
    print(f"{dest}: {len(out['features'])} features, {len(raw)/1e6:.1f} MB raw")


if __name__ == "__main__":
    folder = Path(sys.argv[1])
    for level, pattern, dest in SOURCES:
        matches = sorted(glob.glob(str(folder / pattern)))
        if not matches:
            print(f"skip {level}: no file matching {pattern}")
            continue
        build(level, matches[0], dest)
