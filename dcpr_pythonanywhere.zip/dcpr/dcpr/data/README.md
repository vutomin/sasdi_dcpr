# Bundled boundary data

These files are loaded automatically by `migrate` and populate the geographic extent picker.

| File | Level | Features | Source |
|---|---|---|---|
| `ocha_2020_country.geojson.gz` | Country | 1 | OCHA COD-AB South Africa `zaf_admin0` (valid 2020-11-09) |
| `ocha_2020_provinces.geojson.gz` | Province | 9 | OCHA COD-AB `zaf_admin1` |
| `mdb_2018_district_municipalities.geojson.gz` | District / metro | 52 | Municipal Demarcation Board, *MDB_District_Municipal_Boundary_2018* |
| `mdb_2018_local_municipalities.geojson.gz` | Local / metro municipality | 213 | Municipal Demarcation Board, *LocalMunicipalities2018_Final* |
| `ocha_2020_wards.geojson.gz` | Ward | 4 392 | OCHA COD-AB `zaf_admin4` |

The OCHA files derive from MDB and Stats SA data, and they carry the MDB codes
(EC, DC44, KZN263, LIM344 …). The hierarchy country › province › district › municipality › ward is
therefore linked by official code across both sources.

The geometries are simplified for the app: about 30 m for wards, 50 m for provinces, districts and
municipalities, and 200 m for the national outline. All original attributes are kept.
`build_mdb_bundle.py` rebuilds them from the source files.

## Updating boundaries

Go to **Admin › Boundary dataset uploads › Add**, choose the level, and upload the new file. The file can be
GeoJSON in WGS84, a .gz of that, or a zipped shapefile. Then validate it (dry run) and import it.

MDB and OCHA field names are detected automatically. Other layouts can be mapped by hand, and a name
pattern such as `{MUNICNAME} Ward {WARDNO:int}` can be set.

On import, boundaries are matched on their code within the level:
* **Update mode** adds new boundaries and updates existing ones.
* **Replace mode** also retires boundaries that are missing from the file.
* Retired boundaries stay linked to the requests that used them, but they are hidden from the picker.

Command-line equivalent: `python manage.py load_boundaries <file> --level ward --dry-run`.
