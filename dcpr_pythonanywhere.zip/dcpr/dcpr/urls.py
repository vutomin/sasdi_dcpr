from django.urls import path

from . import views

app_name = "dcpr"

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("requests/new/<str:form_type>/", views.request_form, name="create"),
    path("requests/<int:pk>/", views.request_detail, name="detail"),
    path("requests/<int:pk>/edit/", views.request_form, name="edit"),
    path("requests/<int:pk>/delete/", views.request_delete, name="delete"),
    path("requests/<int:pk>/print/", views.request_print, name="print"),
    path("requests/<int:pk>/upload/", views.attachment_upload, name="upload"),
    path("requests/<int:pk>/action/<str:name>/", views.request_action, name="action"),
    path("attachments/<int:pk>/", views.download_attachment, name="download"),
    path("register/", views.register, name="register"),
    path("report/", views.report, name="report"),
    path("search/", views.spatial_search, name="search"),
    path("api/boundaries/", views.api_boundaries, name="api_boundaries"),
    path("api/boundaries/geojson/", views.api_boundaries_geojson, name="api_boundaries_geojson"),
]
