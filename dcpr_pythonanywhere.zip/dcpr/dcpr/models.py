"""
Data model for digitised Form E1 / Form E2.

Form E1 - Non-custodian request for CSI approval to capture spatial data.
Form E2 - Base Dataset Custodian notification of intention to capture spatial data.

Both paper forms carry identical fields; they differ only in who completes them
and in the process that follows (E1 needs adjudication per process NSIF_B TD.5,
E2 is a notification that is acknowledged and filed).

Structure follows the original draft model:
    Organisation -> ContactPerson -> Project -> Dataset
with a CaptureRequest wrapping one submission of the form, plus supporting
Attachments and an audit trail of WorkflowEvents.
"""
import os
import uuid

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator, MinValueValidator
from django.db import models, transaction
from django.urls import reverse
from django.utils import timezone


# --------------------------------------------------------------------------- #
# Organisation / contact
# --------------------------------------------------------------------------- #
class Organisation(models.Model):
    class Level(models.TextChoices):
        NATIONAL = "N", "National"
        PROVINCIAL = "P", "Provincial"
        MUNICIPAL = "M", "Municipal"
        TRIBAL_AUTHORITY = "T", "Tribal Authority"

    name = models.CharField(max_length=255)
    level = models.CharField("level of organisation", max_length=1, choices=Level.choices)
    address = models.TextField("organisation address")

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class ContactPerson(models.Model):
    organisation = models.ForeignKey(
        Organisation, on_delete=models.CASCADE, related_name="contacts"
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.SET_NULL, related_name="contact_profiles",
    )
    name = models.CharField("contact person name", max_length=100)
    designation = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=20)
    fax_number = models.CharField(max_length=20, blank=True)
    email = models.EmailField("email address")

    class Meta:
        verbose_name_plural = "contact people"

    def __str__(self):
        return f"{self.name} ({self.organisation})"


# --------------------------------------------------------------------------- #
# Project / dataset
# --------------------------------------------------------------------------- #
class Project(models.Model):
    submitted_by = models.ForeignKey(
        ContactPerson, on_delete=models.PROTECT, related_name="projects"
    )
    name = models.CharField("proposed project name", max_length=255)
    start_date = models.DateField("proposed capture start date")
    end_date = models.DateField("proposed capture end date")
    estimated_cost = models.DecimalField(
        "estimated cost (ZAR)", max_digits=15, decimal_places=2,
        validators=[MinValueValidator(0)],
    )

    def clean(self):
        if self.start_date and self.end_date and self.end_date < self.start_date:
            raise ValidationError({"end_date": "End date cannot be before the start date."})

    def __str__(self):
        return self.name


# --------------------------------------------------------------------------- #
# Predefined administrative boundaries (province / district / municipality)
# --------------------------------------------------------------------------- #
def boundary_upload_to(instance, filename):
    return f"boundary_datasets/{timezone.now():%Y%m%d-%H%M%S}_{os.path.basename(filename)[:120]}"


class BoundaryDataset(models.Model):
    """One uploaded boundary file (e.g. MDB 2018 local municipalities) and the result of importing it."""

    class Mode(models.TextChoices):
        UPDATE = "update", "Update: add new and update matching boundaries, keep the rest"
        REPLACE = "replace", "Replace: as update, and retire boundaries of this level missing from the file"

    class Status(models.TextChoices):
        PENDING = "pending", "Uploaded, not imported"
        VALIDATED = "validated", "Validated (dry run)"
        LOADED = "loaded", "Imported"
        FAILED = "failed", "Failed validation"

    title = models.CharField(max_length=200, help_text="e.g. MDB Local Municipal Boundaries 2018")
    level = models.CharField(max_length=20, choices=[
        ("country", "Country"), ("province", "Province"), ("district", "District / metropolitan municipality"),
        ("municipality", "Local / metropolitan municipality"), ("ward", "Ward"),
        ("other", "Other predefined area")])
    file = models.FileField(upload_to=boundary_upload_to, blank=True,
                            validators=[FileExtensionValidator(["geojson", "json", "gz", "zip", "shp"])],
                            help_text="GeoJSON (WGS84) or a zipped shapefile. Original MDB files are accepted as-is.")
    source = models.CharField(max_length=255, default="Municipal Demarcation Board (MDB)")
    effective_date = models.DateField(null=True, blank=True, help_text="Date the boundaries took effect.")
    mode = models.CharField(max_length=10, choices=Mode.choices, default=Mode.REPLACE)
    derive_provinces = models.BooleanField(
        default=False, help_text="District files only: rebuild province boundaries by merging districts "
                                 "on their province code.")
    name_field = models.CharField(max_length=60, blank=True, help_text="Leave blank to detect (MDB: MUNICNAME / DISTRICT_N; OCHA: adm1_name …).")
    name_format = models.CharField(
        max_length=120, blank=True,
        help_text="Optional pattern for display names using file fields, e.g. “{MUNICNAME} Ward {WARDNO}”. "
                  "Overrides the name field.")
    code_field = models.CharField(max_length=60, blank=True, help_text="Leave blank to detect (MDB: CAT_B / DISTRICT).")
    parent_field = models.CharField(max_length=60, blank=True, help_text="Leave blank to detect (MDB: DISTRICT / PROVINCE).")
    category_field = models.CharField(max_length=60, blank=True, help_text="Leave blank to detect (MDB: CATEGORY).")
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    feature_count = models.PositiveIntegerField(default=0)
    created_count = models.PositiveIntegerField(default=0)
    updated_count = models.PositiveIntegerField(default=0)
    retired_count = models.PositiveIntegerField(default=0)
    derived_count = models.PositiveIntegerField(default=0)
    log = models.TextField(blank=True)
    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    imported_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-uploaded_at"]
        verbose_name = "boundary dataset upload"

    def __str__(self):
        return f"{self.title} ({self.get_status_display()})"


class Boundary(models.Model):
    """A predefined boundary an applicant can pick as (part of) a dataset's extent.

    Geometry is stored as GeoJSON (WGS84 / EPSG:4326) with an indexed bounding box,
    so spatial search works on SQLite and PostgreSQL without GDAL. See dcpr/geo.py.
    """

    class Level(models.TextChoices):
        COUNTRY = "country", "Country"
        PROVINCE = "province", "Province"
        DISTRICT = "district", "District / metropolitan municipality"
        MUNICIPALITY = "municipality", "Local / metropolitan municipality"
        WARD = "ward", "Ward"
        OTHER = "other", "Other predefined area"

    LEVEL_ORDER = {"country": 0, "province": 1, "district": 2, "municipality": 3, "ward": 4, "other": 5}

    level = models.CharField(max_length=20, choices=Level.choices, db_index=True)
    name = models.CharField(max_length=255)
    code = models.CharField(max_length=60, help_text="Official code, unique within a level (e.g. WC, DC2, WC024).")
    category = models.CharField(max_length=2, blank=True,
                                help_text="MDB municipal category: A metro, B local, C district.")
    parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.SET_NULL, related_name="children")
    dataset = models.ForeignKey(BoundaryDataset, null=True, blank=True, on_delete=models.SET_NULL,
                                related_name="boundaries", help_text="Upload this version came from.")
    geometry = models.JSONField(help_text="GeoJSON Polygon/MultiPolygon in WGS84 (EPSG:4326).")
    display_geometry = models.JSONField(editable=False, help_text="Further simplified geometry for maps.")
    min_x = models.FloatField(editable=False)
    min_y = models.FloatField(editable=False)
    max_x = models.FloatField(editable=False)
    max_y = models.FloatField(editable=False)
    area_km2 = models.FloatField(editable=False, default=0)
    source = models.CharField(max_length=255, blank=True)
    is_active = models.BooleanField(default=True, help_text="Inactive boundaries are hidden from the picker.")

    class Meta:
        ordering = ["level", "name"]
        verbose_name_plural = "boundaries"
        indexes = [models.Index(fields=["min_x", "max_x", "min_y", "max_y"], name="boundary_bbox_idx")]
        constraints = [models.UniqueConstraint(fields=["level", "code"], name="boundary_level_code_uniq")]

    def __str__(self):
        return f"{self.name} ({self.kind_label})"

    KIND_BY_CATEGORY = {"A": "Metropolitan municipality", "B": "Local municipality", "C": "District municipality"}

    @property
    def kind_label(self):
        """Human label using the MDB category where known (metros show as metros at both levels)."""
        return self.KIND_BY_CATEGORY.get(self.category) or self.get_level_display()

    @property
    def bbox(self):
        return [self.min_x, self.min_y, self.max_x, self.max_y]

    @property
    def path(self):
        """'Western Cape › City of Cape Town' style breadcrumb."""
        names, node = [], self.parent
        while node is not None and len(names) < 4:
            # skip the country, and metros that repeat at district and local level
            if node.level != "country" and (not names or names[-1] != node.name) and node.name != self.name:
                names.append(node.name)
            node = node.parent
        return " › ".join(reversed(names))

    def save(self, *args, **kwargs):
        from . import geo
        geo.prepare_boundary(self)
        super().save(*args, **kwargs)


class Dataset(models.Model):
    class GeographicExtent(models.TextChoices):
        NATIONAL = "N", "National"
        PROVINCIAL = "P", "Provincial"
        MAGISTERIAL_DISTRICT = "MD", "Magisterial district"
        MUNICIPAL = "M", "Municipal"
        TRIBAL_AUTHORITY = "TA", "Tribal authority"
        VOTING_DISTRICT = "VD", "Voting district"
        WARD_BOUNDARIES = "W", "Ward boundaries"
        ENUMERATOR_AREAS = "EA", "Enumerator areas"
        LAND_PARCELS = "LP", "Land parcels"
        OTHER = "O", "Other"

    class DataType(models.TextChoices):
        # Vector
        POINT = "P", "Point (vector)"
        NETWORK = "N", "Network (vector)"
        LINE = "L", "Line (vector)"
        POLYGON = "PO", "Polygon (vector)"
        # Raster
        SATELLITE = "S", "Satellite imagery (raster)"
        RADAR = "R", "Radar (raster)"
        AERIAL = "A", "Aerial photography (raster)"
        OTHER_IMAGERY = "O", "Other imagery (raster)"

    class CaptureMethod(models.TextChoices):
        AERIAL_PHOTOGRAPHY = "AP", "Aerial photography"
        REMOTE_SENSING = "RS", "Remote sensing"
        DIGITISING = "D", "Digitising"
        GPS = "CC", "GPS coordinate capture"
        SURVEY_CADASTRAL = "S", "Survey (cadastral)"
        SURVEY_QUESTIONNAIRE = "Q", "Survey (questionnaire)"
        SCANNING_VECTORISING = "SV", "Scanning & vectorising"
        OTHER = "O", "Other"

    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="datasets")
    title = models.CharField("proposed dataset title", max_length=255)
    purpose = models.TextField("purpose of dataset")
    lineage = models.TextField(
        "lineage statement", blank=True,
        help_text="Optional if an existing dataset is used as part of the capture process.",
    )
    feature_description = models.TextField(
        help_text="Short summary of features that are to be collected."
    )
    abstract = models.TextField("proposed abstract describing the envisaged dataset")
    resolution = models.CharField("proposed spatial resolution or scale of capture", max_length=100)
    attributes = models.TextField("associated attributes")
    # "Mark with X" fields allow several selections, stored as lists of choice codes.
    data_types = models.JSONField("data type", default=list)
    geographic_extents = models.JSONField("geographic extent", default=list)
    geographic_extent_other = models.CharField("other geographic extent", max_length=255, blank=True)
    capture_methods = models.JSONField("method of capture", default=list)
    method_details = models.TextField("detail method of capture")

    # Spatial extent: predefined boundaries and/or a custom area (drawn polygon,
    # bounding box or uploaded GeoJSON). The union is stored with an indexed bbox
    # for spatial search; see dcpr/geo.py.
    boundaries = models.ManyToManyField(Boundary, blank=True, related_name="datasets",
                                        verbose_name="predefined boundaries")
    custom_extent = models.JSONField("custom area", null=True, blank=True,
                                     help_text="GeoJSON Polygon/MultiPolygon (WGS84).")
    custom_extent_kind = models.CharField(max_length=10, blank=True,
                                          choices=[("polygon", "Drawn polygon"), ("bbox", "Bounding box"),
                                                   ("upload", "Uploaded GeoJSON")])
    extent_geometry = models.JSONField(null=True, blank=True, editable=False)
    extent_min_x = models.FloatField(null=True, blank=True, editable=False)
    extent_min_y = models.FloatField(null=True, blank=True, editable=False)
    extent_max_x = models.FloatField(null=True, blank=True, editable=False)
    extent_max_y = models.FloatField(null=True, blank=True, editable=False)
    extent_area_km2 = models.FloatField(null=True, blank=True, editable=False)

    class Meta:
        ordering = ["pk"]
        indexes = [models.Index(fields=["extent_min_x", "extent_max_x", "extent_min_y", "extent_max_y"],
                                name="dataset_extent_bbox_idx")]

    def clean(self):
        if self.GeographicExtent.OTHER in (self.geographic_extents or []) and not self.geographic_extent_other:
            raise ValidationError({"geographic_extent_other": "Please specify the geographic extent."})

    @staticmethod
    def _labels(codes, choices_cls):
        lookup = dict(choices_cls.choices)
        return [lookup.get(c, c) for c in (codes or [])]

    @property
    def geographic_extent_labels(self):
        labels = []
        for code in self.geographic_extents or []:
            if code == self.GeographicExtent.OTHER and self.geographic_extent_other:
                labels.append(f"Other: {self.geographic_extent_other}")
            else:
                labels.append(dict(self.GeographicExtent.choices).get(code, code))
        return labels

    @property
    def data_type_labels(self):
        return self._labels(self.data_types, self.DataType)

    @property
    def capture_method_labels(self):
        return self._labels(self.capture_methods, self.CaptureMethod)

    @property
    def geographic_extent_display(self):
        return ", ".join(self.geographic_extent_labels)

    @property
    def data_type_display(self):
        return ", ".join(self.data_type_labels)

    @property
    def capture_method_display(self):
        return ", ".join(self.capture_method_labels)

    def __str__(self):
        return self.title

    @property
    def extent_bbox(self):
        if self.extent_min_x is None:
            return None
        return [self.extent_min_x, self.extent_min_y, self.extent_max_x, self.extent_max_y]

    def refresh_extent(self, save=True):
        """Recompute the union extent from boundaries + custom area (call after M2M save)."""
        from . import geo
        geo.update_dataset_extent(self, save=save)


# --------------------------------------------------------------------------- #
# The request itself (one submission of Form E1 or E2)
# --------------------------------------------------------------------------- #
class CaptureRequest(models.Model):
    class FormType(models.TextChoices):
        E1 = "E1", "Form E1 – Non-custodian request to capture spatial data"
        E2 = "E2", "Form E2 – Custodian notification of intention to capture"

    class Urgency(models.TextChoices):
        LOW = "L", "Low"
        MEDIUM = "M", "Medium"
        HIGH = "H", "High"

    class UsageRestrictions(models.TextChoices):
        YES = "Y", "Yes"
        NO = "N", "No"
        NOT_APPLICABLE = "NA", "Not applicable"

    class Status(models.TextChoices):
        DRAFT = "draft", "Draft"
        SUBMITTED = "submitted", "Submitted"
        ACKNOWLEDGED = "acknowledged", "Acknowledged"
        IN_ADJUDICATION = "adjudication", "With CSI Data Sub-committee"
        AWAITING_SIGNATURE = "awaiting_signature", "Awaiting Chairperson signature"
        LETTER_SIGNED = "letter_signed", "Letter signed"
        APPLICANT_NOTIFIED = "notified", "Applicant notified"
        CLOSED = "closed", "Filed & closed"
        RETURNED = "returned", "Referred back for amendments"

    class Outcome(models.TextChoices):
        PENDING = "", "Pending"
        APPROVED = "approved", "Successful"
        REJECTED = "rejected", "Unsuccessful"
        NOTED = "noted", "Noted (legacy custodian notification)"  # E2s closed before E2 followed the full process

    form_type = models.CharField(max_length=2, choices=FormType.choices)
    reference_number = models.CharField(
        "CSI reference number", max_length=30, unique=True, null=True, blank=True,
        help_text="Assigned automatically on submission.",
    )
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT)
    outcome = models.CharField(max_length=10, choices=Outcome.choices, default="", blank=True)

    applicant = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="capture_requests"
    )
    project = models.OneToOneField(Project, on_delete=models.CASCADE, related_name="capture_request")

    urgency = models.CharField(max_length=1, choices=Urgency.choices)
    data_usage_restrictions = models.CharField(max_length=2, choices=UsageRestrictions.choices)

    # Declaration block ("Request submitted by / Signature / Designation / Date")
    declarant_name = models.CharField("request submitted by", max_length=100)
    declarant_designation = models.CharField("designation", max_length=100)
    declaration_accepted = models.BooleanField(
        "declaration", default=False,
        help_text="Electronic signature: I confirm the information supplied is correct.",
    )

    # Office-use fields populated through the workflow
    assessment_notes = models.TextField("preliminary assessment", blank=True)
    committee_resolution = models.TextField("CSI Data Sub-committee resolution", blank=True)
    file_reference = models.CharField("filing reference", max_length=100, blank=True)
    returned_from = models.CharField(
        "referred back at stage", max_length=20, blank=True,
        help_text="Stage the request was at when it was last referred back for amendments.",
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    submitted_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-submitted_at", "-created_at"]
        permissions = [
            ("view_register", "Can view the spatial data capture project register"),
        ]

    def __str__(self):
        return f"{self.reference_number or 'DRAFT'} – {self.project.name}"

    def get_absolute_url(self):
        return reverse("dcpr:detail", args=[self.pk])

    # Convenience accessors -------------------------------------------------
    @property
    def datasets(self):
        return self.project.datasets.all()

    @property
    def dataset(self):
        """First dataset (kept for convenience in lists)."""
        ds = self.datasets
        return ds[0] if ds else None

    @property
    def contact(self):
        return self.project.submitted_by

    @property
    def organisation(self):
        return self.project.submitted_by.organisation

    @property
    def is_editable(self):
        return self.status in (self.Status.DRAFT, self.Status.RETURNED)

    @property
    def is_returned(self):
        return self.status == self.Status.RETURNED

    @property
    def last_referral(self):
        """The most recent 'refer back' event (comment explains the amendments needed)."""
        return self.events.filter(action="refer_back").select_related("actor").last()

    @property
    def requires_approval(self):
        """Both forms now follow the full NSIF_B TD.5 process (E2 is worded as a notification)."""
        return True

    @property
    def noun(self):
        """'request' (Form E1) or 'notification' (Form E2) – used in all workflow wording."""
        return "notification" if self.form_type == self.FormType.E2 else "request"

    @property
    def Noun(self):
        return self.noun.capitalize()

    @property
    def status_label(self):
        label = self.get_status_display()
        if self.status == self.Status.CLOSED and self.outcome:
            label = f"{label} – {self.get_outcome_display()}"
        return label

    def assign_reference_number(self):
        """CSI/E1/2026/0001 – sequential per form type and year."""
        if self.reference_number:
            return
        year = timezone.localdate().year
        prefix = f"CSI/{self.form_type}/{year}/"
        with transaction.atomic():
            last = (
                CaptureRequest.objects.select_for_update()
                .filter(reference_number__startswith=prefix)
                .order_by("-reference_number")
                .values_list("reference_number", flat=True)
                .first()
            )
            seq = int(last.rsplit("/", 1)[1]) + 1 if last else 1
            self.reference_number = f"{prefix}{seq:04d}"


# --------------------------------------------------------------------------- #
# Supporting documentation
# --------------------------------------------------------------------------- #
def validate_file_size(f):
    limit = getattr(settings, "ATTACHMENT_MAX_SIZE_MB", 25)
    if f.size > limit * 1024 * 1024:
        raise ValidationError(f"File too large: the maximum size is {limit} MB.")


def attachment_upload_to(instance, filename):
    base, ext = os.path.splitext(filename)
    return f"capture_requests/{instance.request_id}/{uuid.uuid4().hex[:8]}_{base[:80]}{ext.lower()}"


class Attachment(models.Model):
    class Category(models.TextChoices):
        # Applicant-supplied
        SPECIFICATION = "spec", "Detailed specification"
        PROJECT_PLAN = "plan", "Project plan / proposal"
        TERMS_OF_REFERENCE = "tor", "Terms of reference"
        SAMPLE_DATA = "sample", "Sample data / map"
        BUDGET = "budget", "Budget / costing"
        OTHER = "other", "Other supporting document"
        # Office-generated during the process
        ACKNOWLEDGEMENT = "ack", "Acknowledgement letter"
        ADJUDICATION_PACK = "pack", "Adjudication pack"
        DRAFT_LETTER = "draft_letter", "Draft outcome letter"
        SIGNED_LETTER = "signed_letter", "Signed outcome letter"
        SCANNED_FILE = "scanned", "Scanned / filed documentation"

    APPLICANT_CATEGORIES = ["spec", "plan", "tor", "sample", "budget", "other"]

    request = models.ForeignKey(CaptureRequest, on_delete=models.CASCADE, related_name="attachments")
    category = models.CharField(max_length=20, choices=Category.choices, default=Category.SPECIFICATION)
    file = models.FileField(
        upload_to=attachment_upload_to,
        validators=[
            FileExtensionValidator(getattr(settings, "ATTACHMENT_ALLOWED_EXTENSIONS", None)),
            validate_file_size,
        ],
    )
    original_name = models.CharField(max_length=255, editable=False)
    description = models.CharField(max_length=255, blank=True)
    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    stage = models.CharField(max_length=20, choices=CaptureRequest.Status.choices, editable=False)

    class Meta:
        ordering = ["uploaded_at"]

    def save(self, *args, **kwargs):
        if not self.original_name and self.file:
            self.original_name = os.path.basename(self.file.name)
        if not self.stage:
            self.stage = self.request.status
        super().save(*args, **kwargs)

    def __str__(self):
        return self.original_name

    @property
    def size(self):
        try:
            return self.file.size
        except (FileNotFoundError, OSError):
            return None


# --------------------------------------------------------------------------- #
# Audit trail
# --------------------------------------------------------------------------- #
class WorkflowEvent(models.Model):
    request = models.ForeignKey(CaptureRequest, on_delete=models.CASCADE, related_name="events")
    action = models.CharField(max_length=50)
    label = models.CharField(max_length=150)
    from_status = models.CharField(max_length=20, blank=True)
    to_status = models.CharField(max_length=20)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["created_at", "pk"]

    def __str__(self):
        return f"{self.request} – {self.label}"


# --------------------------------------------------------------------------- #
# Keep projects/datasets in step with their request
# --------------------------------------------------------------------------- #
from django.db.models.signals import post_delete  # noqa: E402
from django.dispatch import receiver  # noqa: E402


@receiver(post_delete, sender=CaptureRequest)
def delete_project_with_request(sender, instance, **kwargs):
    """Deleting a request (e.g. in the admin) also removes its project and datasets."""
    Project.objects.filter(pk=instance.project_id).delete()
