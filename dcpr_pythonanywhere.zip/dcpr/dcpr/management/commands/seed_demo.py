"""Create demo users for each role:  python manage.py seed_demo"""
from django.contrib.auth.models import Group, User
from django.core.management.base import BaseCommand

from dcpr.roles import CHAIRPERSON, NSIF, SUBCOMMITTEE

USERS = [
    ("applicant", "Thandi", "Mokoena", "applicant@example.org", None),
    ("nsif", "Sipho", "Ndlovu", "nsif@example.gov.za", NSIF),
    ("committee", "Anika", "van Wyk", "committee@example.gov.za", SUBCOMMITTEE),
    ("chair", "Lerato", "Dlamini", "chair@example.gov.za", CHAIRPERSON),
]


class Command(BaseCommand):
    help = "Create demo users (password: demo12345) for each workflow role."

    def add_arguments(self, parser):
        parser.add_argument("--password", default="demo12345")

    def handle(self, *args, password, **opts):
        for username, first, last, email, role in USERS:
            user, created = User.objects.get_or_create(
                username=username, defaults={"first_name": first, "last_name": last, "email": email}
            )
            user.set_password(password)
            user.save()
            if role:
                user.groups.add(Group.objects.get(name=role))
            self.stdout.write(f"{'Created' if created else 'Updated'} {username} ({role or 'Applicant'})")
        if not User.objects.filter(username="admin").exists():
            User.objects.create_superuser("admin", "admin@example.gov.za", password)
            self.stdout.write("Created superuser admin")
        self.stdout.write(self.style.SUCCESS(f"Done. Password for all demo users: {password}"))
