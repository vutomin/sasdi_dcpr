"""
Load administrative boundaries from the command line (the admin upload screen does the same).

    python manage.py load_boundaries --bundled            # reload all bundled layers
    python manage.py load_boundaries MDB_District_Municipal_Boundary_2018.geojson --level district --derive-provinces
    python manage.py load_boundaries LocalMunicipalities2018.geojson --level municipality
    python manage.py load_boundaries wards.zip --level other --name-field WardID --code-field WardID --mode update
    add --dry-run to validate without changing anything.
"""
from django.core.management.base import BaseCommand, CommandError

from dcpr import boundaries
from dcpr.models import Boundary


class Command(BaseCommand):
    help = "Validate and import boundaries from GeoJSON or a zipped shapefile (WGS84)."

    def add_arguments(self, parser):
        parser.add_argument("path", nargs="?")
        parser.add_argument("--bundled", action="store_true", help="Reload the bundled MDB 2018 boundaries.")
        parser.add_argument("--level", choices=["country", "province", "district", "municipality", "ward", "other"])
        parser.add_argument("--name-field", default="")
        parser.add_argument("--code-field", default="")
        parser.add_argument("--parent-field", default="")
        parser.add_argument("--category-field", default="")
        parser.add_argument("--name-format", default="", help='e.g. "{MUNICNAME} Ward {WARDNO:int}"')
        parser.add_argument("--mode", choices=["update", "replace"], default="replace")
        parser.add_argument("--derive-provinces", action="store_true")
        parser.add_argument("--source", default=boundaries.MDB_SOURCE)
        parser.add_argument("--dry-run", action="store_true")

    def handle(self, path, **o):
        try:
            if o["bundled"]:
                from dcpr.models import BoundaryDataset
                done = boundaries.load_bundled(Boundary, BoundaryDataset, skip_existing=False)
                for title, res in done:
                    self.stdout.write(f"{title}: {res.summary()}")
                return
            if not path or not o["level"]:
                raise CommandError("Give a file path and --level (or use --bundled).")
            res = boundaries.import_file(
                Boundary, path, o["level"],
                mapping={"name": o["name_field"], "code": o["code_field"],
                         "parent": o["parent_field"], "category": o["category_field"],
                         "name_format": o["name_format"]},
                mode=o["mode"], derive_provinces=o["derive_provinces"], source=o["source"],
                dry_run=o["dry_run"])
        except boundaries.BoundaryImportError as e:
            raise CommandError("Validation failed:\n  - " + "\n  - ".join(e.problems[:40]))
        self.stdout.write(res.text)
