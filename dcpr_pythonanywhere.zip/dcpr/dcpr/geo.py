"""
Geospatial helpers for DCPR.

Geometries are kept as GeoJSON (WGS84 lon/lat, EPSG:4326) in JSON columns, each
with an indexed bounding box. Spatial search is two-stage:

  1. SQL bounding-box overlap on indexed float columns (fast, any database);
  2. exact geometry test with Shapely on the remaining candidates.

This avoids a GDAL/PostGIS dependency. If you later move to PostGIS, the same
API can be backed by GeoDjango geometry fields without changing the views.
"""
import json
import math

from django.core.exceptions import ValidationError
from shapely import set_precision
from shapely.geometry import MultiPolygon, Polygon, box, mapping, shape
from shapely.ops import unary_union
from shapely.prepared import prep

# Generous envelope around South Africa (incl. Prince Edward Islands) for sanity checks.
SA_ENVELOPE = (10.0, -50.0, 40.0, -15.0)
MAX_VERTICES = 20000
STORE_TOLERANCE = 0.001      # ~100 m: stored extent geometry
DISPLAY_TOLERANCE = {"country": 0.02, "province": 0.01, "district": 0.006, "municipality": 0.004,
                     "ward": 0.0006, "other": 0.002}


# --------------------------------------------------------------------------- #
# Parsing / validation
# --------------------------------------------------------------------------- #
def _as_multipolygon(g):
    if g.is_empty:
        raise ValidationError("The area is empty.")
    if isinstance(g, Polygon):
        return MultiPolygon([g])
    if isinstance(g, MultiPolygon):
        return g
    if g.geom_type == "GeometryCollection":
        polys = []
        for part in g.geoms:
            if isinstance(part, Polygon):
                polys.append(part)
            elif isinstance(part, MultiPolygon):
                polys.extend(part.geoms)
        if polys:
            return MultiPolygon(polys)
    raise ValidationError("The area must be a polygon (points and lines cannot define an extent).")


def parse_geojson(value):
    """Accept a GeoJSON geometry, Feature or FeatureCollection (str or dict); return a valid MultiPolygon."""
    if value in (None, "", {}):
        return None
    try:
        data = json.loads(value) if isinstance(value, str) else value
    except json.JSONDecodeError:
        raise ValidationError("The area is not valid GeoJSON.")
    if not isinstance(data, dict) or "type" not in data:
        raise ValidationError("The area is not valid GeoJSON.")
    try:
        if data["type"] == "FeatureCollection":
            geoms = [shape(f["geometry"]) for f in data.get("features", []) if f.get("geometry")]
            g = unary_union(geoms) if geoms else Polygon()
        elif data["type"] == "Feature":
            g = shape(data["geometry"])
        else:
            g = shape(data)
    except Exception:
        raise ValidationError("The area could not be read as GeoJSON geometry.")
    if not g.is_valid:
        g = g.buffer(0)
    g = _as_multipolygon(g)
    n = sum(len(p.exterior.coords) + sum(len(i.coords) for i in p.interiors) for p in g.geoms)
    if n > MAX_VERTICES:
        g = _as_multipolygon(g.simplify(STORE_TOLERANCE, preserve_topology=True))
    minx, miny, maxx, maxy = g.bounds
    ex = SA_ENVELOPE
    if minx < ex[0] or maxx > ex[2] or miny < ex[1] or maxy > ex[3]:
        raise ValidationError(
            "The area lies outside South Africa. Coordinates must be longitude/latitude in WGS84 "
            "(e.g. longitude 28.2, latitude -25.7)."
        )
    return g


def bbox_geometry(min_x, min_y, max_x, max_y):
    try:
        vals = [float(v) for v in (min_x, min_y, max_x, max_y)]
    except (TypeError, ValueError):
        raise ValidationError("Bounding box values must be numbers.")
    if vals[0] >= vals[2] or vals[1] >= vals[3]:
        raise ValidationError("Bounding box minimum values must be smaller than the maximum values.")
    return parse_geojson(mapping(box(*vals)))


def to_geojson(g, precision=0.00001):
    return mapping(set_precision(g, precision)) if g is not None else None


# --------------------------------------------------------------------------- #
# Measurements
# --------------------------------------------------------------------------- #
def approx_area_km2(g):
    """Area of a lon/lat geometry, scaled by latitude (accurate to a few % at SA latitudes)."""
    if g is None or g.is_empty:
        return 0.0
    total = 0.0
    for poly in getattr(g, "geoms", [g]):
        lat = poly.centroid.y
        total += poly.area * (111.32 ** 2) * math.cos(math.radians(lat))
    return round(total, 1)


# --------------------------------------------------------------------------- #
# Boundaries
# --------------------------------------------------------------------------- #
def prepare_boundary(b):
    """Validate geometry and fill bbox, area and display geometry on a Boundary before save."""
    g = parse_geojson(b.geometry)
    if g is None:
        raise ValidationError("A boundary needs a geometry.")
    b.geometry = to_geojson(g)
    tol = DISPLAY_TOLERANCE.get(b.level, 0.003)
    simple = g.simplify(tol, preserve_topology=True)
    b.display_geometry = to_geojson(simple if not simple.is_empty else g, 0.0001)
    b.min_x, b.min_y, b.max_x, b.max_y = g.bounds
    b.area_km2 = approx_area_km2(g)


def boundary_shape(b):
    return shape(b.geometry)


# --------------------------------------------------------------------------- #
# Dataset extent
# --------------------------------------------------------------------------- #
def dataset_extent_shape(dataset, boundaries=None, custom=None):
    parts = []
    for b in (boundaries if boundaries is not None else dataset.boundaries.all()):
        parts.append(shape(b.geometry))
    custom = dataset.custom_extent if custom is None else custom
    if custom:
        parts.append(shape(custom))
    if not parts:
        return None
    u = unary_union(parts)
    if not u.is_valid:
        u = u.buffer(0)
    u = u.simplify(STORE_TOLERANCE, preserve_topology=True)
    return _as_multipolygon(u)


def update_dataset_extent(dataset, save=True):
    g = dataset_extent_shape(dataset)
    if g is None:
        dataset.extent_geometry = None
        dataset.extent_min_x = dataset.extent_min_y = dataset.extent_max_x = dataset.extent_max_y = None
        dataset.extent_area_km2 = None
    else:
        dataset.extent_geometry = to_geojson(g)
        dataset.extent_min_x, dataset.extent_min_y, dataset.extent_max_x, dataset.extent_max_y = g.bounds
        dataset.extent_area_km2 = approx_area_km2(g)
    if save:
        dataset.save(update_fields=["extent_geometry", "extent_min_x", "extent_min_y", "extent_max_x",
                                    "extent_max_y", "extent_area_km2"])
    return g


# --------------------------------------------------------------------------- #
# Search
# --------------------------------------------------------------------------- #
def bbox_overlap_q(prefix, bounds):
    """Django Q-style kwargs for 'stored bbox overlaps bounds' on fields <prefix>min_x etc."""
    from django.db.models import Q
    minx, miny, maxx, maxy = bounds
    return (Q(**{f"{prefix}min_x__lte": maxx}) & Q(**{f"{prefix}max_x__gte": minx})
            & Q(**{f"{prefix}min_y__lte": maxy}) & Q(**{f"{prefix}max_y__gte": miny}))


def filter_datasets(qs, area, mode="intersects"):
    """Return datasets from qs whose extent intersects (or lies within) the shapely geometry `area`."""
    if area is None:
        return list(qs)
    candidates = qs.filter(bbox_overlap_q("extent_", area.bounds)).exclude(extent_geometry=None)
    pa = prep(area)
    out = []
    for d in candidates:
        g = shape(d.extent_geometry)
        if mode == "within":
            # tolerate simplification noise along shared edges
            if pa.contains(g) or area.buffer(0.002).contains(g):
                out.append(d)
        elif pa.intersects(g):
            out.append(d)
    return out


def overlapping_datasets(dataset, qs):
    """Other datasets whose extent intersects this dataset's extent, with overlap area."""
    if not dataset.extent_geometry:
        return []
    g = shape(dataset.extent_geometry)
    results = []
    for other in filter_datasets(qs.exclude(pk=dataset.pk), g):
        og = shape(other.extent_geometry)
        inter = g.intersection(og)
        km2 = approx_area_km2(inter) if not inter.is_empty else 0.0
        share = km2 / dataset.extent_area_km2 * 100 if dataset.extent_area_km2 else 0
        results.append((other, km2, share))
    results.sort(key=lambda r: -r[1])
    return results


def boundaries_intersecting(geom, qs):
    pg = prep(geom)
    return [b for b in qs.filter(bbox_overlap_q("", geom.bounds)) if pg.intersects(shape(b.geometry))]


# --------------------------------------------------------------------------- #
# Static SVG rendering (print view; works without map tiles)
# --------------------------------------------------------------------------- #
def svg_map(layers, width=520, height=360, pad=8):
    """layers: list of (shapely geometry, css_class). Returns an SVG string in lon/lat
    (equirectangular, scaled by cos(latitude)) framed on the union of all layers."""
    geoms = [g for g, _ in layers if g is not None and not g.is_empty]
    if not geoms:
        return ""
    minx, miny, maxx, maxy = unary_union(geoms).bounds
    k = math.cos(math.radians((miny + maxy) / 2))
    w, h = max((maxx - minx) * k, 1e-6), max(maxy - miny, 1e-6)
    scale = min((width - 2 * pad) / w, (height - 2 * pad) / h)
    ox = (width - w * scale) / 2
    oy = (height - h * scale) / 2

    def ring(coords):
        return "M" + "L".join(f"{ox + (x - minx) * k * scale:.1f},{oy + (maxy - y) * scale:.1f}" for x, y in coords) + "Z"

    paths = []
    for g, cls in layers:
        if g is None or g.is_empty:
            continue
        d = ""
        for poly in getattr(g, "geoms", [g]):
            if poly.geom_type != "Polygon":
                continue
            d += ring(poly.exterior.coords) + "".join(ring(i.coords) for i in poly.interiors)
        paths.append(f'<path class="{cls}" fill-rule="evenodd" d="{d}"/>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" '
            f'width="{width}" height="{height}" role="img">{"".join(paths)}</svg>')
