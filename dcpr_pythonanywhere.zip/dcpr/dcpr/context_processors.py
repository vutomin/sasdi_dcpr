from .roles import CHAIRPERSON, NSIF, SUBCOMMITTEE, has_role, is_office


def roles(request):
    u = request.user
    if not u.is_authenticated:
        return {}
    return {
        "is_office": is_office(u),
        "is_nsif": has_role(u, NSIF),
        "is_committee": has_role(u, SUBCOMMITTEE),
        "is_chair": has_role(u, CHAIRPERSON),
    }
