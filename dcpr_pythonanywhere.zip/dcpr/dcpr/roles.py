"""Role helpers. Roles are plain Django auth Groups (created by migration 0002)."""
from django.contrib.auth.models import Group

NSIF = "NSIF (Spatial Information and Support)"
SUBCOMMITTEE = "CSI Data Sub-committee"
CHAIRPERSON = "CSI Data Sub-committee Chairperson"
APPLICANT = "Applicant"  # implicit: any authenticated user who owns a request

OFFICE_ROLES = (NSIF, SUBCOMMITTEE, CHAIRPERSON)
ALL_GROUPS = OFFICE_ROLES


def user_roles(user):
    if not user.is_authenticated:
        return set()
    cache = getattr(user, "_capture_roles", None)
    if cache is None:
        if user.is_superuser:
            cache = set(OFFICE_ROLES)
        else:
            cache = set(user.groups.filter(name__in=OFFICE_ROLES).values_list("name", flat=True))
        user._capture_roles = cache
    return cache


def has_role(user, *roles):
    return bool(user_roles(user) & set(roles))


def is_office(user):
    return has_role(user, *OFFICE_ROLES)


def users_in_role(role):
    group = Group.objects.filter(name=role).first()
    if not group:
        return []
    return list(group.user_set.filter(is_active=True))


def can_view_request(user, req):
    return req.applicant_id == user.pk or is_office(user)
