import json

from django import forms
from django.contrib import admin
from django.core.exceptions import ValidationError

from django.contrib import messages
from django.urls import reverse
from django.utils.html import format_html

from . import boundaries as boundary_import
from . import geo
from .models import Attachment, Boundary, BoundaryDataset, CaptureRequest, ContactPerson, Dataset, Organisation, Project, WorkflowEvent


@admin.register(Organisation)
class OrganisationAdmin(admin.ModelAdmin):
    list_display = ("name", "level")
    list_filter = ("level",)
    search_fields = ("name",)


@admin.register(ContactPerson)
class ContactPersonAdmin(admin.ModelAdmin):
    list_display = ("name", "organisation", "designation", "email", "phone_number")
    search_fields = ("name", "email", "organisation__name")


class DatasetInline(admin.StackedInline):
    model = Dataset
    extra = 0
    filter_horizontal = ("boundaries",)
    readonly_fields = ("extent_area_km2", "extent_min_x", "extent_min_y", "extent_max_x", "extent_max_y")
    exclude = ("extent_geometry",)


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ("name", "submitted_by", "start_date", "end_date", "estimated_cost")
    inlines = [DatasetInline]

    def save_related(self, request, form, formsets, change):
        super().save_related(request, form, formsets, change)
        for d in form.instance.datasets.all():
            d.refresh_extent()


class AttachmentInline(admin.TabularInline):
    model = Attachment
    extra = 0
    readonly_fields = ("original_name", "uploaded_by", "uploaded_at", "stage")


class EventInline(admin.TabularInline):
    model = WorkflowEvent
    extra = 0
    readonly_fields = ("action", "label", "from_status", "to_status", "actor", "comment", "created_at")
    can_delete = False


@admin.register(CaptureRequest)
class CaptureRequestAdmin(admin.ModelAdmin):
    list_display = ("reference_number", "form_type", "project", "status", "outcome", "urgency", "submitted_at")
    list_filter = ("form_type", "status", "outcome", "urgency")
    search_fields = ("reference_number", "project__name", "project__submitted_by__organisation__name")
    readonly_fields = ("reference_number", "submitted_at", "closed_at", "created_at", "updated_at")
    inlines = [AttachmentInline, EventInline]


class BoundaryAdminForm(forms.ModelForm):
    geojson_file = forms.FileField(
        required=False, label="Upload GeoJSON",
        help_text="Polygon/MultiPolygon in WGS84 longitude/latitude. Replaces the geometry below.")

    class Meta:
        model = Boundary
        fields = ["level", "name", "code", "parent", "is_active", "source", "geometry", "geojson_file"]
        widgets = {"geometry": forms.Textarea(attrs={"rows": 4})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["geometry"].required = False

    def clean(self):
        cd = super().clean()
        f = cd.get("geojson_file")
        if f:
            try:
                cd["geometry"] = json.loads(f.read().decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                raise ValidationError({"geojson_file": "The file is not valid GeoJSON."})
        if not cd.get("geometry"):
            raise ValidationError({"geojson_file": "Upload a GeoJSON file or paste a geometry."})
        try:
            cd["geometry"] = geo.to_geojson(geo.parse_geojson(cd["geometry"]))
        except ValidationError as e:
            raise ValidationError({"geometry": e.messages})
        return cd


@admin.register(Boundary)
class BoundaryAdmin(admin.ModelAdmin):
    form = BoundaryAdminForm
    list_display = ("name", "level", "category", "parent", "code", "area_km2", "is_active", "dataset")
    list_filter = ("level", "is_active", "category", "dataset")
    search_fields = ("name", "code")
    autocomplete_fields = ("parent",)
    readonly_fields = ("min_x", "min_y", "max_x", "max_y", "area_km2")


# --------------------------------------------------------------------------- #
# Boundary dataset uploads (administrators upload / update MDB boundaries)
# --------------------------------------------------------------------------- #
class BoundaryDatasetForm(forms.ModelForm):
    RUN_CHOICES = [
        ("validate", "Validate only (dry run): check the file and show what would change"),
        ("import", "Validate and import now"),
        ("none", "Save without running"),
    ]
    run = forms.ChoiceField(choices=RUN_CHOICES, initial="validate", widget=forms.RadioSelect,
                            label="On save")

    class Meta:
        model = BoundaryDataset
        fields = ["title", "level", "file", "source", "effective_date", "mode", "derive_provinces",
                  "name_field", "name_format", "code_field", "parent_field", "category_field"]

    def clean(self):
        cd = super().clean()
        if cd.get("run") != "none" and not (cd.get("file") or (self.instance.pk and self.instance.file)):
            raise ValidationError({"file": "Upload a boundary file to validate or import."})
        if cd.get("derive_provinces") and cd.get("level") != "district":
            raise ValidationError({"derive_provinces": "Provinces can only be derived from a district file."})
        return cd


@admin.register(BoundaryDataset)
class BoundaryDatasetAdmin(admin.ModelAdmin):
    form = BoundaryDatasetForm
    list_display = ("title", "level", "status_badge", "feature_count", "created_count", "updated_count",
                    "retired_count", "derived_count", "uploaded_by", "uploaded_at", "imported_at")
    list_filter = ("level", "status")
    readonly_fields = ("status", "result_summary", "import_log", "uploaded_by", "uploaded_at", "imported_at",
                       "boundaries_link")
    actions = ["validate_selected", "import_selected"]
    fieldsets = (
        (None, {"fields": ("title", "level", "file", "source", "effective_date")}),
        ("Import options", {"fields": ("mode", "derive_provinces", "run"),
                            "description": "Boundaries are matched on their official code within the level. "
                                           "Existing records are updated in place; requests keep the extent "
                                           "they were submitted with."}),
        ("Field mapping (optional – detected automatically for MDB and OCHA COD-AB files)", {
            "classes": ("collapse",),
            "fields": ("name_field", "name_format", "code_field", "parent_field", "category_field")}),
        ("Result", {"fields": ("status", "result_summary", "boundaries_link", "import_log",
                               "uploaded_by", "uploaded_at", "imported_at")}),
    )

    def get_changeform_initial_data(self, request):
        return {"source": boundary_import.MDB_SOURCE, "mode": "replace"}

    @admin.display(description="Status")
    def status_badge(self, obj):
        colours = {"loaded": "#00602f", "validated": "#a05a0a", "failed": "#a3271a", "pending": "#777"}
        return format_html('<b style="color:{}">{}</b>', colours.get(obj.status, "#333"), obj.get_status_display())

    @admin.display(description="Summary")
    def result_summary(self, obj):
        if obj.status in ("pending",) or not obj.pk:
            return "—"
        return (f"{obj.feature_count} features · {obj.created_count} new · {obj.updated_count} updated · "
                f"{obj.retired_count} retired" + (f" · {obj.derived_count} provinces derived" if obj.derived_count else ""))

    @admin.display(description="Log")
    def import_log(self, obj):
        return format_html('<pre style="white-space:pre-wrap;max-height:28em;overflow:auto;margin:0">{}</pre>',
                           obj.log or "—")

    @admin.display(description="Boundaries from this upload")
    def boundaries_link(self, obj):
        if not obj.pk:
            return "—"
        n = obj.boundaries.count()
        url = reverse("admin:dcpr_boundary_changelist") + f"?dataset__id__exact={obj.pk}"
        return format_html('<a href="{}">{} boundaries</a>', url, n)

    def save_model(self, request, obj, form, change):
        if not change:
            obj.uploaded_by = request.user
        if form.cleaned_data.get("file") and change and "file" in form.changed_data:
            obj.status = BoundaryDataset.Status.PENDING
        super().save_model(request, obj, form, change)
        run = form.cleaned_data.get("run")
        if run in ("validate", "import"):
            self._run(request, obj, dry_run=(run == "validate"))

    def _run(self, request, obj, dry_run):
        if not obj.file:
            self.message_user(request, f"{obj.title}: no file to import (bundled data is loaded by "
                                       "'manage.py load_boundaries --bundled').", messages.WARNING)
            return
        try:
            res = boundary_import.run_upload(obj, dry_run=dry_run)
        except boundary_import.BoundaryImportError as e:
            self.message_user(request, f"{obj.title}: validation failed – " + " | ".join(e.problems[:3])
                              + (" …" if len(e.problems) > 3 else "") + " See the log for details.",
                              messages.ERROR)
            return
        level = messages.WARNING if res.warnings else messages.SUCCESS
        extra = f" {len(res.warnings)} warning(s), see the log." if res.warnings else ""
        hint = " Choose “Validate and import now” to apply it." if dry_run else ""
        self.message_user(request, f"{obj.title}: {res.summary()}{extra}{hint}", level)

    @admin.action(description="Validate selected uploads (dry run)")
    def validate_selected(self, request, queryset):
        for obj in queryset:
            self._run(request, obj, dry_run=True)

    @admin.action(description="Import selected uploads")
    def import_selected(self, request, queryset):
        order = {"country": 0, "province": 1, "district": 2, "municipality": 3, "ward": 4, "other": 5}
        for obj in sorted(queryset, key=lambda o: (order.get(o.level, 9), o.uploaded_at)):
            self._run(request, obj, dry_run=False)  # parents before children
