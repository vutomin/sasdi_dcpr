from django.apps import AppConfig


class DcprConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "dcpr"
    verbose_name = "DCPR – Data Capture Project Requests"
