from django import template

register = template.Library()


@register.simple_tag
def percent(n, total):
    try:
        return f"{(n / total) * 100:.1f}" if total else "0"
    except (TypeError, ZeroDivisionError):
        return "0"


@register.simple_tag
def mark(value, option):
    """Return an 'X' when value == option (for the printable paper-style form)."""
    return "X" if str(value) == str(option) else ""


@register.simple_tag
def mark_in(values, option):
    """'X' when option is among the selected values (multi-select fields)."""
    return "X" if str(option) in [str(v) for v in (values or [])] else ""


@register.filter
def mod(value, n):
    try:
        return int(value) % int(n)
    except (TypeError, ValueError, ZeroDivisionError):
        return 0
