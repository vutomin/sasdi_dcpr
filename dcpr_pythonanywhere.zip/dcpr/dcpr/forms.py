from django import forms
from django.conf import settings
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.forms import inlineformset_factory

import json

from django.core.exceptions import ValidationError

from . import geo
from .models import (
    Attachment, Boundary, CaptureRequest, ContactPerson, Dataset, Organisation, Project,
    validate_file_size,
)

ACCEPT = ",".join("." + e for e in settings.ATTACHMENT_ALLOWED_EXTENSIONS)


class DateInput(forms.DateInput):
    input_type = "date"


def textarea(rows=3):
    return forms.Textarea(attrs={"rows": rows})


# --------------------------------------------------------------------------- #
# Form E sections
# --------------------------------------------------------------------------- #
class OrganisationForm(forms.Form):
    """Not a ModelForm on purpose: organisations are shared, so we look up an
    existing one by name rather than editing it in place."""
    name = forms.CharField(label="Name of organisation", max_length=255)
    level = forms.ChoiceField(
        label="Level of organisation", choices=Organisation.Level.choices, widget=forms.RadioSelect
    )
    address = forms.CharField(label="Organisation address", widget=textarea(2))

    def save(self):
        d = self.cleaned_data
        org = Organisation.objects.filter(name__iexact=d["name"].strip(), level=d["level"]).first()
        if org is None:
            org = Organisation.objects.create(name=d["name"].strip(), level=d["level"], address=d["address"])
        elif org.address != d["address"]:
            # Keep the most recent address supplied by an applicant.
            org.address = d["address"]
            org.save(update_fields=["address"])
        return org


class ContactForm(forms.ModelForm):
    class Meta:
        model = ContactPerson
        fields = ["name", "designation", "phone_number", "fax_number", "email"]
        widgets = {"phone_number": forms.TextInput(attrs={"type": "tel"}),
                   "fax_number": forms.TextInput(attrs={"type": "tel"})}


class ProjectForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ["name", "start_date", "end_date", "estimated_cost"]
        widgets = {"start_date": DateInput(), "end_date": DateInput(),
                   "estimated_cost": forms.NumberInput(attrs={"step": "0.01", "min": "0"})}

    def clean(self):
        cd = super().clean()
        s, e = cd.get("start_date"), cd.get("end_date")
        if s and e and e < s:
            self.add_error("end_date", "End date cannot be before the start date.")
        return cd


def _choices(cls):
    return [c for c in cls.choices if c[0]]


class DatasetForm(forms.ModelForm):
    """One dataset to be produced by the project. Repeated via DatasetFormSet."""
    geographic_extents = forms.MultipleChoiceField(
        label="Geographic extent level", choices=_choices(Dataset.GeographicExtent),
        widget=forms.CheckboxSelectMultiple,
        help_text="The level or units the data is captured at (as on the paper form). Select all that apply.",
    )
    data_types = forms.MultipleChoiceField(
        label="Data type", choices=_choices(Dataset.DataType),
        widget=forms.CheckboxSelectMultiple, help_text="Select all that apply.",
    )
    capture_methods = forms.MultipleChoiceField(
        label="Method of capture", choices=_choices(Dataset.CaptureMethod),
        widget=forms.CheckboxSelectMultiple, help_text="Select all that apply.",
    )
    # Spatial extent, filled by the map picker (static/dcpr/extent-picker.js)
    boundary_ids = forms.CharField(required=False, widget=forms.HiddenInput(attrs={"data-role": "boundary-ids"}))
    extent_geojson = forms.CharField(required=False, widget=forms.HiddenInput(attrs={"data-role": "extent-geojson"}))
    extent_kind = forms.CharField(required=False, widget=forms.HiddenInput(attrs={"data-role": "extent-kind"}))

    class Meta:
        model = Dataset
        fields = [
            "title", "purpose", "lineage", "feature_description", "abstract",
            "geographic_extents", "geographic_extent_other", "data_types",
            "resolution", "attributes", "capture_methods", "method_details",
        ]
        widgets = {
            "purpose": textarea(3), "lineage": textarea(3), "feature_description": textarea(3),
            "abstract": textarea(4), "attributes": textarea(3), "method_details": textarea(3),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        inst = self.instance
        if inst.pk:
            self.fields["boundary_ids"].initial = ",".join(str(i) for i in inst.boundaries.values_list("pk", flat=True))
            if inst.custom_extent:
                self.fields["extent_geojson"].initial = json.dumps(inst.custom_extent)
                self.fields["extent_kind"].initial = inst.custom_extent_kind

    def clean_boundary_ids(self):
        raw = self.cleaned_data.get("boundary_ids") or ""
        try:
            ids = sorted({int(x) for x in raw.split(",") if x.strip()})
        except ValueError:
            raise ValidationError("Invalid boundary selection.")
        found = list(Boundary.objects.filter(pk__in=ids, is_active=True))
        if len(found) != len(ids):
            raise ValidationError("One of the selected boundaries no longer exists. Please reselect.")
        return found

    def clean_extent_geojson(self):
        g = geo.parse_geojson(self.cleaned_data.get("extent_geojson"))
        return geo.to_geojson(g) if g is not None else None

    def clean(self):
        cd = super().clean()
        if not self.errors.get("boundary_ids") and not self.errors.get("extent_geojson"):
            if not cd.get("boundary_ids") and not cd.get("extent_geojson"):
                self.add_error(None, "Set the dataset's geographic extent on the map: choose one or more "
                                     "predefined boundaries, or draw an area / enter a bounding box.")
        if cd.get("extent_kind") not in ("", None, "polygon", "bbox", "upload"):
            cd["extent_kind"] = "polygon"
        if Dataset.GeographicExtent.OTHER in (cd.get("geographic_extents") or []):
            if not cd.get("geographic_extent_other"):
                self.add_error("geographic_extent_other", "Please specify the other geographic extent.")
        else:
            cd["geographic_extent_other"] = ""
        return cd

    def save(self, commit=True):
        obj = super().save(commit=False)
        obj.custom_extent = self.cleaned_data.get("extent_geojson")
        obj.custom_extent_kind = (self.cleaned_data.get("extent_kind") or "polygon") if obj.custom_extent else ""
        if commit:
            obj.save()
            obj.boundaries.set(self.cleaned_data.get("boundary_ids") or [])
            obj.refresh_extent()
        return obj


class BaseDatasetFormSet(forms.BaseInlineFormSet):
    def clean(self):
        super().clean()
        if any(self.errors):
            return
        live = [f for f in self.forms if f.has_changed() or f.instance.pk]
        live = [f for f in live if not (self.can_delete and self._should_delete_form(f))]
        if not live:
            raise forms.ValidationError("Add at least one dataset.")
        titles = [f.cleaned_data.get("title", "").strip().lower() for f in live]
        if len(titles) != len(set(titles)):
            raise forms.ValidationError("Each dataset in a project needs a different title.")


DatasetFormSet = inlineformset_factory(
    Project, Dataset, form=DatasetForm, formset=BaseDatasetFormSet,
    extra=0, min_num=1, validate_min=True, can_delete=True,
)


class RequestForm(forms.ModelForm):
    class Meta:
        model = CaptureRequest
        fields = ["urgency", "data_usage_restrictions", "declarant_name",
                  "declarant_designation", "declaration_accepted"]
        widgets = {"urgency": forms.RadioSelect, "data_usage_restrictions": forms.RadioSelect}
        help_texts = {"declaration_accepted": ""}
        labels = {"declaration_accepted": "I confirm that the information supplied in this form is "
                                          "correct and serves as my electronic signature."}

    def __init__(self, *args, submitting=False, **kwargs):
        super().__init__(*args, **kwargs)
        self.submitting = submitting
        for f in ("urgency", "data_usage_restrictions"):
            self.fields[f].choices = [c for c in self.fields[f].choices if c[0]]

    def clean(self):
        cd = super().clean()
        if self.submitting and not cd.get("declaration_accepted"):
            self.add_error("declaration_accepted", "You must accept the declaration to submit.")
        return cd


# --------------------------------------------------------------------------- #
# Attachments
# --------------------------------------------------------------------------- #
class AttachmentForm(forms.ModelForm):
    class Meta:
        model = Attachment
        fields = ["category", "file", "description"]
        widgets = {"file": forms.ClearableFileInput(attrs={"accept": ACCEPT}),
                   "description": forms.TextInput(attrs={"placeholder": "e.g. Technical specification v2"})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["category"].choices = [
            c for c in Attachment.Category.choices if c[0] in Attachment.APPLICANT_CATEGORIES
        ]
        # Supporting documents are optional: a row without a file is simply ignored.
        self.fields["file"].required = False

    def has_changed(self):
        if not self.instance.pk and not (self.files and self.files.get(self.add_prefix("file"))):
            return False
        return super().has_changed()


class BaseAttachmentFormSet(forms.BaseInlineFormSet):
    def __init__(self, *args, user=None, **kwargs):
        self.user = user
        super().__init__(*args, **kwargs)

    def get_queryset(self):
        qs = super().get_queryset().filter(category__in=Attachment.APPLICANT_CATEGORIES)
        # Only the applicant's own uploads are editable here (not documents added by the office).
        if self.instance.pk:
            qs = qs.filter(uploaded_by=self.instance.applicant_id)
        return qs

    def save_new(self, form, commit=True):
        if not form.cleaned_data.get("file"):
            return None
        obj = form.save(commit=False)
        obj.request = self.instance
        obj.uploaded_by = self.user
        if commit:
            obj.save()
        return obj


AttachmentFormSet = inlineformset_factory(
    CaptureRequest, Attachment, form=AttachmentForm, formset=BaseAttachmentFormSet,
    extra=1, can_delete=True,
)


class MultipleFileInput(forms.ClearableFileInput):
    allow_multiple_selected = True


class MultipleFileField(forms.FileField):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault("widget", MultipleFileInput(attrs={"accept": ACCEPT}))
        super().__init__(*args, **kwargs)

    def clean(self, data, initial=None):
        single = super().clean
        if isinstance(data, (list, tuple)):
            return [single(d, initial) for d in data if d]
        return [single(data, initial)] if data else []


def _check_files(files):
    from django.core.validators import FileExtensionValidator
    ext = FileExtensionValidator(settings.ATTACHMENT_ALLOWED_EXTENSIONS)
    for f in files:
        ext(f)
        validate_file_size(f)
    return files


class SupplementaryUploadForm(forms.Form):
    """Applicant/office adds documents after submission."""
    category = forms.ChoiceField(choices=[])
    files = MultipleFileField(label="Files")
    description = forms.CharField(max_length=255, required=False)

    def __init__(self, *args, categories=None, **kwargs):
        super().__init__(*args, **kwargs)
        cats = categories or Attachment.APPLICANT_CATEGORIES
        self.fields["category"].choices = [c for c in Attachment.Category.choices if c[0] in cats]

    def clean_files(self):
        return _check_files(self.cleaned_data["files"])


class ActionForm(forms.Form):
    comment = forms.CharField(widget=textarea(3), required=False)
    files = MultipleFileField(required=False)
    file_reference = forms.CharField(max_length=100, required=False, label="Filing reference")

    def __init__(self, *args, transition=None, req=None, **kwargs):
        super().__init__(*args, **kwargs)
        t = transition
        if t:
            self.fields["comment"].label = t.comment_label_for(req) if req else t.comment_label
            self.fields["comment"].required = t.comment_required
            self.fields["files"].label = t.attachment_label_for(req) if req else t.attachment_label
            self.fields["files"].required = t.attachment_required
            if not t.attachment_category:
                del self.fields["files"]
            if not t.asks_file_reference:
                del self.fields["file_reference"]

    def clean_files(self):
        return _check_files(self.cleaned_data.get("files") or [])


# --------------------------------------------------------------------------- #
# Register filters / accounts
# --------------------------------------------------------------------------- #
class RegisterFilterForm(forms.Form):
    q = forms.CharField(required=False, label="Search",
                        widget=forms.TextInput(attrs={"placeholder": "Reference, project, dataset, organisation"}))
    form_type = forms.ChoiceField(required=False, choices=[("", "All forms")] + list(CaptureRequest.FormType.choices))
    status = forms.ChoiceField(required=False, choices=[("", "All statuses")] + [
        c for c in CaptureRequest.Status.choices if c[0] != "draft"])
    outcome = forms.ChoiceField(required=False, choices=[("", "All outcomes"), ("pending", "Pending")] + [
        c for c in CaptureRequest.Outcome.choices if c[0]])
    urgency = forms.ChoiceField(required=False, choices=[("", "Any urgency")] + list(CaptureRequest.Urgency.choices))
    date_from = forms.DateField(required=False, widget=DateInput(), label="Submitted from")
    date_to = forms.DateField(required=False, widget=DateInput(), label="to")


class SignUpForm(UserCreationForm):
    first_name = forms.CharField(max_length=150)
    last_name = forms.CharField(max_length=150)
    email = forms.EmailField()

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("username", "first_name", "last_name", "email")

    def clean_email(self):
        email = self.cleaned_data["email"]
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("An account with this email already exists.")
        return email


class SpatialSearchForm(forms.Form):
    """Find datasets by where they will be captured (and optional attribute filters)."""
    MODE_CHOICES = [("intersects", "Overlaps the area"), ("within", "Lies completely within the area")]
    q = forms.CharField(required=False, label="Text",
                        widget=forms.TextInput(attrs={"placeholder": "Reference, project, dataset or organisation"}))
    boundary_ids = forms.CharField(required=False, widget=forms.HiddenInput(attrs={"data-role": "boundary-ids"}))
    extent_geojson = forms.CharField(required=False, widget=forms.HiddenInput(attrs={"data-role": "extent-geojson"}))
    extent_kind = forms.CharField(required=False, widget=forms.HiddenInput(attrs={"data-role": "extent-kind"}))
    mode = forms.ChoiceField(choices=MODE_CHOICES, initial="intersects", widget=forms.RadioSelect, label="Match")
    form_type = forms.ChoiceField(required=False, choices=[("", "All forms")] + list(CaptureRequest.FormType.choices))
    status = forms.ChoiceField(required=False, label="Status", choices=[("", "Any status")] + [
        c for c in CaptureRequest.Status.choices if c[0] != "draft"])
    data_type = forms.ChoiceField(required=False, choices=[("", "Any data type")] + _choices(Dataset.DataType))
    capture_method = forms.ChoiceField(required=False, label="Method of capture",
                                       choices=[("", "Any method")] + _choices(Dataset.CaptureMethod))

    def clean_boundary_ids(self):
        raw = self.cleaned_data.get("boundary_ids") or ""
        ids = {int(x) for x in raw.split(",") if x.strip().isdigit()}
        return list(Boundary.objects.filter(pk__in=ids))

    def clean_extent_geojson(self):
        return geo.parse_geojson(self.cleaned_data.get("extent_geojson"))

    def search_area(self):
        """Union of chosen boundaries and drawn area, as a shapely geometry (or None)."""
        from shapely.geometry import shape
        from shapely.ops import unary_union
        parts = [shape(b.geometry) for b in self.cleaned_data.get("boundary_ids") or []]
        if self.cleaned_data.get("extent_geojson") is not None:
            parts.append(self.cleaned_data["extent_geojson"])
        return unary_union(parts) if parts else None
