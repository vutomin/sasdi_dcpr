"""
Import administrative boundaries (MDB or any GeoJSON/shapefile) into Boundary records.

Used by:
  * the admin "Boundary dataset uploads" screen (upload / validate / apply),
  * `python manage.py load_boundaries`,
  * migration 0005, which loads the bundled MDB 2018 district and local municipal boundaries.

All checks run before anything is written. A dry run performs the whole import
inside a transaction and rolls it back, so administrators see exactly what would change.
"""
import gzip
import json
import os
import zipfile
from collections import defaultdict
from pathlib import Path

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import transaction
from shapely.geometry import shape
from shapely.ops import unary_union

from . import geo

DATA_DIR = Path(__file__).resolve().parent / "data"
MDB_SOURCE = "Municipal Demarcation Board (MDB) 2018 boundaries"
OCHA_SOURCE = "OCHA COD-AB South Africa (MDB / Stats SA), valid 2020-11-09"
BUNDLED = [
    # (file, level, derive provinces, title, source) – loaded parents first
    (DATA_DIR / "ocha_2020_country.geojson.gz", "country", False,
     "South Africa national boundary (OCHA COD-AB 2020, bundled)", OCHA_SOURCE),
    (DATA_DIR / "ocha_2020_provinces.geojson.gz", "province", False,
     "Provincial boundaries (OCHA COD-AB 2020, bundled)", OCHA_SOURCE),
    (DATA_DIR / "mdb_2018_district_municipalities.geojson.gz", "district", False,
     "MDB 2018 district municipal boundaries (bundled)", MDB_SOURCE),
    (DATA_DIR / "mdb_2018_local_municipalities.geojson.gz", "municipality", False,
     "MDB 2018 local municipal boundaries (bundled)", MDB_SOURCE),
    (DATA_DIR / "ocha_2020_wards.geojson.gz", "ward", False,
     "Ward boundaries (OCHA COD-AB 2020, bundled)", OCHA_SOURCE),
]
# Known spelling errors in published source data
NAME_FIXES = {"Nothern Cape": "Northern Cape"}

PROVINCE_NAMES = {
    "EC": "Eastern Cape", "FS": "Free State", "GT": "Gauteng", "GP": "Gauteng", "KZN": "KwaZulu-Natal",
    "LIM": "Limpopo", "LP": "Limpopo", "MP": "Mpumalanga", "NW": "North West", "NC": "Northern Cape",
    "WC": "Western Cape",
}
PARENT_LEVEL = {"ward": "municipality", "municipality": "district", "district": "province", "province": "country"}

# Field presets, tried in order: MDB shapefile/GeoJSON names, then OCHA COD-AB (zaf_adminN), then generic.
# OCHA files keep the MDB code in adm<N>_name1 (e.g. EC, DC44, KZN263), so both sources link together.
PRESETS = {
    "country": [
        {"name": "adm0_name", "code": "adm0_pcode", "parent": "", "category": ""},
        {"name": "NAME", "code": "ISO", "parent": "", "category": ""},
    ],
    "province": [
        {"name": "adm1_name", "code": "adm1_name1", "parent": "adm0_pcode", "category": ""},
        {"name": "PROVINCENA", "code": "PROVINCE", "parent": "", "category": ""},
        {"name": "PROVNAME", "code": "PROVINCE", "parent": "", "category": ""},
        {"name": "PROVINCE_N", "code": "PROVINCE", "parent": "", "category": ""},
    ],
    "district": [
        {"name": "DISTRICT_N", "code": "DISTRICT", "parent": "PROVINCE", "category": "CATEGORY"},
        {"name": "DISTRICTNA", "code": "DISTRICT", "parent": "PROVINCE", "category": "CATEGORY"},
        {"name": "adm2_name", "code": "adm2_name1", "parent": "adm1_name1", "category": ""},
    ],
    "municipality": [
        {"name": "MUNICNAME", "code": "CAT_B", "parent": "DISTRICT", "category": "CATEGORY"},
        {"name": "MUNICNAME", "code": "MUNICCODE", "parent": "DISTRICT", "category": "CATEGORY"},
        {"name": "adm3_name", "code": "adm3_name1", "parent": "adm2_name1", "category": ""},
    ],
    "ward": [
        # OCHA: ward number in adm4_name ("001"); parent municipality code in adm3_id (e.g. LIM344)
        {"name": "adm4_name", "code": "adm4_pcode", "parent": "adm3_id", "category": "",
         "name_format": "{adm3_name} Ward {adm4_name:int}"},
        # MDB ward shapefiles
        {"name": "WardNo", "code": "WardID", "parent": "CAT_B", "category": "",
         "name_format": "{Municipali} Ward {WardNo:int}"},
        {"name": "WARDNO", "code": "WARD_ID", "parent": "CAT_B", "category": "",
         "name_format": "{MUNICNAME} Ward {WARDNO:int}"},
    ],
    "*": [
        {"name": "name", "code": "code", "parent": "parent_code", "category": "category"},
        {"name": "NAME", "code": "CODE", "parent": "PARENT", "category": "CATEGORY"},
    ],
}


class BoundaryImportError(Exception):
    def __init__(self, problems):
        self.problems = problems if isinstance(problems, list) else [problems]
        super().__init__("; ".join(self.problems[:5]))


class Result:
    def __init__(self):
        self.features = self.created = self.updated = self.retired = self.derived = 0
        self.warnings = []
        self.lines = []
        self.dry_run = False

    def log(self, msg):
        self.lines.append(msg)

    @property
    def text(self):
        out = list(self.lines)
        if self.warnings:
            out.append(f"{len(self.warnings)} warning(s):")
            out.extend("  - " + w for w in self.warnings[:100])
        return "\n".join(out)

    def summary(self):
        verb = "Would import" if self.dry_run else "Imported"
        s = (f"{verb} {self.features} features: {self.created} new, {self.updated} updated, "
             f"{self.retired} retired")
        if self.derived:
            s += f", {self.derived} provinces derived"
        return s + "."


# --------------------------------------------------------------------------- #
# Reading
# --------------------------------------------------------------------------- #
def read_collection(path):
    """Return (features, crs_note). Features are (properties, geometry dict)."""
    path = str(path)
    lower = path.lower()
    if lower.endswith((".geojson", ".json", ".geojson.gz", ".json.gz", ".gz")):
        opener = gzip.open if lower.endswith(".gz") else open
        try:
            with opener(path, "rt", encoding="utf-8-sig") as fh:
                data = json.load(fh)
        except (json.JSONDecodeError, UnicodeDecodeError, OSError) as e:
            raise BoundaryImportError(f"The file is not valid GeoJSON ({e.__class__.__name__}).")
        _check_geojson_crs(data.get("crs"))
        if data.get("type") == "FeatureCollection":
            feats = data.get("features") or []
        elif data.get("type") == "Feature":
            feats = [data]
        else:
            raise BoundaryImportError("The GeoJSON must be a FeatureCollection of polygons.")
        return [(f.get("properties") or {}, f.get("geometry")) for f in feats]
    if lower.endswith((".shp", ".zip")):
        return _read_shapefile(path)
    raise BoundaryImportError("Unsupported file type. Upload GeoJSON (.geojson/.json, optionally .gz) "
                              "or a zipped shapefile (.zip).")


def _check_geojson_crs(crs):
    if not crs:
        return  # GeoJSON default is WGS84 lon/lat
    name = str((crs.get("properties") or {}).get("name", "")).upper()
    if any(k in name for k in ("4326", "CRS84", "WGS84", "4148")):  # 4148 = Hartebeesthoek94 (lon/lat)
        return
    raise BoundaryImportError(
        f"The file's coordinate system is {name or 'unknown'}. Re-project it to WGS84 "
        "(EPSG:4326) longitude/latitude first, e.g. in QGIS 'Export → Save Features As' or "
        "ogr2ogr -t_srs EPSG:4326.")


def _read_shapefile(path):
    try:
        import shapefile  # pyshp
    except ImportError:
        raise BoundaryImportError("Reading shapefiles needs the pyshp package (pip install pyshp).")
    if path.lower().endswith(".zip"):
        zf = zipfile.ZipFile(path)
        names = zf.namelist()
        shp = next((n for n in names if n.lower().endswith(".shp")), None)
        if not shp:
            raise BoundaryImportError("The zip file does not contain a .shp file.")
        base = shp[:-4]
        find = lambda ext: next((n for n in names if n.lower() == (base + ext).lower()), None)
        if not find(".dbf") or not find(".shx"):
            raise BoundaryImportError("The zipped shapefile must include the .shp, .shx and .dbf files.")
        prj = find(".prj")
        _check_prj(zf.read(prj).decode("latin-1") if prj else "")
        reader = shapefile.Reader(shp=zf.open(shp), dbf=zf.open(find(".dbf")), shx=zf.open(find(".shx")))
    else:
        prj = path[:-4] + ".prj"
        _check_prj(open(prj, encoding="latin-1").read() if os.path.exists(prj) else "")
        reader = shapefile.Reader(path)
    return [(sr.record.as_dict(), sr.shape.__geo_interface__) for sr in reader.iterShapeRecords()]


def _check_prj(text):
    t = text.upper()
    if "PROJCS" in t:
        raise BoundaryImportError("The shapefile is in a projected coordinate system. Re-project it to "
                                  "WGS84 (EPSG:4326) first.")


# --------------------------------------------------------------------------- #
# Field mapping
# --------------------------------------------------------------------------- #
def detect_mapping(level, keys, overrides=None):
    keys = set(keys)
    overrides = {k: v for k, v in (overrides or {}).items() if v}
    chosen = None
    for preset in PRESETS.get(level, []) + PRESETS["*"]:
        if preset["name"] in keys and preset["code"] in keys:
            chosen = dict(preset)
            break
    chosen = chosen or {"name": "", "code": "", "parent": "", "category": ""}
    chosen.setdefault("name_format", "")
    chosen.update(overrides)
    for k in ("parent", "category"):
        if chosen.get(k) and chosen[k] not in keys:
            chosen[k] = ""
    return chosen


def format_name(fmt, props):
    """'{adm3_name} Ward {adm4_name:int}' -> 'Makhado Ward 1'. ':int' strips leading zeros."""
    import re

    def repl(m):
        key, conv = m.group(1), m.group(2)
        val = props.get(key)
        if val is None:
            return ""
        if conv == "int":
            try:
                return str(int(float(val)))
            except (TypeError, ValueError):
                return str(val)
        return str(val)
    return re.sub(r"\{([^{}:]+)(?::(\w+))?\}", repl, fmt).strip()


def infer_category(level, code, given):
    """MDB category when the file has none: A metro, B local, C district."""
    if given:
        return given
    if level == "district":
        return "C" if code.upper().startswith("DC") else "A"
    if level == "municipality":
        return "A" if code.isalpha() and len(code) == 3 else "B"
    return ""


# --------------------------------------------------------------------------- #
# Import
# --------------------------------------------------------------------------- #
def import_file(Boundary, path, level, *, mapping=None, mode="replace", derive_provinces=False,
                source=MDB_SOURCE, dataset_id=None, dry_run=False, tolerance=None):
    """Validate and import a boundary file. Returns Result; raises BoundaryImportError on bad input.

    Works with the real Boundary model or a migration's historical model.
    """
    res = Result()
    res.dry_run = dry_run
    if level not in PARENT_LEVEL and level not in ("country", "other"):
        raise BoundaryImportError(f"Unknown level {level!r}.")
    tol = tolerance if tolerance is not None else getattr(settings, "DCPR_BOUNDARY_TOLERANCE", 0.0005)

    feats = read_collection(path)
    if not feats:
        raise BoundaryImportError("The file contains no features.")
    types = {(g or {}).get("type") for _, g in feats}
    if not types & {"Polygon", "MultiPolygon", "GeometryCollection"}:
        raise BoundaryImportError(
            f"This file contains {', '.join(sorted(t for t in types if t)) or 'no'} geometries, not polygons. "
            "Only area boundaries (polygons) can be used as geographic extents; admin points and "
            "boundary lines files are not needed.")
    keys = set().union(*(set(p) for p, _ in feats))
    m = detect_mapping(level, keys, mapping)
    missing = [k for k in ("name", "code") if not m.get(k) or m[k] not in keys]
    if m.get("name_format") and "name" in missing:
        missing.remove("name")
        if not format_name(m["name_format"], feats[0][0]):
            missing.append("name (the name pattern produced an empty name)")
    if missing:
        raise BoundaryImportError(
            f"Could not find the {' and '.join(missing)} field(s). Set them explicitly. "
            f"Fields in this file: {', '.join(sorted(keys))}.")
    res.log(f"Level: {level}. Fields: name={m.get('name_format') or m['name']}, code={m['code']}, "
            f"parent={m.get('parent') or '—'}, category={m.get('category') or '—'}. Tolerance {tol}°.")

    # ---- validate everything first -------------------------------------------------
    problems, rows, seen = [], [], set()
    for i, (props, geom) in enumerate(feats, 1):
        name = format_name(m["name_format"], props) if m.get("name_format") else str(props.get(m["name"]) or "").strip()
        name = NAME_FIXES.get(name, name)
        code = str(props.get(m["code"]) or "").strip()
        label = f"Feature {i}" + (f" ({name or code})" if name or code else "")
        if not name:
            problems.append(f"{label}: no name in field {m['name']}.")
        if not code:
            problems.append(f"{label}: no code in field {m['code']}.")
        elif code in seen:
            problems.append(f"{label}: duplicate code {code}.")
        seen.add(code)
        try:
            g = geo.parse_geojson(geom)
            if g is None:
                raise ValidationError("no geometry")
        except ValidationError as e:
            problems.append(f"{label}: {' '.join(e.messages)}")
            continue
        if tol:
            g = geo._as_multipolygon(g.simplify(tol, preserve_topology=True))
        rows.append({
            "name": name, "code": code, "geom": g,
            "parent": str(props.get(m["parent"]) or "").strip() if m.get("parent") else "",
            "category": infer_category(level, code, str(props.get(m["category"]) or "").strip()[:2]
                                       if m.get("category") else ""),
        })
        if len(problems) > 50:
            break
    if problems:
        raise BoundaryImportError(problems)
    res.features = len(rows)

    # ---- write ------------------------------------------------------------------------
    with transaction.atomic():
        if derive_provinces and level == "district":
            _derive_provinces(Boundary, rows, res, source, dataset_id, mode, tol)
        existing = {b.code: b for b in Boundary.objects.filter(level=level)}
        parent_level = PARENT_LEVEL.get(level)
        parents = ({b.code: b.pk for b in Boundary.objects.filter(level=parent_level, is_active=True)}
                   if parent_level else {})
        no_parent = []
        for r in rows:
            b = existing.get(r["code"])
            is_new = b is None
            if is_new:
                b = Boundary(level=level, code=r["code"])
            b.name, b.category, b.source, b.is_active = r["name"], r["category"], source, True
            b.dataset_id = dataset_id
            b.geometry = geo.to_geojson(r["geom"])
            if parent_level and r["parent"]:
                b.parent_id = parents.get(r["parent"])
                if b.parent_id is None:
                    no_parent.append(f"{r['name']} ({r['code']}): parent {parent_level} {r['parent']} not found")
            geo.prepare_boundary(b)
            b.save()
            res.created += is_new
            res.updated += not is_new
        if mode == "replace":
            stale = Boundary.objects.filter(level=level, is_active=True).exclude(code__in=[r["code"] for r in rows])
            for b in stale:
                res.warnings.append(f"Retired {level} {b.name} ({b.code}): not in the new file.")
            res.retired += stale.update(is_active=False)
        res.warnings.extend(no_parent)
        # children pointing at retired parents
        child_level = {v: k for k, v in PARENT_LEVEL.items()}.get(level)
        if child_level:
            orphans = Boundary.objects.filter(level=child_level, is_active=True, parent__is_active=False).count()
            if orphans:
                res.warnings.append(f"{orphans} active {child_level} boundaries point to a retired {level}. "
                                    f"Upload the matching {child_level} file to relink them.")
        res.log(res.summary())
        if dry_run:
            transaction.set_rollback(True)
    return res


def _derive_provinces(Boundary, rows, res, source, dataset_id, mode, tol):
    groups = defaultdict(list)
    for r in rows:
        if r["parent"]:
            groups[r["parent"]].append(r["geom"])
    if not groups:
        res.warnings.append("Could not derive provinces: no province codes in the district file.")
        return
    existing = {b.code: b for b in Boundary.objects.filter(level="province")}
    for code, geoms in sorted(groups.items()):
        u = unary_union([g.buffer(0.0002) for g in geoms]).buffer(-0.0002)  # close slivers between districts
        u = geo._as_multipolygon(u.simplify(tol, preserve_topology=True) if tol else u)
        b = existing.get(code) or Boundary(level="province", code=code)
        b.name = PROVINCE_NAMES.get(code, b.name or code)
        b.category, b.source, b.is_active, b.dataset_id = "", f"Derived from districts · {source}", True, dataset_id
        b.parent_id = None
        b.geometry = geo.to_geojson(u)
        geo.prepare_boundary(b)
        b.save()
        res.derived += 1
    if mode == "replace":
        res.retired += Boundary.objects.filter(level="province", is_active=True).exclude(code__in=list(groups)).update(is_active=False)
    res.log(f"Derived {len(groups)} provinces from district province codes.")


def run_upload(upload, dry_run=False):
    """Run (or validate) a BoundaryDataset upload and store the outcome on it."""
    from django.utils import timezone

    from .models import Boundary
    mapping = {"name": upload.name_field, "code": upload.code_field,
               "parent": upload.parent_field, "category": upload.category_field,
               "name_format": getattr(upload, "name_format", "")}
    source = upload.source + (f" ({upload.effective_date:%Y-%m-%d})" if upload.effective_date else "")
    try:
        res = import_file(Boundary, upload.file.path, upload.level, mapping=mapping, mode=upload.mode,
                          derive_provinces=upload.derive_provinces, source=source,
                          dataset_id=upload.pk, dry_run=dry_run)
    except BoundaryImportError as e:
        upload.status = upload.Status.FAILED
        upload.log = "Validation failed:\n" + "\n".join("  - " + p for p in e.problems[:60])
        upload.save()
        raise
    upload.feature_count = res.features
    upload.created_count, upload.updated_count = res.created, res.updated
    upload.retired_count, upload.derived_count = res.retired, res.derived
    upload.status = upload.Status.VALIDATED if dry_run else upload.Status.LOADED
    if not dry_run:
        upload.imported_at = timezone.now()
    upload.log = ("DRY RUN, nothing was changed.\n" if dry_run else "") + res.text
    upload.save()
    return res


def load_bundled(Boundary, BoundaryDataset=None, skip_existing=True, levels=None):
    """Load the boundary files shipped with the app (migrations 0005 and 0007, `load_boundaries --bundled`).

    With skip_existing, a bundle already recorded as a BoundaryDataset (by title) is not loaded again,
    so upgrades only add the layers that are missing.
    """
    from django.utils import timezone
    results = []
    for path, level, derive, title, source in BUNDLED:
        if levels and level not in levels:
            continue
        if not path.exists():
            continue
        if skip_existing and BoundaryDataset is not None and BoundaryDataset.objects.filter(title=title).exists():
            continue
        upload_id = None
        if BoundaryDataset is not None:
            upload_id = BoundaryDataset.objects.create(
                title=title, level=level, source=source, mode="replace", derive_provinces=derive,
                status="loaded").pk
        res = import_file(Boundary, path, level, mode="replace", derive_provinces=derive, source=source,
                          dataset_id=upload_id, tolerance=0)  # bundled files are already simplified
        if BoundaryDataset is not None:
            BoundaryDataset.objects.filter(pk=upload_id).update(
                feature_count=res.features, created_count=res.created, updated_count=res.updated,
                retired_count=res.retired, derived_count=res.derived, log=res.text, imported_at=timezone.now())
        results.append((title, res))
    return results
