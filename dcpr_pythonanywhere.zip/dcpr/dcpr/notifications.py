"""Email notifications. Failures are logged and never block the workflow."""
import logging

from django.conf import settings
from django.core.mail import send_mail
from django.urls import reverse

from .roles import CHAIRPERSON, NSIF, SUBCOMMITTEE, users_in_role

logger = logging.getLogger(__name__)
SITE_URL = getattr(settings, "SITE_URL", "http://localhost:8000")


def _send(subject, body, recipients):
    recipients = sorted({r for r in recipients if r})
    if not recipients:
        return
    try:
        send_mail(subject, body, settings.DEFAULT_FROM_EMAIL, recipients)
    except Exception:  # pragma: no cover - mail misconfiguration should not break the app
        logger.exception("Could not send notification %r", subject)


def _link(req):
    return SITE_URL + reverse("dcpr:detail", args=[req.pk])


def _emails(role):
    return [u.email for u in users_in_role(role)]


def _applicant_emails(req):
    return [req.contact.email, req.applicant.email]


def submitted(req):
    _send(
        f"[{req.reference_number}] Spatial data capture {req.noun} received (Form {req.form_type})",
        f"Dear {req.contact.name},\n\nYour {req.noun} \"{req.project.name}\" has been received "
        f"and allocated reference {req.reference_number}.\n\nTrack it here: {_link(req)}\n\nNSIF",
        _applicant_emails(req),
    )
    _send(
        f"[{req.reference_number}] New {req.noun} (Form {req.form_type}) – {req.organisation}",
        f"A new {req.get_form_type_display()} was submitted and awaits acknowledgement.\n\n{_link(req)}",
        _emails(NSIF) + list(getattr(settings, "NSIF_NOTIFY_EMAILS", [])),
    )


def resubmitted(req):
    _send(
        f"[{req.reference_number}] Amended {req.noun} resubmitted – {req.organisation}",
        f"The applicant has amended and resubmitted \"{req.project.name}\".\n\n{_link(req)}",
        _emails(NSIF) + list(getattr(settings, "NSIF_NOTIFY_EMAILS", [])),
    )
    _send(
        f"[{req.reference_number}] Amended {req.noun} received",
        f"Dear {req.contact.name},\n\nYour amended {req.noun} \"{req.project.name}\" has been "
        f"received and will be processed again.\n\n{_link(req)}\n\nNSIF",
        _applicant_emails(req),
    )


def transitioned(req, t, comment=""):
    ref = req.reference_number
    if t.name == "refer_back":
        _send(
            f"[{ref}] Your {req.noun} has been referred back for amendments",
            f"Dear {req.contact.name},\n\nYour {req.noun} \"{req.project.name}\" has been referred "
            f"back to you for the following amendments:\n\n{comment}\n\n"
            f"Please update and resubmit it here: {_link(req)}\n\nNSIF",
            _applicant_emails(req),
        )
        if req.returned_from in ("adjudication", "awaiting_signature"):
            # Referred back by the Sub-committee or Chairperson: keep NSIF informed.
            _send(
                f"[{ref}] {req.Noun} referred back for amendments",
                f"\"{req.project.name}\" was referred back to the applicant.\n\nReason:\n{comment}\n\n{_link(req)}",
                _emails(NSIF),
            )
    elif t.name == "acknowledge":
        _send(
            f"[{ref}] {req.Noun} acknowledged",
            f"Dear {req.contact.name},\n\nNSIF acknowledges receipt of your {req.noun} \"{req.project.name}\".\n"
            "It will be assessed and adjudicated by the CSI Data Sub-committee.\n"
            f"\n{_link(req)}\n\nNSIF",
            _applicant_emails(req),
        )
    elif t.name == "send_for_adjudication":
        _send(f"[{ref}] Adjudication pack ready",
              f"An adjudication pack for the {req.noun} \"{req.project.name}\" awaits the Sub-committee.\n\n{_link(req)}",
              _emails(SUBCOMMITTEE))
    elif t.name in ("criteria_met", "criteria_not_met"):
        _send(f"[{ref}] Outcome letter awaiting signature",
              f"The Sub-committee has resolved on the {req.noun}: {req.get_outcome_display()}.\n"
              f"Please sign the outcome letter.\n\n{_link(req)}",
              _emails(CHAIRPERSON))
    elif t.name == "sign_letter":
        _send(f"[{ref}] Letter signed – notify applicant",
              f"The Chairperson has signed the outcome letter.\n\n{_link(req)}", _emails(NSIF))
    elif t.name == "notify_applicant":
        _send(
            f"[{ref}] Outcome of your spatial data capture {req.noun}: {req.get_outcome_display()}",
            f"Dear {req.contact.name},\n\nYour {req.noun} \"{req.project.name}\" was "
            f"{req.get_outcome_display().lower()}.\n\n"
            + (f"{comment}\n\n" if comment else "")
            + f"The signed letter is available here: {_link(req)}\n\nNSIF",
            _applicant_emails(req),
        )
