"""
Workflow for spatial data capture requests.

Form E1 follows process NSIF_B TD.5 "Request to Capture Spatial Data Projects
Request (Non Data Custodians)":

  Applicant        Complete Form E ................................ submit
  NSIF             Acknowledge request + update register ......... acknowledge
  NSIF             Preliminary assessment, draft letters,
                   prepare adjudication pack ...................... send_for_adjudication
  CSI Data S-C     Does request meet criteria?  Y / N ............. criteria_met / criteria_not_met
  Chairperson      Sign letter (successful / unsuccessful) ........ sign_letter
  NSIF             Notify applicant (successful / unsuccessful) ... notify_applicant
  NSIF             Scan & file all documentation + update register  file_and_close
  Chairperson      Provide feedback to CSI on all requests ........ CSI feedback report (views.report)

At any stage before the letter is signed, the role holding the request may
refer it back to the applicant for amendments (refer_back). The applicant
edits and resubmits; it re-enters the process at "Submitted" (NSIF).

Form E2 (Base Dataset Custodian notification of intention to capture) follows the
same steps; only the wording differs ("notification" instead of "request").
Wording templates below use {noun} / {Noun}, filled from CaptureRequest.noun.
"""
from dataclasses import dataclass, field

from django.db import transaction
from django.utils import timezone

from . import notifications
from .models import Attachment, CaptureRequest, WorkflowEvent
from .roles import CHAIRPERSON, NSIF, SUBCOMMITTEE, has_role

S = CaptureRequest.Status
O = CaptureRequest.Outcome
E1, E2 = CaptureRequest.FormType.E1, CaptureRequest.FormType.E2


@dataclass(frozen=True)
class Transition:
    name: str
    label: str
    sources: tuple
    target: str
    roles: tuple
    form_types: tuple = (E1, E2)
    outcome: str | None = None
    style: str = "primary"
    help: str = ""
    comment_label: str = "Comment"
    comment_required: bool = False
    comment_field: str | None = None          # CaptureRequest field the comment is stored in
    attachment_category: str | None = None
    attachment_label: str = "Attach documents"
    attachment_required: bool = False
    asks_file_reference: bool = False
    register_note: bool = False               # step includes "Update register"
    requires_outcome: tuple = field(default_factory=tuple)
    # Optional per-stage role override, e.g. who may refer back at each stage.
    roles_by_status: dict = field(default_factory=dict, hash=False, compare=False)

    def roles_for(self, req):
        return self.roles_by_status.get(req.status, self.roles)

    @staticmethod
    def _fill(text, req):
        return text.format(noun=req.noun, Noun=req.Noun) if text else text

    def label_for(self, req):
        if self.name == "sign_letter" and req.outcome:
            word = "successful" if req.outcome == O.APPROVED else "unsuccessful"
            return f"Sign letter for {word} {req.noun}"
        if self.name == "notify_applicant" and req.outcome:
            word = "successful" if req.outcome == O.APPROVED else "unsuccessful"
            return f"Notify applicant: {word} {req.noun}"
        return self._fill(self.label, req)

    def help_for(self, req):
        return self._fill(self.help, req)

    def comment_label_for(self, req):
        return self._fill(self.comment_label, req)

    def attachment_label_for(self, req):
        return self._fill(self.attachment_label, req)


TRANSITIONS = {
    t.name: t
    for t in [
        Transition(
            name="acknowledge",
            label="Acknowledge {noun}",
            sources=(S.SUBMITTED,),
            target=S.ACKNOWLEDGED,
            roles=(NSIF,),
            help="Acknowledges receipt to the applicant and records the {noun} in the "
                 "Spatial Data Capture Project Register.",
            attachment_category=Attachment.Category.ACKNOWLEDGEMENT,
            attachment_label="Acknowledgement letter (optional)",
            register_note=True,
        ),
        Transition(
            name="refer_back",
            label="Refer back to applicant for amendments",
            # Each role may refer the application back at the stage where it holds the request.
            sources=(S.SUBMITTED, S.ACKNOWLEDGED, S.IN_ADJUDICATION, S.AWAITING_SIGNATURE),
            target=S.RETURNED,
            roles=(NSIF, SUBCOMMITTEE, CHAIRPERSON),
            roles_by_status={
                S.SUBMITTED: (NSIF,),
                S.ACKNOWLEDGED: (NSIF,),
                S.IN_ADJUDICATION: (SUBCOMMITTEE,),
                S.AWAITING_SIGNATURE: (CHAIRPERSON,),
            },
            style="warning",
            help="Returns the {noun} to the applicant to amend and resubmit. "
                 "The reference number is kept; the resubmission starts again at NSIF.",
            comment_label="Amendments required (sent to the applicant)",
            comment_required=True,
            attachment_category=Attachment.Category.OTHER,
            attachment_label="Marked-up documents for the applicant (optional)",
        ),
        Transition(
            name="send_for_adjudication",
            label="Submit adjudication pack to CSI Data Sub-committee",
            sources=(S.ACKNOWLEDGED,),
            target=S.IN_ADJUDICATION,
            roles=(NSIF,),
            help="Record the preliminary assessment of the {noun}, then attach the adjudication pack "
                 "and the draft successful/unsuccessful letters.",
            comment_label="Preliminary assessment",
            comment_required=True,
            comment_field="assessment_notes",
            attachment_category=Attachment.Category.ADJUDICATION_PACK,
            attachment_label="Adjudication pack and draft letters",
            attachment_required=True,
        ),
        Transition(
            name="criteria_met",
            label="{Noun} meets criteria",
            sources=(S.IN_ADJUDICATION,),
            target=S.AWAITING_SIGNATURE,
            roles=(SUBCOMMITTEE,),
            outcome=O.APPROVED,
            style="success",
            comment_label="Sub-committee resolution",
            comment_field="committee_resolution",
        ),
        Transition(
            name="criteria_not_met",
            label="{Noun} does not meet criteria",
            sources=(S.IN_ADJUDICATION,),
            target=S.AWAITING_SIGNATURE,
            roles=(SUBCOMMITTEE,),
            outcome=O.REJECTED,
            style="danger",
            comment_label="Reasons the {noun} does not meet the criteria",
            comment_required=True,
            comment_field="committee_resolution",
        ),
        Transition(
            name="sign_letter",
            label="Sign outcome letter",
            sources=(S.AWAITING_SIGNATURE,),
            target=S.LETTER_SIGNED,
            roles=(CHAIRPERSON,),
            help="Upload the signed outcome letter for the {noun}.",
            attachment_category=Attachment.Category.SIGNED_LETTER,
            attachment_label="Signed letter",
            attachment_required=True,
        ),
        Transition(
            name="notify_applicant",
            label="Notify applicant of outcome",
            sources=(S.LETTER_SIGNED,),
            target=S.APPLICANT_NOTIFIED,
            roles=(NSIF,),
            help="Emails the applicant the outcome of the {noun}; the signed letter becomes visible to them.",
            comment_label="Message to applicant (optional)",
        ),
        Transition(
            name="file_and_close",
            label="Scan & file documentation, update register",
            sources=(S.APPLICANT_NOTIFIED,),
            target=S.CLOSED,
            roles=(NSIF,),
            help="Attach scanned documentation and record the filing reference. "
                 "This closes the {noun} in the register.",
            attachment_category=Attachment.Category.SCANNED_FILE,
            attachment_label="Scanned documentation (optional)",
            asks_file_reference=True,
            register_note=True,
        ),
    ]
}


def _applies(t, req):
    return req.form_type in t.form_types and req.status in t.sources


def available_transitions(req, user):
    return [t for t in TRANSITIONS.values() if _applies(t, req) and has_role(user, *t.roles_for(req))]


def pending_transitions(req):
    """Transitions that are next for this request, regardless of user (for 'waiting on')."""
    return [t for t in TRANSITIONS.values() if _applies(t, req)]


class TransitionError(Exception):
    pass


def log(req, action, label, from_status, user, comment=""):
    return WorkflowEvent.objects.create(
        request=req, action=action, label=label, from_status=from_status,
        to_status=req.status, actor=user, comment=comment,
    )


@transaction.atomic
def submit(req, user):
    if req.status not in (S.DRAFT, S.RETURNED):
        raise TransitionError(f"Only drafts or {req.noun}s referred back can be submitted.")
    if not req.declaration_accepted:
        raise TransitionError("The declaration must be accepted before submitting.")
    resubmission = req.status == S.RETURNED
    from_status = req.status
    req.assign_reference_number()
    req.status = S.SUBMITTED
    req.outcome = ""
    if not resubmission:
        req.submitted_at = timezone.now()
    req.save()
    if resubmission:
        log(req, "resubmit", "Resubmitted with amendments", from_status, user)
        transaction.on_commit(lambda: notifications.resubmitted(req))
    else:
        log(req, "submit", f"{req.Noun} submitted (Form {req.form_type})", from_status, user)
        transaction.on_commit(lambda: notifications.submitted(req))
    return req


@transaction.atomic
def perform(req, name, user, comment="", files=(), file_reference=""):
    t = TRANSITIONS.get(name)
    req = CaptureRequest.objects.select_for_update().get(pk=req.pk)
    if t is None or not _applies(t, req):
        raise TransitionError("This action is not available at the current stage.")
    if not has_role(user, *t.roles_for(req)):
        raise TransitionError("You do not have the role required for this action.")
    if t.comment_required and not comment.strip():
        raise TransitionError(f"{t.comment_label_for(req)} is required.")
    if t.attachment_required and not files:
        raise TransitionError(f"{t.attachment_label_for(req)} is required.")

    label = t.label_for(req)
    from_status = req.status
    for f in files:
        Attachment.objects.create(
            request=req, category=t.attachment_category or Attachment.Category.OTHER,
            file=f, uploaded_by=user, stage=from_status,
        )
    if t.comment_field and comment:
        setattr(req, t.comment_field, comment)
    if t.outcome:
        req.outcome = t.outcome
    if t.name == "refer_back":
        req.returned_from = from_status
        req.outcome = ""
        req.declaration_accepted = False  # applicant must re-confirm on resubmission
    if t.name == "file_and_close":
        req.file_reference = file_reference
        req.closed_at = timezone.now()
    req.status = t.target
    req.save()

    log(req, t.name, label, from_status, user, comment)
    if t.register_note:
        log(req, "register", "Spatial Data Capture Project Register updated", req.status, user)

    transaction.on_commit(lambda: notifications.transitioned(req, t, comment))
    return req
