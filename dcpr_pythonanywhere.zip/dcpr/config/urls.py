from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import include, path

from dcpr import views as dcpr_views

admin.site.site_header = "DCPR Administration"
admin.site.site_title = "DCPR admin"

urlpatterns = [
    path("admin/", admin.site.urls),
    path("accounts/login/", auth_views.LoginView.as_view(), name="login"),
    path("accounts/logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("accounts/signup/", dcpr_views.signup, name="signup"),
    path("accounts/", include("django.contrib.auth.urls")),
    path("", include("dcpr.urls")),
]
