# Deploying DCPR on PythonAnywhere (free account)

These steps take about 20 minutes. Replace `YOURUSERNAME` with your PythonAnywhere username throughout.
Your site will be at `https://YOURUSERNAME.pythonanywhere.com`.

Checked with the free plan as of October 2026: 512 MB disk, 1 web app, HTTPS included. DCPR needs about
175 MB: roughly 140 MB of Python packages, a 26 MB database with all boundaries loaded, and 5 MB of code.

---

## 1. Create the account

1. Sign up at <https://www.pythonanywhere.com> with the **Beginner (free)** plan.
2. Confirm your email address.

## 2. Upload the code

1. Open the **Files** tab and upload `dcpr.zip` into `/home/YOURUSERNAME/`.
2. Open **Consoles → Bash** and run:

```bash
cd ~
unzip -q dcpr.zip          # creates ~/dcpr (contains manage.py)
rm dcpr.zip
```

*(With Git instead: `git clone <your-repo-url> ~/dcpr`.)*

## 3. Create a virtualenv and install packages

Still in the Bash console:

```bash
mkvirtualenv --python=/usr/bin/python3.13 dcpr-venv     # use the version the Web tab offers, e.g. python3.12
pip install --no-cache-dir -r ~/dcpr/requirements.txt
```

* Use the newest Python 3.1x that the **Web** tab offers. Django 6 needs Python 3.12 or later.
  On 3.10 or 3.11, pip installs Django 5.2 LTS automatically, and DCPR supports both.
* `--no-cache-dir` saves disk space.
* Next time you open a console, run `workon dcpr-venv` to activate the virtualenv.

## 4. Configure secrets (`.env`)

### What this step does

DCPR reads its private settings from a small text file called **`.env`**. These are the secret key, your web
address and whether debug mode is on. Keeping them in this file means you never edit the code, and the
secrets never end up in the zip or in Git.

### Where the file goes

After step 2 your project folder looks like this. `.env` goes **next to `manage.py`**, in the top `dcpr`
folder:

```
/home/YOURUSERNAME/dcpr/          ← project folder (from dcpr.zip)
├── manage.py
├── .env                          ← you create this in this step
├── config/                       ← Django settings (config/settings.py reads .env)
├── dcpr/                         ← the DCPR app itself (models, views, workflow, maps)
├── deploy/
│   ├── env.example               ← template for .env
│   ├── pythonanywhere_wsgi.py
│   └── update.sh
├── static/  templates/  requirements.txt
```

The folder name appears twice on purpose. The outer `dcpr/` is the project; the inner `dcpr/` is the app.
The settings live in `config/settings.py`, not `dcpr/settings.py`.

### Option A: create it with one command (recommended)

In the Bash console, with the virtualenv active (`workon dcpr-venv`), copy and paste these four lines
**unchanged**:

```bash
cd ~/dcpr
PA_USER=$(whoami)
SECRET=$(python -c "import secrets; print(secrets.token_urlsafe(50))")
sed -e "s/YOURUSERNAME/$PA_USER/g" -e "s|^DJANGO_SECRET_KEY=.*|DJANGO_SECRET_KEY=$SECRET|" deploy/env.example > .env
```

On PythonAnywhere's **EU** system (`eu.pythonanywhere.com`), replace `.pythonanywhere.com` with
`.eu.pythonanywhere.com` in `.env` afterwards.

This copies the template and fills in two things:

* your PythonAnywhere username, which `whoami` returns, in the web address lines;
* a newly generated random secret key.

### Option B: create it by hand

1. In the Bash console, run `cp ~/dcpr/deploy/env.example ~/dcpr/.env`.
2. Open the **Files** tab and go to `/home/YOURUSERNAME/dcpr/`. Files starting with a dot can be hidden; type
   `.env` into the path box if you don't see it. Click it to open the editor.
3. Generate a key in the console with `python -c "import secrets; print(secrets.token_urlsafe(50))"`, and paste
   it after `DJANGO_SECRET_KEY=`.
4. Replace every `YOURUSERNAME` with your username, then click **Save**.

### What the finished file looks like

Here it is for a user called `nsifdemo`. Your key will be different.

```
DJANGO_DEBUG=0
DJANGO_SECRET_KEY=Qm3v...a-long-random-string...7_Q
DJANGO_ALLOWED_HOSTS=nsifdemo.pythonanywhere.com
DJANGO_CSRF_TRUSTED_ORIGINS=https://nsifdemo.pythonanywhere.com
SITE_URL=https://nsifdemo.pythonanywhere.com
EMAIL_HOST=
...
```

| Line | Meaning |
|---|---|
| `DJANGO_DEBUG=0` | Production mode: no error details shown to visitors, and HTTPS enforced. Keep it `0`. |
| `DJANGO_SECRET_KEY` | Random value Django uses to sign logins and forms. Keep it private. |
| `DJANGO_ALLOWED_HOSTS` | The only web address DCPR will answer to. Domain only, no `https://`. |
| `DJANGO_CSRF_TRUSTED_ORIGINS` | The same address **with** `https://`, so forms can be submitted. |
| `SITE_URL` | Used to build links in emails. |
| `EMAIL_...` | Optional. Leave empty for now (see step 9). |

### Check it worked

```bash
cd ~/dcpr
python manage.py shell -c "from django.conf import settings; print(settings.DEBUG, settings.ALLOWED_HOSTS, settings.SITE_URL)"
```

You should see `False`, then your own address twice, like this:

```
False ['nsifdemo.pythonanywhere.com'] https://nsifdemo.pythonanywhere.com
```

If you see `ImproperlyConfigured: Set DJANGO_SECRET_KEY`, the file is missing, is in the wrong folder, or still
says `change-me`. Repeat Option A.

> Treat `.env` like a password. Don't share it, email it, or put it in Git (it's already in `.gitignore`).
> If it leaks, generate a new key with Option A and reload the web app. Everyone will have to sign in again.

## 5. Create the database and the admin user

```bash
cd ~/dcpr
python manage.py migrate                 # ~15 s: creates tables, roles and loads all SA boundaries
python manage.py createsuperuser         # your administrator login
python manage.py collectstatic --noinput
python manage.py check --deploy          # two HSTS warnings are expected on *.pythonanywhere.com
```

> Don't run `seed_demo` on a public site: it creates accounts with a known password.
> Create real staff users in the admin instead (step 8).

## 6. Create the web app

1. Open the **Web** tab and click **Add a new web app**.
2. Click **Next** to accept the free domain `YOURUSERNAME.pythonanywhere.com`.
3. Choose **Manual configuration**, not "Django". Pick the **same Python version** as the virtualenv.
4. On the web app page, fill in these sections:

| Section | Setting | Value |
|---|---|---|
| Code | Source code | `/home/YOURUSERNAME/dcpr` |
| Code | Working directory | `/home/YOURUSERNAME/dcpr` |
| Virtualenv | Path | `dcpr-venv` (it expands to `/home/YOURUSERNAME/.virtualenvs/dcpr-venv`) |
| Static files *(optional, faster)* | URL `/static/` | Directory `/home/YOURUSERNAME/dcpr/staticfiles` |
| Security | Force HTTPS | **Enabled** |

DCPR serves its own CSS, JavaScript and logos through **WhiteNoise**, so the site keeps its styling even
without the `/static/` mapping. The mapping just lets PythonAnywhere serve those files slightly faster.

**Do not add a static mapping for `/media/`.** Uploaded documents must only be served through DCPR's
permission-checked download page.

## 7. Point the WSGI file at DCPR

### What this step does

When someone opens your site, PythonAnywhere runs one small Python file, the **WSGI file**, to find and start
your Django app. It tells the server three things:

* where the DCPR code is (`/home/YOURUSERNAME/dcpr`);
* where the settings are (`config.settings`);
* how to start the app (`get_wsgi_application()`).

PythonAnywhere creates this file for you, filled with example code. You replace that code with DCPR's version.

> This is **not** `~/dcpr/config/wsgi.py` inside the project. Leave that one alone. The file PythonAnywhere
> uses lives in `/var/www/`.

### Find the file

1. Open the **Web** tab and click your web app (`YOURUSERNAME.pythonanywhere.com`).
2. Scroll to the **Code** section. You'll see a line like:

   **WSGI configuration file:** `/var/www/YOURUSERNAME_pythonanywhere_com_wsgi.py`

   On PythonAnywhere's EU system, the name contains `_eu_`, e.g. `/var/www/YOURUSERNAME_eu_pythonanywhere_com_wsgi.py`.

### Option A: fill it in with one command (recommended)

In the Bash console, paste these lines **unchanged**:

```bash
WSGI=$(ls /var/www/*_wsgi.py | head -1)
echo "Updating $WSGI"
sed "s/YOURUSERNAME/$(whoami)/" ~/dcpr/deploy/pythonanywhere_wsgi.py > "$WSGI"
grep -n "USERNAME =" "$WSGI"
```

This copies DCPR's WSGI file over the example and puts in your username. The last line should show
`USERNAME = "yourusername"`.

### Option B: edit it by hand

1. In the **Code** section, click the link to the WSGI configuration file. It opens in PythonAnywhere's editor.
2. Select everything (**Ctrl+A**) and delete it. All of the example code goes, including the commented-out
   Flask and "Hello World" sections.
3. Paste this, then change `YOURUSERNAME` on the `USERNAME` line to your own username, keeping the quotes:

```python
import os
import sys

USERNAME = "YOURUSERNAME"                      # <-- your PythonAnywhere username
PROJECT_DIR = f"/home/{USERNAME}/dcpr"           # folder that contains manage.py

if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
# Secrets and options are read from /home/<username>/dcpr/.env by config/settings.py.

from django.core.wsgi import get_wsgi_application  # noqa: E402

application = get_wsgi_application()
```

4. Click **Save** (top right of the editor).

What each part does:

| Line | Purpose |
|---|---|
| `USERNAME = "..."` | Your username, used to build the path to DCPR. |
| `PROJECT_DIR` | The folder that contains `manage.py`. Python must be able to import `config` and `dcpr` from here. |
| `sys.path.insert(...)` | Adds that folder to Python's search path. |
| `DJANGO_SETTINGS_MODULE` | Points Django at `config/settings.py`, which also loads your `.env`. |
| `application = ...` | The object PythonAnywhere calls for every web request. |

### Check it before reloading (optional but quick)

With the virtualenv active (`workon dcpr-venv`), run:

```bash
python -c "import runpy; runpy.run_path('$(ls /var/www/*_wsgi.py | head -1)'); print('WSGI OK')"
```

* **`WSGI OK`:** the file is correct.
* **`ModuleNotFoundError: No module named 'config'`:** the path is wrong. Check the username in `USERNAME`,
  and that `~/dcpr/manage.py` exists.
* **`No module named 'django'`:** run `workon dcpr-venv` first.
* **`Set DJANGO_SECRET_KEY`:** the `.env` file from step 4 is missing.

### Reload and open the site

1. Go back to the **Web** tab and click the green **Reload YOURUSERNAME.pythonanywhere.com** button.
2. Open `https://YOURUSERNAME.pythonanywhere.com`.

**Expected result:** the DCPR sign-in page, with the Land Reform & Rural Development logo on the left, the CSI
logo on the right and the brown navigation bar.

**If it doesn't load**, open the **Error log** link on the Web tab, in the **Log files** section, and read the
newest lines at the bottom:

| You see | Cause | Fix |
|---|---|---|
| "Something went wrong :-(" page | Python error while starting | Error log; usually one of the rows below |
| `No module named 'config'` | Wrong `USERNAME` or project path | Fix the `USERNAME` line, Save, Reload |
| `No module named 'django'` | Virtualenv not set on the Web tab | **Virtualenv** section: enter `dcpr-venv`, Reload |
| `ImproperlyConfigured: Set DJANGO_SECRET_KEY` | `.env` missing or still says `change-me` | Redo step 4, Reload |
| `400 Bad Request` | Address not in `DJANGO_ALLOWED_HOSTS` | Correct `.env` (on EU: `YOURUSERNAME.eu.pythonanywhere.com`), Reload |
| Page loads without colours or logos | WhiteNoise not installed, or static mapping wrong | `pip install -r ~/dcpr/requirements.txt`, `collectstatic`, Reload. If you set a `/static/` mapping, it must point to `/home/YOURUSERNAME/dcpr/staticfiles` |
| "Coming soon!" placeholder page | WSGI file not saved or app not reloaded | Save the file, then click Reload |

> Remember to **Reload** after every change to the WSGI file, `.env` or the code. Changes don't take effect
> until you do.

## 8. Set up users and roles

1. Sign in at `/admin/` with the superuser.
2. Go to **Users → Add** to create accounts for the NSIF officers, Sub-committee members and the Chairperson.
3. On each user, add them to the matching group:
   * **NSIF (Spatial Information and Support)**
   * **CSI Data Sub-committee**
   * **CSI Data Sub-committee Chairperson**
4. To use the admin (boundary uploads, user management), a user needs **Staff status** plus the relevant
   permissions.

Applicants register themselves at `/accounts/signup/`.

## 9. Email (optional)

Free accounts can only send through **Gmail SMTP**.

1. In the Google account you'll send from, turn on 2-step verification.
2. Create an **App password**.
3. Add these lines to `~/dcpr/.env`:

```
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_HOST_USER=your.account@gmail.com
EMAIL_HOST_PASSWORD=the-16-character-app-password
EMAIL_USE_TLS=1
DEFAULT_FROM_EMAIL=your.account@gmail.com
NSIF_NOTIFY_EMAILS=nsif.team@example.gov.za
```

4. **Reload** the web app.

Without these settings, each email that would have been sent appears in **Web tab → Server log** as
`EMAIL NOT SENT`.

## 10. Keep it running (free plan)

* **Renew every month.** The free web app stops after one month unless you extend it with the button on the
  **Web** tab. Put a monthly reminder in your calendar.
* **Back up regularly.** Download `~/dcpr/db.sqlite3` and the `~/dcpr/media/` folder from the **Files** tab.
  Those two hold all the data.
* **Watch the disk.** Check **Account → Disk usage**. Supporting documents count toward the 512 MB.
  Keep boundary uploads simplified (the default), and don't upload the 162 MB full-resolution ward file on a
  free account.
* **CPU allowance.** Consoles and scheduled tasks share 100 CPU-seconds a day. The website itself doesn't use
  them. Setup uses about 30.

## Updating to a new DCPR version

1. Upload the new `dcpr.zip` to `/home/YOURUSERNAME/`.
2. In a Bash console, run:

```bash
workon dcpr-venv
cd ~ && unzip -oq dcpr.zip && rm dcpr.zip     # overwrites code only; .env, db.sqlite3 and media/ are kept
bash ~/dcpr/deploy/update.sh                   # backs up the DB, migrates, collects static, reloads
```

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Something went wrong" page | Web tab → **Error log**, read the last traceback. |
| `ImproperlyConfigured: Set DJANGO_SECRET_KEY` | `.env` is missing or still has `change-me`. |
| `400 Bad Request` | `DJANGO_ALLOWED_HOSTS` in `.env` doesn't match your domain. |
| Page has no styling or logos | Run `pip install -r ~/dcpr/requirements.txt` (installs WhiteNoise), then `collectstatic`, then Reload. Test by opening `https://YOURUSERNAME.pythonanywhere.com/static/dcpr/style.css`: it should show CSS text. |
| `403 CSRF verification failed` on forms | Set `DJANGO_CSRF_TRUSTED_ORIGINS=https://YOURUSERNAME.pythonanywhere.com`. |
| Emails not arriving | Check the Server log. On free accounts only Gmail SMTP works, with an *app* password. |
| `database is locked` | It's rare with a pilot's traffic. For heavier use, move to a paid plan with MySQL/Postgres. |

## Before real (non-pilot) use

DCPR stores applicants' personal information (names, emails, phone numbers), which falls under POPIA.
PythonAnywhere hosts in the US or EU. For production, check with the department's IT team or SITA about
approved hosting.
