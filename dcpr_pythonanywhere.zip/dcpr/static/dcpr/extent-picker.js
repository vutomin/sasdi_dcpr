/*
 * DCPR geographic extent picker and display maps, built on DcprMap (dcpr-map.js).
 * Uses only DCPR's own boundary data – no basemap tiles or external libraries.
 *
 * Picker markup: any element with [data-extent-picker] containing
 *   [data-role=map]            map container
 *   [data-role=boundary-ids]   hidden input, comma-separated boundary ids
 *   [data-role=extent-geojson] hidden input, custom area as GeoJSON
 *   [data-role=extent-kind]    hidden input: polygon | bbox | upload
 * plus the search box, level switch, draw buttons, bbox inputs and upload input.
 *
 * Display maps: [data-extent-display] with a JSON script id in data-source (and optional data-area).
 */
(function () {
  "use strict";
  if (!window.DcprMap) return;

  var cfgEl = document.getElementById("dcpr-map-config");
  var CFG = cfgEl ? JSON.parse(cfgEl.textContent) : {};
  var API = CFG.api || {};
  var COLORS = ["#a05a0a", "#00602f", "#2f5aa8", "#b0306a", "#6b4fb0", "#c07d00", "#2b8a8a"];
  var WARD_MAX_DEG_PER_PX = 0.0012;   // wards are shown once ~1 px < 130 m
  var levelCache = {};

  function getJSON(url) {
    return fetch(url, { credentials: "same-origin", headers: { Accept: "application/json" } })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); });
  }
  function levelGeoJSON(level) {
    if (!levelCache[level]) levelCache[level] = getJSON(API.geojson + "?level=" + encodeURIComponent(level));
    return levelCache[level];
  }
  function fmt(n) { return Number(n).toFixed(4); }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function union(a, b) {
    if (!a) return b; if (!b) return a;
    return [Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[2], b[2]), Math.max(a[3], b[3])];
  }
  function tipFor(p) {
    return "<b>" + esc(p.name) + "</b>" + (p.path ? "<br><small>" + esc(p.path) + "</small>" : "");
  }

  // ------------------------------------------------------------------ picker
  function Picker(root) {
    var self = this;
    this.root = root;
    this.$ = function (sel) { return root.querySelector(sel); };
    this.ids = this.$('[data-role="boundary-ids"]');
    this.geojson = this.$('[data-role="extent-geojson"]');
    this.kind = this.$('[data-role="extent-kind"]');
    this.selected = {};      // id -> {props, recs, bounds}
    this.custom = [];        // [{geometry, recs, bounds}]
    this.level = "province";
    var wardTimer = null;
    this.map = new DcprMap(this.$('[data-role="map"]'), {
      attribution: CFG.attribution,
      onViewChange: function () {
        if (self.level !== "ward") return;
        clearTimeout(wardTimer);
        wardTimer = setTimeout(function () { self.loadWards(); }, 200);
      }
    });
    this.map.loadContext(API.geojson);
    this.initControls();
    this.restore();
    this.loadLevel(this.level);
  }

  Picker.prototype.status = function (msg) {
    var el = this.$('[data-role="status"]');
    if (el) el.textContent = msg || "";
  };

  Picker.prototype.levelOpts = function () {
    var self = this;
    return {
      className: "dmap-pick", labels: true, title: function (f) { return tipFor(f.properties); },
      onClick: function (f) { self.toggle(f.properties, f); }
    };
  };

  Picker.prototype.loadLevel = function (level) {
    var self = this;
    this.level = level;
    this.map.clearLayer("level");
    if (level === "ward") { this.loadWards(); return; }
    this.root.classList.add("ep-loading");
    levelGeoJSON(level).then(function (fc) {
      self.root.classList.remove("ep-loading");
      if (self.level !== level) return;
      self.map.setLayer("level", fc, self.levelOpts());
      self.status("");
    }).catch(function () {
      self.root.classList.remove("ep-loading");
      self.status("Could not load boundaries. Reload the page to try again.");
    });
  };

  // Wards: fetched for the visible area only, once zoomed in far enough.
  Picker.prototype.loadWards = function () {
    var self = this;
    if (this.level !== "ward") return;
    if (this.map.degreesPerPixel() > WARD_MAX_DEG_PER_PX) {
      this.map.clearLayer("level");
      this.status("Zoom in to a town or municipality to see and select wards.");
      return;
    }
    var bbox = this.map.getBounds().map(function (v) { return v.toFixed(4); }).join(",");
    if (bbox === this.wardBbox) return;
    this.wardBbox = bbox;
    this.root.classList.add("ep-loading");
    getJSON(API.geojson + "?level=ward&bbox=" + bbox).then(function (fc) {
      self.root.classList.remove("ep-loading");
      if (self.level !== "ward" || self.wardBbox !== bbox) return;
      self.map.setLayer("level", fc, self.levelOpts());
      self.status(fc.features.length ? "Click wards to add or remove them." : "No wards in this view.");
    }).catch(function () { self.root.classList.remove("ep-loading"); });
  };

  Picker.prototype.toggle = function (props, feature) {
    if (this.selected[props.id]) this.remove(props.id); else this.add(props, feature);
  };

  Picker.prototype.add = function (props, feature, quiet) {
    if (this.selected[props.id]) return;
    var recs = this.map.addToLayer("selected", feature, { className: "dmap-selected", interactive: false });
    this.selected[props.id] = { props: props, recs: recs, bounds: DcprMap.geomBounds(feature.geometry) };
    this.sync();
    if (!quiet) this.status(props.name + " added.");
  };

  Picker.prototype.addById = function (item) {
    var self = this;
    if (this.selected[item.id]) { this.map.fitBounds(this.selected[item.id].bounds); return; }
    getJSON(API.geojson + "?ids=" + item.id).then(function (fc) {
      if (!fc.features.length) return;
      var f = fc.features[0];
      self.add(f.properties, f);
      self.map.fitBounds(self.selected[item.id].bounds);
    });
  };

  Picker.prototype.remove = function (id) {
    var s = this.selected[id];
    if (!s) return;
    this.map.removeRecords("selected", s.recs);
    delete this.selected[id];
    this.sync();
    this.status(s.props.name + " removed.");
  };

  Picker.prototype.addCustom = function (geometry, kind) {
    var recs = this.map.addToLayer("custom", geometry, { className: "dmap-custom", interactive: false });
    this.custom.push({ geometry: geometry, recs: recs, bounds: DcprMap.geomBounds(geometry) });
    this.kind.value = kind;
    this.sync();
  };

  Picker.prototype.clearCustom = function () {
    this.map.clearLayer("custom");
    this.custom = [];
    this.sync();
  };

  Picker.prototype.allBounds = function () {
    var b = null, self = this;
    Object.keys(this.selected).forEach(function (id) { b = union(b, self.selected[id].bounds); });
    this.custom.forEach(function (c) { b = union(b, c.bounds); });
    return b;
  };

  Picker.prototype.sync = function () {
    var self = this, ids = Object.keys(this.selected);
    this.ids.value = ids.join(",");
    this.geojson.value = this.custom.length ? JSON.stringify({
      type: "FeatureCollection",
      features: this.custom.map(function (c) { return { type: "Feature", properties: {}, geometry: c.geometry }; })
    }) : "";
    if (!this.custom.length) this.kind.value = "";
    var list = this.$('[data-role="selected"]');
    list.innerHTML = "";
    ids.forEach(function (id) {
      var s = self.selected[id], p = s.props;
      var li = document.createElement("li");
      li.className = "ep-chip";
      li.innerHTML = "<span><b>" + esc(p.name) + "</b><small>" + esc(p.level_label) + (p.path ? " · " + esc(p.path) : "") + "</small></span>";
      var x = document.createElement("button");
      x.type = "button"; x.className = "ep-x"; x.setAttribute("aria-label", "Remove " + p.name); x.textContent = "×";
      x.addEventListener("click", function () { self.remove(id); });
      li.appendChild(x);
      li.querySelector("span").addEventListener("click", function () { self.map.fitBounds(s.bounds); });
      list.appendChild(li);
    });
    if (this.custom.length) {
      var li = document.createElement("li");
      li.className = "ep-chip ep-chip-custom";
      var label = { bbox: "Bounding box", upload: "Uploaded area", polygon: "Drawn area" }[this.kind.value] || "Custom area";
      li.innerHTML = "<span><b>" + label + "</b><small>" + this.custom.length + " shape(s)</small></span>";
      var x = document.createElement("button");
      x.type = "button"; x.className = "ep-x"; x.setAttribute("aria-label", "Remove custom area"); x.textContent = "×";
      x.addEventListener("click", function () { self.clearCustom(); });
      li.appendChild(x);
      list.appendChild(li);
    }
    var empty = this.$('[data-role="empty"]');
    if (empty) empty.hidden = !!(ids.length || this.custom.length);
    var b = this.allBounds(), bb = this.$('[data-role="bbox"]');
    if (bb) bb.textContent = b ? "Extent bounding box (W, S, E, N): " + b.map(fmt).join(", ") : "";
  };

  Picker.prototype.restore = function () {
    var self = this, ids = (this.ids.value || "").split(",").filter(Boolean), pending = [];
    if (ids.length) {
      pending.push(getJSON(API.geojson + "?ids=" + ids.join(",")).then(function (fc) {
        fc.features.forEach(function (f) { self.add(f.properties, f, true); });
      }));
    }
    if (this.geojson.value) {
      try {
        var gj = JSON.parse(this.geojson.value), kind = this.kind.value || "polygon";
        (gj.type === "FeatureCollection" ? gj.features : [gj]).forEach(function (f) {
          self.addCustom(f.geometry || f, kind);
        });
      } catch (e) { /* ignore an invalid draft value */ }
    }
    Promise.all(pending).then(function () {
      self.sync();
      var b = self.allBounds();
      if (b) self.map.fitBounds(b);
    });
  };

  Picker.prototype.initControls = function () {
    var self = this;
    this.root.querySelectorAll('[data-role="level"]').forEach(function (r) {
      r.addEventListener("change", function () { if (r.checked) self.loadLevel(r.value); });
    });
    // search
    var input = this.$('[data-role="search"]'), results = this.$('[data-role="results"]'), timer = null;
    function render(items) {
      results.innerHTML = "";
      items.forEach(function (it) {
        var li = document.createElement("li"), b = document.createElement("button");
        b.type = "button";
        b.innerHTML = "<b>" + esc(it.name) + "</b><small>" + esc(it.level_label) + (it.path ? " · " + esc(it.path) : "") + "</small>";
        b.addEventListener("click", function () { self.addById(it); results.innerHTML = ""; input.value = ""; });
        li.appendChild(b);
        results.appendChild(li);
      });
      if (!items.length && input.value.trim().length > 1) {
        results.innerHTML = '<li class="ep-none">No boundary matches “' + esc(input.value) + "”.</li>";
      }
    }
    if (input) {
      input.addEventListener("input", function () {
        clearTimeout(timer);
        var q = input.value.trim();
        if (q.length < 2) { results.innerHTML = ""; return; }
        timer = setTimeout(function () {
          getJSON(API.boundaries + "?q=" + encodeURIComponent(q)).then(function (d) { render(d.results); });
        }, 200);
      });
      input.addEventListener("keydown", function (e) {
        if (e.key === "Enter") {      // never submit the whole form from the search box
          e.preventDefault();
          var first = results.querySelector("button");
          if (first) first.click();
        }
      });
    }
    // drawing
    this.$('[data-role="draw-polygon"]').addEventListener("click", function () {
      self.status("Click on the map to add corners. Click the first point, double-click or press Enter to finish; Esc cancels.");
      self.map.drawPolygon(function (g) {
        if (g) { self.addCustom(g, "polygon"); self.status("Area added."); } else self.status("Drawing cancelled.");
      });
    });
    this.$('[data-role="draw-rectangle"]').addEventListener("click", function () {
      self.status("Click and drag on the map to draw a bounding box. Esc cancels.");
      self.map.drawRectangle(function (g) {
        if (g) { self.addCustom(g, "bbox"); self.status("Bounding box added."); } else self.status("Drawing cancelled.");
      });
    });
    this.$('[data-role="clear-custom"]').addEventListener("click", function () {
      self.clearCustom(); self.status("Custom area cleared.");
    });
    // typed bounding box
    this.$('[data-role="bbox-apply"]').addEventListener("click", function () {
      var v = ["w", "s", "e", "n"].map(function (k) { return parseFloat(self.$('[data-bbox="' + k + '"]').value); });
      var err = self.$('[data-role="bbox-error"]');
      if (v.some(isNaN)) { err.textContent = "Enter all four coordinates in decimal degrees."; return; }
      if (v[0] >= v[2] || v[1] >= v[3]) { err.textContent = "West must be less than East, and South less than North."; return; }
      if (v[0] < 10 || v[2] > 40 || v[1] < -50 || v[3] > -15) { err.textContent = "Those coordinates are outside South Africa (longitude 16–33, latitude −35 to −22)."; return; }
      err.textContent = "";
      self.addCustom(DcprMap.bboxPolygon(v[0], v[1], v[2], v[3]), "bbox");
      self.map.fitBounds(v);
      self.status("Bounding box added.");
    });
    // GeoJSON upload
    var up = this.$('[data-role="upload"]');
    up.addEventListener("change", function () {
      var f = up.files[0];
      if (!f) return;
      var reader = new FileReader();
      reader.onload = function () {
        try {
          var gj = JSON.parse(reader.result), added = 0;
          var feats = gj.type === "FeatureCollection" ? gj.features : [gj.type === "Feature" ? gj : { geometry: gj }];
          feats.forEach(function (ft) {
            var g = ft.geometry;
            if (g && /Polygon/.test(g.type)) { self.addCustom(g, "upload"); added++; }
          });
          if (!added) throw new Error("no polygons");
          self.map.fitBounds(self.allBounds());
          self.status(added + " area(s) loaded from " + f.name + ".");
        } catch (e) {
          self.status("That file is not GeoJSON with polygons in WGS84 longitude/latitude.");
        }
        up.value = "";
      };
      reader.readAsText(f);
    });
    var fit = this.$('[data-role="fit"]');
    if (fit) fit.addEventListener("click", function () {
      var b = self.allBounds();
      self.map.fitBounds(b || DcprMap.SA);
    });
    var whole = this.$('[data-role="whole-country"]');
    if (whole) whole.addEventListener("click", function () {
      getJSON(API.boundaries + "?level=country").then(function (d) { if (d.results.length) self.addById(d.results[0]); });
    });
  };

  // ----------------------------------------------------------- display maps
  function display(el) {
    var src = document.getElementById(el.getAttribute("data-source"));
    if (!src) return;
    var fc = JSON.parse(src.textContent);
    var map = new DcprMap(el, { attribution: CFG.attribution });
    map.loadContext(API.geojson);
    var areaSrc = el.getAttribute("data-area") && document.getElementById(el.getAttribute("data-area"));
    if (areaSrc && areaSrc.textContent.trim() !== "null") {
      map.addToLayer("custom", JSON.parse(areaSrc.textContent), { className: "dmap-search-area", interactive: false });
    }
    map.addToLayer("display", fc, {
      className: "dmap-extent",
      style: function (f) {
        var c = COLORS[(f.properties.index || 0) % COLORS.length];
        return { fill: c, stroke: c };
      },
      title: function (f) {
        var p = f.properties;
        return (p.ref ? esc(p.ref) + " · " : "") + "<b>" + esc(p.title) + "</b>";
      },
      onClick: function (f) {
        var p = f.properties, html = "";
        if (p.ref) html += '<a href="' + esc(p.url) + '">' + esc(p.ref) + "</a><div>" + esc(p.project) + "</div>";
        html += "<b>" + esc(p.title) + "</b>";
        if (p.status) html += "<div class=\"muted\">" + esc(p.status) + "</div>";
        if (p.boundaries && p.boundaries.length) html += "<div class=\"muted\">" + esc(p.boundaries.join(", ")) + "</div>";
        if (p.area_km2) html += "<div class=\"muted\">≈ " + Math.round(p.area_km2).toLocaleString() + " km²</div>";
        map.showInfo(html);
      }
    });
    var b = map.layerBounds(["display", "custom"]);
    if (b) map.fitBounds(b);
  }

  function init(scope) {
    (scope || document).querySelectorAll("[data-extent-picker]").forEach(function (el) {
      if (el.closest("template") || el._picker) return;
      el._picker = new Picker(el);
    });
    (scope || document).querySelectorAll("[data-extent-display]").forEach(function (el) {
      if (el._map) return;
      el._map = true;
      display(el);
    });
  }

  document.addEventListener("dcpr:block-added", function (e) { init(e.target); });
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", function () { init(); });
  else init();
})();
