/*
 * DcprMap – a small, dependency-free SVG map for DCPR.
 *
 * It draws only DCPR's own boundary data (country, provinces, districts, municipalities,
 * wards, dataset extents) so it works on closed networks: no tiles, no CDN, no external
 * requests. Coordinates are WGS84 lon/lat, shown in an equirectangular projection scaled
 * for South African latitudes.
 *
 *   var m = new DcprMap(el, {onViewChange: fn, status: fn});
 *   m.setLayer("level", featureCollection, {className, onClick, labels: true});
 *   m.fitBounds([w, s, e, n]);   m.getBounds();
 *   m.drawPolygon(cb);  m.drawRectangle(cb);   // cb(geojsonPolygon) or cb(null) if cancelled
 */
(function (global) {
  "use strict";

  var SVGNS = "http://www.w3.org/2000/svg";
  var K = Math.cos(29 * Math.PI / 180);          // x scale for SA's mid-latitude
  var SA = [16.3, -35.0, 33.0, -22.0];            // mainland view
  var LAYERS = ["context", "level", "display", "selected", "custom", "draft"];
  var ctxCache = null;

  function el(tag, attrs, parent) {
    var n = document.createElementNS(SVGNS, tag);
    for (var k in attrs) if (attrs[k] != null) n.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(n);
    return n;
  }
  function project(lon, lat) { return [lon * K, -lat]; }
  function unproject(x, y) { return [x / K, -y]; }

  function ringPath(ring) {
    var d = "";
    for (var i = 0; i < ring.length; i++) {
      var p = project(ring[i][0], ring[i][1]);
      d += (i ? "L" : "M") + p[0].toFixed(5) + " " + p[1].toFixed(5);
    }
    return d + "Z";
  }
  function geomPath(g) {
    if (!g) return "";
    if (g.type === "Polygon") return g.coordinates.map(ringPath).join("");
    if (g.type === "MultiPolygon") return g.coordinates.map(function (p) { return p.map(ringPath).join(""); }).join("");
    if (g.type === "GeometryCollection") return g.geometries.map(geomPath).join("");
    return "";
  }
  function geomBounds(g, b) {
    b = b || [Infinity, Infinity, -Infinity, -Infinity];
    function walk(c) {
      if (typeof c[0] === "number") {
        if (c[0] < b[0]) b[0] = c[0]; if (c[1] < b[1]) b[1] = c[1];
        if (c[0] > b[2]) b[2] = c[0]; if (c[1] > b[3]) b[3] = c[1];
      } else c.forEach(walk);
    }
    if (g && g.type === "GeometryCollection") g.geometries.forEach(function (x) { geomBounds(x, b); });
    else if (g && g.coordinates) walk(g.coordinates);
    return b;
  }
  function features(fc) {
    if (!fc) return [];
    if (fc.type === "FeatureCollection") return fc.features || [];
    if (fc.type === "Feature") return [fc];
    return [{ type: "Feature", properties: {}, geometry: fc }];
  }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function DcprMap(container, opts) {
    var self = this;
    this.opts = opts || {};
    this.container = container;
    container.classList.add("dmap");
    container.innerHTML = "";
    this.svg = el("svg", { class: "dmap-svg", role: "img" }, container);
    this.g = {};
    LAYERS.forEach(function (n) { self.g[n] = el("g", { class: "dmap-layer dmap-" + n }, self.svg); });
    this.labels = document.createElement("div"); this.labels.className = "dmap-labels"; container.appendChild(this.labels);
    this.tip = document.createElement("div"); this.tip.className = "dmap-tip"; this.tip.hidden = true; container.appendChild(this.tip);
    this.info = document.createElement("div"); this.info.className = "dmap-info"; this.info.hidden = true; container.appendChild(this.info);
    this.layerData = {};
    this.mode = null;
    this.cx = 0; this.cy = 0; this.s = 0.02;
    this.buildControls();
    this.bindEvents();
    this.resizeObs = new ResizeObserver(function () { self.render(); });
    this.resizeObs.observe(container);
    this.fitBounds(this.opts.bounds || SA, 0);
  }

  // ------------------------------------------------------------------ view
  DcprMap.prototype.size = function () {
    return [this.container.clientWidth || 600, this.container.clientHeight || 400];
  };
  DcprMap.prototype.render = function () {
    var sz = this.size(), w = sz[0] * this.s, h = sz[1] * this.s;
    this.vb = [this.cx - w / 2, this.cy - h / 2, w, h];
    this.svg.setAttribute("viewBox", this.vb.join(" "));
    this.svg.style.setProperty("--px", this.s);   // world units per pixel (for dash arrays)
    this.renderLabels();
    this.renderScale();
    if (this.opts.onViewChange) this.opts.onViewChange(this);
  };
  DcprMap.prototype.fitBounds = function (b, padPx) {
    if (!b || !isFinite(b[0])) return;
    var sz = this.size(), pad = padPx == null ? 24 : padPx;
    var p1 = project(b[0], b[3]), p2 = project(b[2], b[1]);
    var w = Math.max(p2[0] - p1[0], 0.002), h = Math.max(p2[1] - p1[1], 0.002);
    this.cx = (p1[0] + p2[0]) / 2; this.cy = (p1[1] + p2[1]) / 2;
    this.s = Math.max(w / Math.max(sz[0] - 2 * pad, 50), h / Math.max(sz[1] - 2 * pad, 50));
    this.clampScale();
    this.render();
  };
  DcprMap.prototype.clampScale = function () { this.s = Math.min(Math.max(this.s, 0.00001), 0.08); };
  DcprMap.prototype.getBounds = function () {
    var a = unproject(this.vb[0], this.vb[1]), b = unproject(this.vb[0] + this.vb[2], this.vb[1] + this.vb[3]);
    return [a[0], b[1], b[0], a[1]];
  };
  DcprMap.prototype.degreesPerPixel = function () { return this.s / K; };
  DcprMap.prototype.zoomBy = function (f, sx, sy) {
    var sz = this.size();
    if (sx == null) { sx = sz[0] / 2; sy = sz[1] / 2; }
    var wx = this.vb[0] + sx * this.s, wy = this.vb[1] + sy * this.s;
    var ns = this.s / f; var old = this.s; this.s = ns; this.clampScale(); ns = this.s;
    this.cx = wx + (this.cx - wx) * (ns / old);
    this.cy = wy + (this.cy - wy) * (ns / old);
    this.render();
  };
  DcprMap.prototype.screenToLonLat = function (sx, sy) {
    return unproject(this.vb[0] + sx * this.s, this.vb[1] + sy * this.s);
  };
  DcprMap.prototype.lonLatToScreen = function (lon, lat) {
    var p = project(lon, lat);
    return [(p[0] - this.vb[0]) / this.s, (p[1] - this.vb[1]) / this.s];
  };
  DcprMap.prototype.localXY = function (ev) {
    var r = this.container.getBoundingClientRect();
    return [ev.clientX - r.left, ev.clientY - r.top];
  };

  // ---------------------------------------------------------------- layers
  /* opts: className, style(feature, i) -> {fill, stroke}, onClick(feature, path), title(feature),
           labels (bool), interactive (bool) */
  DcprMap.prototype.setLayer = function (name, fc, o) {
    this.clearLayer(name);
    return this.addToLayer(name, fc, o);
  };
  DcprMap.prototype.addToLayer = function (name, fc, o) {
    o = o || {};
    var self = this, g = this.g[name], out = [];
    var store = this.layerData[name] = this.layerData[name] || [];
    features(fc).forEach(function (f, i) {
      var d = geomPath(f.geometry);
      if (!d) return;
      var p = el("path", { d: d, class: "dmap-feature " + (o.className || ""), "fill-rule": "evenodd" }, g);
      if (o.style) {
        var st = o.style(f, i);
        if (st.fill) p.style.fill = st.fill;
        if (st.stroke) p.style.stroke = st.stroke;
      }
      var title = o.title ? o.title(f) : (f.properties && f.properties.name);
      if (o.interactive !== false && (o.onClick || title)) {
        p.classList.add("dmap-hit");
        if (title) {
          p.addEventListener("pointerenter", function (ev) { self.showTip(title, ev); });
          p.addEventListener("pointermove", function (ev) { self.showTip(title, ev); });
          p.addEventListener("pointerleave", function () { self.tip.hidden = true; });
        }
        if (o.onClick) p.addEventListener("click", function (ev) {
          if (self.mode || self.suppressClick) return;
          ev.stopPropagation();
          o.onClick(f, p, ev);
        });
      }
      var rec = { feature: f, path: p, bounds: geomBounds(f.geometry), labels: !!o.labels };
      store.push(rec); out.push(rec);
    });
    this.renderLabels();
    return out;
  };
  DcprMap.prototype.clearLayer = function (name) {
    var g = this.g[name];
    while (g.firstChild) g.removeChild(g.firstChild);
    this.layerData[name] = [];
    this.renderLabels();
  };
  DcprMap.prototype.removeRecords = function (name, recs) {
    var store = this.layerData[name] || [];
    recs.forEach(function (r) { if (r.path.parentNode) r.path.parentNode.removeChild(r.path); });
    this.layerData[name] = store.filter(function (r) { return recs.indexOf(r) < 0; });
    this.renderLabels();
  };
  DcprMap.prototype.layerBounds = function (names) {
    var b = [Infinity, Infinity, -Infinity, -Infinity], self = this;
    names.forEach(function (n) {
      (self.layerData[n] || []).forEach(function (r) {
        b = [Math.min(b[0], r.bounds[0]), Math.min(b[1], r.bounds[1]), Math.max(b[2], r.bounds[2]), Math.max(b[3], r.bounds[3])];
      });
    });
    return isFinite(b[0]) ? b : null;
  };

  DcprMap.prototype.renderLabels = function () {
    if (!this.vb) return;
    var self = this, html = "", sz = this.size(), placed = [];
    ["level", "context"].forEach(function (name) {
      (self.layerData[name] || []).forEach(function (r) {
        if (!r.labels) return;
        var p = r.feature.properties || {};
        var b = r.bounds;
        var a = self.lonLatToScreen(b[0], b[3]), c = self.lonLatToScreen(b[2], b[1]);
        var wpx = c[0] - a[0], hpx = c[1] - a[1];
        if (wpx < 70 || hpx < 26 || c[0] < 0 || a[0] > sz[0] || c[1] < 0 || a[1] > sz[1]) return;
        var lp = p.label || [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2];
        var s = self.lonLatToScreen(lp[0], lp[1]);
        if (s[0] < 0 || s[1] < 0 || s[0] > sz[0] || s[1] > sz[1]) return;
        for (var i = 0; i < placed.length; i++) {           // avoid overlaps
          if (Math.abs(placed[i][0] - s[0]) < 80 && Math.abs(placed[i][1] - s[1]) < 16) return;
        }
        placed.push(s);
        html += '<span class="dmap-label dmap-label-' + name + '" style="left:' + s[0].toFixed(0) + "px;top:" + s[1].toFixed(0) + 'px">' + esc(p.name) + "</span>";
      });
    });
    this.labels.innerHTML = html;
  };

  DcprMap.prototype.renderScale = function () {
    if (!this.scaleEl) return;
    var kmPerPx = this.s * 111.32;              // y units are degrees of latitude
    var target = kmPerPx * 100, steps = [0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100, 200, 500, 1000];
    var km = steps[0];
    for (var i = 0; i < steps.length; i++) if (steps[i] <= target) km = steps[i];
    this.scaleBar.style.width = (km / kmPerPx).toFixed(0) + "px";
    this.scaleText.textContent = km < 1 ? (km * 1000) + " m" : km + " km";
  };

  DcprMap.prototype.showTip = function (text, ev) {
    if (this.mode) return;
    var xy = this.localXY(ev);
    this.tip.innerHTML = text;
    this.tip.hidden = false;
    this.tip.style.left = Math.min(xy[0] + 12, this.size()[0] - 180) + "px";
    this.tip.style.top = (xy[1] + 14) + "px";
  };
  DcprMap.prototype.showInfo = function (html) {
    var self = this;
    this.info.innerHTML = '<button type="button" class="dmap-info-x" aria-label="Close">×</button>' + html;
    this.info.hidden = false;
    this.info.querySelector(".dmap-info-x").onclick = function () { self.info.hidden = true; };
  };

  // -------------------------------------------------------------- controls
  DcprMap.prototype.buildControls = function () {
    var self = this;
    var box = document.createElement("div"); box.className = "dmap-controls";
    [["+", "Zoom in", function () { self.zoomBy(1.6); }],
     ["−", "Zoom out", function () { self.zoomBy(1 / 1.6); }],
     ["⤢", "Show all of South Africa", function () { self.fitBounds(SA); }]].forEach(function (c) {
      var b = document.createElement("button");
      b.type = "button"; b.textContent = c[0]; b.title = c[1]; b.setAttribute("aria-label", c[1]);
      b.addEventListener("click", c[2]);
      box.appendChild(b);
    });
    this.container.appendChild(box);
    var sc = document.createElement("div"); sc.className = "dmap-scale";
    this.scaleBar = document.createElement("span"); this.scaleText = document.createElement("small");
    sc.appendChild(this.scaleBar); sc.appendChild(this.scaleText);
    this.scaleEl = sc;
    this.container.appendChild(sc);
    var at = document.createElement("div"); at.className = "dmap-attrib";
    at.textContent = this.opts.attribution || "Boundaries: MDB 2018 · OCHA COD-AB 2020";
    this.container.appendChild(at);
  };

  // ---------------------------------------------------------------- events
  DcprMap.prototype.bindEvents = function () {
    var self = this, c = this.container, drag = null, pinch = null, pointers = {};
    c.tabIndex = 0;
    c.addEventListener("wheel", function (ev) {
      ev.preventDefault();
      var xy = self.localXY(ev);
      self.zoomBy(Math.exp(-ev.deltaY * (ev.deltaMode ? 0.05 : 0.0015)), xy[0], xy[1]);
    }, { passive: false });
    c.addEventListener("dblclick", function (ev) {
      if (self.mode === "polygon") {          // the two clicks added the same vertex twice
        if (self.poly.length > 3) self.poly.pop();
        self.polyFinish();
        return;
      }
      if (self.mode) return;
      var xy = self.localXY(ev);
      self.zoomBy(ev.shiftKey ? 1 / 2 : 2, xy[0], xy[1]);
    });
    c.addEventListener("pointerdown", function (ev) {
      if (ev.target.closest(".dmap-controls, .dmap-info")) return;
      pointers[ev.pointerId] = self.localXY(ev);
      var ids = Object.keys(pointers);
      if (ids.length === 2) {
        var a = pointers[ids[0]], b = pointers[ids[1]];
        pinch = { d: Math.hypot(a[0] - b[0], a[1] - b[1]), s: self.s };
        drag = null; return;
      }
      if (self.mode === "rectangle") { self.rectStart(ev); return; }
      if (ev.button !== 0) return;
      drag = { x: ev.clientX, y: ev.clientY, cx: self.cx, cy: self.cy, moved: false, id: ev.pointerId };
    });
    c.addEventListener("pointermove", function (ev) {
      if (pointers[ev.pointerId]) pointers[ev.pointerId] = self.localXY(ev);
      if (pinch) {
        var ids = Object.keys(pointers);
        if (ids.length === 2) {
          var a = pointers[ids[0]], b = pointers[ids[1]];
          var d = Math.hypot(a[0] - b[0], a[1] - b[1]);
          var f = d / pinch.d, target = pinch.s / f;
          self.zoomBy(self.s / target, (a[0] + b[0]) / 2, (a[1] + b[1]) / 2);
        }
        return;
      }
      if (self.mode === "rectangle" && self.rect) { self.rectMove(ev); return; }
      if (self.mode === "polygon") { self.polyMove(ev); }
      if (!drag) return;
      var dx = ev.clientX - drag.x, dy = ev.clientY - drag.y;
      if (!drag.moved && Math.hypot(dx, dy) < 4) return;
      if (!drag.moved) { drag.moved = true; c.setPointerCapture(drag.id); c.classList.add("dmap-dragging"); self.tip.hidden = true; }
      self.cx = drag.cx - dx * self.s; self.cy = drag.cy - dy * self.s;
      self.render();
    });
    function end(ev) {
      delete pointers[ev.pointerId];
      if (Object.keys(pointers).length < 2) pinch = null;
      if (self.mode === "rectangle" && self.rect) { self.rectEnd(ev); return; }
      if (drag && drag.moved) {
        self.suppressClick = true;
        setTimeout(function () { self.suppressClick = false; }, 0);
      }
      c.classList.remove("dmap-dragging");
      drag = null;
    }
    c.addEventListener("pointerup", end);
    c.addEventListener("pointercancel", end);
    c.addEventListener("click", function (ev) {
      if (self.mode === "polygon" && !self.suppressClick) { self.polyClick(ev); }
    });
    c.addEventListener("keydown", function (ev) {
      if (ev.key === "Escape" && self.mode) { self.finishDraw(null); }
      else if (ev.key === "Enter" && self.mode === "polygon") { ev.preventDefault(); self.polyFinish(); }
      else if (ev.key === "Backspace" && self.mode === "polygon" && self.poly.length) { ev.preventDefault(); self.poly.pop(); self.polyDraw(); }
      else if (ev.key === "+" || ev.key === "=") self.zoomBy(1.6);
      else if (ev.key === "-") self.zoomBy(1 / 1.6);
      else if (/^Arrow/.test(ev.key)) {
        ev.preventDefault();
        var step = 60 * self.s;
        if (ev.key === "ArrowLeft") self.cx -= step; if (ev.key === "ArrowRight") self.cx += step;
        if (ev.key === "ArrowUp") self.cy -= step; if (ev.key === "ArrowDown") self.cy += step;
        self.render();
      }
    });
  };

  // ---------------------------------------------------------------- drawing
  DcprMap.prototype.drawPolygon = function (cb) {
    this.finishDraw(null);
    this.mode = "polygon"; this.poly = []; this.drawCb = cb;
    this.container.classList.add("dmap-drawing");
    this.container.focus({ preventScroll: true });
  };
  DcprMap.prototype.drawRectangle = function (cb) {
    this.finishDraw(null);
    this.mode = "rectangle"; this.rect = null; this.drawCb = cb;
    this.container.classList.add("dmap-drawing");
    this.container.focus({ preventScroll: true });
  };
  DcprMap.prototype.finishDraw = function (geom) {
    var cb = this.drawCb;
    this.mode = null; this.poly = []; this.rect = null; this.drawCb = null;
    this.clearLayer("draft");
    this.container.classList.remove("dmap-drawing");
    if (cb) cb(geom);
  };
  DcprMap.prototype.polyClick = function (ev) {
    ev.stopPropagation();
    var xy = this.localXY(ev);
    if (this.poly.length >= 3) {
      var f = this.lonLatToScreen(this.poly[0][0], this.poly[0][1]);
      if (Math.hypot(f[0] - xy[0], f[1] - xy[1]) < 10) { this.polyFinish(); return; }
    }
    this.poly.push(this.screenToLonLat(xy[0], xy[1]));
    this.polyDraw();
  };
  DcprMap.prototype.polyMove = function (ev) { this.hover = this.screenToLonLat.apply(this, this.localXY(ev)); this.polyDraw(); };
  DcprMap.prototype.polyDraw = function () {
    var g = this.g.draft;
    while (g.firstChild) g.removeChild(g.firstChild);
    var pts = this.poly.slice();
    if (this.hover && pts.length) pts.push(this.hover);
    if (pts.length > 1) {
      var d = pts.map(function (p, i) { var q = project(p[0], p[1]); return (i ? "L" : "M") + q[0] + " " + q[1]; }).join("");
      el("path", { d: d, class: "dmap-draft-line" }, g);
    }
    var self = this;
    this.poly.forEach(function (p, i) {
      var q = project(p[0], p[1]);
      el("circle", { cx: q[0], cy: q[1], r: (i === 0 ? 6 : 4) * self.s, class: "dmap-vertex" + (i === 0 ? " first" : "") }, g);
    });
  };
  DcprMap.prototype.polyFinish = function () {
    if (this.poly.length < 3) return;
    var ring = this.poly.concat([this.poly[0]]).map(function (p) { return [+p[0].toFixed(6), +p[1].toFixed(6)]; });
    this.finishDraw({ type: "Polygon", coordinates: [ring] });
  };
  DcprMap.prototype.rectStart = function (ev) {
    ev.preventDefault();
    this.container.setPointerCapture(ev.pointerId);
    this.rect = { a: this.screenToLonLat.apply(this, this.localXY(ev)) };
  };
  DcprMap.prototype.rectMove = function (ev) {
    this.rect.b = this.screenToLonLat.apply(this, this.localXY(ev));
    var a = this.rect.a, b = this.rect.b;
    this.clearLayer("draft");
    this.addToLayer("draft", bboxPolygon(Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[0], b[0]), Math.max(a[1], b[1])),
                    { className: "dmap-draft-rect", interactive: false });
  };
  DcprMap.prototype.rectEnd = function () {
    var a = this.rect.a, b = this.rect.b;
    if (!b || Math.abs(a[0] - b[0]) < this.s || Math.abs(a[1] - b[1]) < this.s) { this.rect = null; return; }
    this.finishDraw(bboxPolygon(Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[0], b[0]), Math.max(a[1], b[1])));
  };

  function bboxPolygon(w, s, e, n) {
    var r = function (v) { return +v.toFixed(6); };
    return { type: "Polygon", coordinates: [[[r(w), r(s)], [r(e), r(s)], [r(e), r(n)], [r(w), r(n)], [r(w), r(s)]]] };
  }

  // ------------------------------------------------- shared context layer
  /* Country and provinces, drawn under everything for orientation (loaded once per page). */
  DcprMap.prototype.loadContext = function (geojsonUrl) {
    var self = this;
    if (!ctxCache) {
      var get = function (lvl) {
        return fetch(geojsonUrl + "?level=" + lvl, { credentials: "same-origin" }).then(function (r) { return r.json(); });
      };
      ctxCache = Promise.all([get("country"), get("province")]);
    }
    return ctxCache.then(function (res) {
      self.setLayer("context", res[0], { className: "dmap-country", interactive: false });
      self.addToLayer("context", res[1], { className: "dmap-province", interactive: false, labels: true });
    });
  };

  DcprMap.bboxPolygon = bboxPolygon;
  DcprMap.geomBounds = geomBounds;
  DcprMap.SA = SA;
  global.DcprMap = DcprMap;
})(window);
