(function () {
  "use strict";

  // Confirmation prompts on buttons with data-confirm
  document.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-confirm]");
    if (btn && !window.confirm(btn.getAttribute("data-confirm"))) {
      e.preventDefault();
    }
  });

  // Show each dataset's "Other" geographic extent box only when "Other" is ticked
  function toggleOther(block) {
    var other = block.querySelector('[data-field$="-geographic_extent_other"]');
    if (!other) return;
    var ticked = block.querySelector('input[name$="-geographic_extents"][value="O"]:checked');
    other.classList.toggle("hidden", !ticked && !other.classList.contains("has-error"));
  }
  function initBlocks() {
    document.querySelectorAll("[data-ds]").forEach(toggleOther);
  }
  document.addEventListener("change", function (e) {
    if (e.target.name && /-geographic_extents$/.test(e.target.name)) {
      toggleOther(e.target.closest("[data-ds]"));
    }
  });

  // Repeatable datasets (Django formset, prefix "ds")
  var dsRows = document.getElementById("ds-rows");
  var dsTpl = document.getElementById("ds-template");
  var dsTotal = document.getElementById("id_ds-TOTAL_FORMS");
  function renumber() {
    if (!dsRows) return;
    var n = 0;
    dsRows.querySelectorAll("[data-ds]").forEach(function (b) {
      if (b.classList.contains("hidden")) return;
      n += 1;
      var num = b.querySelector(".ds-num");
      if (num) num.textContent = n;
    });
    // Never offer to remove the only remaining dataset
    var visible = dsRows.querySelectorAll("[data-ds]:not(.hidden) .remove-ds");
    visible.forEach(function (btn) { btn.classList.toggle("hidden", n <= 1); });
  }
  var addDs = document.getElementById("add-ds");
  if (addDs && dsTpl && dsRows && dsTotal) {
    addDs.addEventListener("click", function () {
      var idx = parseInt(dsTotal.value, 10);
      var wrap = document.createElement("div");
      wrap.innerHTML = dsTpl.innerHTML.replace(/__prefix__/g, String(idx)).trim();
      var block = wrap.firstElementChild;
      dsRows.appendChild(block);
      dsTotal.value = idx + 1;
      toggleOther(block);
      block.dispatchEvent(new CustomEvent("dcpr:block-added", { bubbles: true }));
      renumber();
      var title = block.querySelector('input[name$="-title"]');
      if (title) { block.scrollIntoView({ behavior: "smooth", block: "start" }); title.focus({ preventScroll: true }); }
    });
    dsRows.addEventListener("click", function (e) {
      var rm = e.target.closest(".remove-ds");
      if (!rm) return;
      var block = rm.closest("[data-ds]");
      var del = block.querySelector('input[name$="-DELETE"]');
      if (del) del.checked = true;  // Django skips deleted forms
      block.classList.add("hidden");
      renumber();
    });
  }
  initBlocks();
  renumber();

  // Dynamic attachment rows for the Django formset (prefix "att")
  var addBtn = document.getElementById("add-att");
  var tpl = document.getElementById("att-template");
  var rows = document.getElementById("att-rows");
  var total = document.getElementById("id_att-TOTAL_FORMS");
  if (addBtn && tpl && rows && total) {
    addBtn.addEventListener("click", function () {
      var idx = parseInt(total.value, 10);
      var html = tpl.innerHTML.replace(/__prefix__/g, String(idx));
      var wrapper = document.createElement("div");
      wrapper.innerHTML = html.trim();
      var row = wrapper.firstElementChild;
      rows.appendChild(row);
      total.value = idx + 1;
      var input = row.querySelector('input[type="file"]');
      if (input) input.click();
    });
    rows.addEventListener("click", function (e) {
      var rm = e.target.closest(".remove-row");
      if (!rm) return;
      // Clear the row rather than removing it, so formset indices stay contiguous.
      var row = rm.closest(".att-row");
      row.querySelectorAll("input, select").forEach(function (el) {
        if (el.type === "file" || el.type === "text") el.value = "";
        if (el.tagName === "SELECT") el.selectedIndex = 0;
      });
      row.classList.add("hidden");
    });
  }
})();
