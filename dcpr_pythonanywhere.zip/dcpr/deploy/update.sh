#!/usr/bin/env bash
# Apply a new DCPR version on PythonAnywhere (run in a Bash console):
#   workon dcpr-venv && bash ~/dcpr/deploy/update.sh
# Copy the new code into ~/dcpr first (git pull, or unzip a new dcpr.zip over it;
# your .env, db.sqlite3 and media/ folder are not in the zip and are kept).
set -euo pipefail
cd "$HOME/dcpr"
cp db.sqlite3 "db.sqlite3.bak-$(date +%Y%m%d-%H%M%S)" 2>/dev/null || true   # quick backup
pip install --no-cache-dir -q -r requirements.txt
python manage.py migrate --noinput
python manage.py collectstatic --noinput -v 0
python manage.py check --deploy --fail-level ERROR
# Touching the WSGI file reloads the web app.
touch /var/www/"${USER}"_pythonanywhere_com_wsgi.py
echo "DCPR updated and reloaded."
