# PythonAnywhere WSGI file for DCPR.
#
# Copy the contents of this file into the WSGI file linked on your PythonAnywhere
# "Web" tab (it is called /var/www/<username>_pythonanywhere_com_wsgi.py), replacing
# everything that is there. Change YOURUSERNAME below, save, and click Reload.
import os
import sys

USERNAME = "YOURUSERNAME"                      # <-- your PythonAnywhere username
PROJECT_DIR = f"/home/{USERNAME}/dcpr"           # folder that contains manage.py

if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
# Secrets and options are read from /home/<username>/dcpr/.env by config/settings.py.

from django.core.wsgi import get_wsgi_application  # noqa: E402

application = get_wsgi_application()
